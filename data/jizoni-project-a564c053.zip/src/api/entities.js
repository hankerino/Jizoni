import { base44 } from './base44Client';


export const Project = base44.entities.Project;

export const Task = base44.entities.Task;

export const Comment = base44.entities.Comment;

export const Baseline = base44.entities.Baseline;

export const Calendar = base44.entities.Calendar;

export const Resource = base44.entities.Resource;

export const TaskRelationship = base44.entities.TaskRelationship;

export const ScheduleSettings = base44.entities.ScheduleSettings;

export const FloatPath = base44.entities.FloatPath;

export const ScheduleLoop = base44.entities.ScheduleLoop;

export const ResourceAssignment = base44.entities.ResourceAssignment;



// auth sdk:
export const User = base44.auth;