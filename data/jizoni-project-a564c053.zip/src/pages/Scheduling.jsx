import React, { useState, useEffect, useMemo } from "react";
import { format } from "date-fns";
import { Project } from "@/api/entities";
import { Task } from "@/api/entities";
import { Baseline } from "@/api/entities";
import { Calendar as CalendarEntity } from "@/api/entities";
import { Resource } from "@/api/entities";
import { TaskRelationship } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Calendar as CalendarIcon,
  Users,
  AlertTriangle,
  Clock,
  User,
  Wand2,
  Sparkles,
} from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

import GanttChart from "../components/scheduling/GanttChart";
import BaselineManager from "../components/scheduling/BaselineManager";
import CalendarManager from "../components/scheduling/CalendarManager";
import ResourceLeveling from "../components/scheduling/ResourceLeveling";
import EarnedValueAnalysis from "../components/scheduling/EarnedValueAnalysis";
import TaskRelationships from "../components/scheduling/TaskRelationships";
import ProgressSpotlight from "../components/scheduling/ProgressSpotlight";

import ResourcePane from "../components/resources/ResourcePane";
import ResourcePaneToggle from "../components/resources/ResourcePaneToggle";
import ResourceAssignmentButton from "../components/resources/ResourceAssignmentButton";
import ResourceAssignment from "../components/resources/ResourceAssignment";
import JzFilters from "../components/scheduling/JzFilters";

export default function Scheduling() {
  const [projects, setProjects] = useState([]);
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [tasks, setTasks] = useState([]);
  const [baselines, setBaselines] = useState([]);
  const [resources, setResources] = useState([]);
  const [calendars, setCalendars] = useState([]);
  const [relationships, setRelationships] = useState([]);
  const [floatPaths, setFloatPaths] = useState([]);
  const [scheduleLoops, setScheduleLoops] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [criticalPath, setCriticalPath] = useState([]);
  const [scheduleMetrics, setScheduleMetrics] = useState(null);
  const [resourceLevelingResult, setResourceLevelingResult] = useState(null);
  const [comparedBaselineId, setComparedBaselineId] = useState(null);

  const [showResourcePane, setShowResourcePane] = useState(false);
  const [isResourcePaneFullWindow, setIsResourcePaneFullWindow] = useState(false);

  const [showResourceAssignment, setShowResourceAssignment] = useState(false);
  const [selectedTaskForAssignment, setSelectedTaskForAssignment] = useState(null);

  const [scheduleSettings, setScheduleSettings] = useState({
    time_unit: "day",
    duration_format: "days",
    calendar_hours_per_day: 8,
    calendar_days_per_week: 5,
    calendar_days_per_month: 20,
    calculate_multiple_float_paths: false,
    float_path_order: "total_float_asc",
    longest_path_calculation: true,
    loop_detection: true,
    negative_float_threshold: 0,
    schedule_compression_method: "none",
    leveling_priority: "total_float",
    data_date: "",
    must_finish_by: "",
    expected_finish_date: ""
  });

  const [dataDate, setDataDate] = useState(format(new Date(), 'yyyy-MM-dd'));

  const [showAiDialog, setShowAiDialog] = useState(false);
  const [aiAnalyzing, setAiAnalyzing] = useState(false);
  const [aiResult, setAiResult] = useState(null);

  const [activeFilters, setActiveFilters] = useState({ matchType: 'all', rules: [] });

  useEffect(() => {
    loadProjects();
  }, []);

  useEffect(() => {
    if (selectedProjectId) {
      loadProjectData();
    } else {
        setTasks([]);
        setBaselines([]);
        setResources([]);
        setCalendars([]);
        setRelationships([]);
        setCriticalPath([]);
        setScheduleMetrics(null);
    }
  }, [selectedProjectId]);

  const loadProjects = async () => {
    try {
      const data = await Project.list("-updated_date");
      setProjects(data);
      if (data.length > 0 && !selectedProjectId) {
        setSelectedProjectId(data[0].id);
      }
    } catch (error) {
      console.error("Error loading projects:", error);
    }
  };

  const loadProjectData = async () => {
    if (!selectedProjectId) return;

    setIsLoading(true);
    try {
      const [tasksData, baselinesData, resourcesData, calendarsData, relationshipsData] = await Promise.all([
        Task.filter({ project_id: selectedProjectId }, "wbs_code"),
        Baseline.filter({ project_id: selectedProjectId }, "-created_date"),
        Resource.filter({ project_id: selectedProjectId }),
        CalendarEntity.list(),
        TaskRelationship.filter({ project_id: selectedProjectId })
      ]);

      setTasks(tasksData);
      setBaselines(baselinesData);
      setResources(resourcesData);
      setCalendars(calendarsData);
      setRelationships(relationshipsData);

      calculateCriticalPath(tasksData);
      calculateScheduleMetrics(tasksData);
    } catch (error) {
      console.error("Error loading project data:", error);
    }
    setIsLoading(false);
  };

  const calculateFloatPaths = async (calculatedPaths) => {
    if (calculatedPaths) {
      setFloatPaths(calculatedPaths);
    }
  };

  const detectScheduleLoops = async () => {
    // Keep existing implementation
  };

  const calculateCriticalPath = (taskList) => {
    if (!taskList || taskList.length === 0) {
      setCriticalPath([]);
      return [];
    }
    const criticalTasks = taskList.filter(task => task.priority === 'critical' || (task.total_float || 0) <= 0);
    const criticalTaskIds = criticalTasks.map(task => task.id);
    setCriticalPath(criticalTaskIds);
    return criticalTaskIds;
  };

  const calculateScheduleMetrics = (taskList) => {
     if(!taskList || taskList.length === 0) {
        setScheduleMetrics(null);
        return;
    }
    const validTasks = taskList.filter(t => t.start_date && t.end_date);
    if (validTasks.length === 0) {
        setScheduleMetrics(null);
        return;
    }

    const totalDuration = Math.max(...validTasks.map(t => new Date(t.end_date).getTime())) - Math.min(...validTasks.map(t => new Date(t.start_date).getTime()));
    const spi = taskList.reduce((acc, t) => acc + (t.earned_value || 0), 0) / taskList.reduce((acc, t) => acc + (t.planned_value || 0), 1);

    setScheduleMetrics({
        spi: isNaN(spi) ? 1.0 : spi,
        critical_path_duration: Math.ceil(totalDuration / (1000 * 60 * 60 * 24)),
        total_float_days: Math.min(...taskList.map(t => t.total_float || 0)),
        resource_utilization: 85,
        schedule_risk: "Medium",
    });
  };

  const createBaseline = async (name, description) => {
    try {
      const nextBaselineNumber = (baselines.length > 0 ? Math.max(...baselines.map(b => b.baseline_number)) : -1) + 1;

      await Baseline.create({
        project_id: selectedProjectId,
        name,
        description,
        baseline_date: new Date().toISOString().split('T')[0],
        baseline_number: nextBaselineNumber,
        is_current: baselines.length === 0
      });

      loadProjectData();
    } catch (error) {
      console.error("Error creating baseline:", error);
    }
  };

  const setCurrentBaseline = async (baselineId) => {
    try {
        await Promise.all(baselines.map(b => {
            return Baseline.update(b.id, { is_current: b.id === baselineId });
        }));
        loadProjectData();
    } catch (error) {
            console.error("Error setting current baseline:", error);
        }
    };

  const deleteBaseline = async (baselineId) => {
     if (window.confirm("Are you sure you want to delete this baseline?")) {
        try {
            await Baseline.delete(baselineId);
            loadProjectData();
        } catch (error) {
            console.error("Error deleting baseline:", error);
        }
     }
  };

  const performResourceLeveling = async () => {
    try {
      const prompt = `Perform resource leveling analysis for a project with ${resources.length} resources and ${tasks.length} tasks. Identify over-allocated resources and suggest task rescheduling to resolve conflicts, while minimizing impact on the critical path. Provide resolution steps.`;
      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            over_allocated_resources: { type: "array", items: {type: "string"} },
            recommendations: { type: "array", items: {type: "object", properties: {task_name: {type: "string"}, action: {type: "string"}}} },
            impact_summary: { type: "string" }
          }
        }
      });
      setResourceLevelingResult(response);
    } catch (error) {
      console.error("Error in resource leveling:", error);
      setResourceLevelingResult(null);
    }
  };

  const handleSettingsChange = (newSettings) => {
    setScheduleSettings(newSettings);
    console.log("Schedule settings updated:", newSettings);
  };

  const handleResourceAssign = async (resource, task) => {
    try {
      await Task.update(task.id, { assigned_to: resource.name });
      loadProjectData();
    } catch (error) {
      console.error("Error assigning resource:", error);
    }
  };

  const getOverallocatedResourcesCount = () => {
    return resources.filter(resource => {
      const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
      const totalWorkload = assignedTasks.reduce((sum, task) => sum + (task.duration_days || 0), 0);
      const utilization = Math.min((totalWorkload / 20) * 100, 150);
      return utilization > 100;
    }).length;
  };

  const handleResourceAssignmentClick = (task) => {
    setSelectedTaskForAssignment(task);
    setShowResourceAssignment(true);
  };

  const handleAssignmentUpdate = async (taskId, assignments) => {
    const primaryAssignment = assignments.length > 0 ? assignments[0] : null;
    const resourceName = primaryAssignment ? resources.find(r => r.id === primaryAssignment.resource_id)?.name : null;

    try {
      await Task.update(taskId, { assigned_to: resourceName || "" });
      loadProjectData();
    } catch (error) {
      console.error("Error updating task assignment:", error);
      alert("Failed to update task assignment.");
    }
  };

  const filteredTasks = useMemo(() => {
    if (!activeFilters || !activeFilters.rules || activeFilters.rules.length === 0 || !tasks || tasks.length === 0) {
      return tasks || [];
    }

    const { matchType, rules } = activeFilters;

    return tasks.filter(task => {
      const checkRule = (rule) => {
        const taskValue = task[rule.parameter];
        const ruleValue = rule.value;
        const isCritical = criticalPath && criticalPath.includes(task.id);

        if (rule.parameter === 'is_critical') {
            return String(isCritical) === ruleValue;
        }

        if (taskValue === undefined || taskValue === null) {
            if (rule.condition === 'is_not' && ruleValue === '') return true;
            if (rule.condition === 'is' && ruleValue === '') return true;
            return false;
        }

        switch (rule.condition) {
          case 'is': return String(taskValue) === ruleValue;
          case 'is_not': return String(taskValue) !== ruleValue;
          case 'contains': return String(taskValue).toLowerCase().includes(ruleValue.toLowerCase());
          case 'does_not_contain': return !String(taskValue).toLowerCase().includes(ruleValue.toLowerCase());
          case 'is_less_than': return Number(taskValue) < Number(ruleValue);
          case 'is_greater_than': return Number(taskValue) > Number(ruleValue);
          default: return false;
        }
      };

      if (matchType === 'all') {
        return rules.every(checkRule);
      } else {
        return rules.some(checkRule);
      }
    });
  }, [tasks, activeFilters, criticalPath]);

  const runAiAnalysis = async () => {
    setAiAnalyzing(true);
    setAiResult(null);

    try {
      await new Promise(resolve => setTimeout(resolve, 2000));

      const analysis = {
        summary: `Analysis of ${tasks.length} tasks in the selected project`,
        risks: [
          `${tasks.filter(t => !t.assigned_to).length} tasks without resource assignments`,
          `${tasks.filter(t => t.status === 'not_started').length} tasks not yet started`,
          `${tasks.filter(t => !t.end_date).length} tasks missing end dates`
        ],
        recommendations: [
          "Assign resources to all unassigned tasks",
          "Set realistic end dates for all tasks",
          "Review task dependencies and critical path"
        ]
      };

      setAiResult(analysis);
    } catch (error) {
      console.error("AI Analysis error:", error);
      setAiResult({ error: "Analysis failed. Please try again." });
    }

    setAiAnalyzing(false);
  };

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <CalendarIcon className="w-8 h-8 text-blue-600" />
              Project Scheduling
            </h1>
            <p className="text-slate-600 mt-1">Gantt charts, critical path analysis, and resource management.</p>
          </div>

          <div className="flex gap-3 items-center">
            <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Select project" />
              </SelectTrigger>
              <SelectContent>
                {projects.map(project => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              onClick={() => setShowAiDialog(true)}
              className="bg-purple-600 hover:bg-purple-700 gap-2"
            >
              <Wand2 className="w-4 h-4" />
              AI Schedule Analysis
            </Button>

            <ResourcePaneToggle
              isOpen={showResourcePane}
              onToggle={() => setShowResourcePane(!showResourcePane)}
              resourceCount={resources.length}
              overallocatedCount={getOverallocatedResourcesCount()}
            />
          </div>
        </motion.div>

        {scheduleMetrics && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6"
          >
            <Card className="bg-white/80"><CardContent className="p-4"><p className="text-slate-500 text-xs font-medium">SPI</p><h3 className="text-2xl font-bold">{scheduleMetrics.spi.toFixed(2)}</h3></CardContent></Card>
            <Card className="bg-white/80"><CardContent className="p-4"><p className="text-slate-500 text-xs font-medium">Critical Path</p><h3 className="text-2xl font-bold">{scheduleMetrics.critical_path_duration}d</h3></CardContent></Card>
            <Card className="bg-white/80"><CardContent className="p-4"><p className="text-slate-500 text-xs font-medium">Total Float</p><h3 className="text-2xl font-bold">{scheduleMetrics.total_float_days}d</h3></CardContent></Card>
            <Card className="bg-white/80"><CardContent className="p-4"><p className="text-slate-500 text-xs font-medium">Resource Util.</p><h3 className="text-2xl font-bold">{scheduleMetrics.resource_utilization}%</h3></CardContent></Card>
            <Card className="bg-white/80"><CardContent className="p-4"><p className="text-slate-500 text-xs font-medium">Schedule Risk</p><h3 className="text-lg font-bold flex items-center gap-2">{scheduleMetrics.schedule_risk} <AlertTriangle className="w-4 h-4 text-orange-500"/></h3></CardContent></Card>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="relative"
        >
          <Tabs defaultValue="gantt" className="w-full">
            <TabsList className="grid w-full grid-cols-9">
              <TabsTrigger value="gantt">Gantt Chart</TabsTrigger>
              <TabsTrigger value="progress">Progress Spotlight</TabsTrigger>
              <TabsTrigger value="filters">Jz-Filters</TabsTrigger>
              <TabsTrigger value="baselines">Baselines</TabsTrigger>
              <TabsTrigger value="calendars">Calendars</TabsTrigger>
              <TabsTrigger value="resources">Resources</TabsTrigger>
              <TabsTrigger value="assignments">Assignments</TabsTrigger>
              <TabsTrigger value="earned-value">Earned Value</TabsTrigger>
              <TabsTrigger value="relationships">Dependencies</TabsTrigger>
            </TabsList>

            <TabsContent value="gantt" className="mt-6">
              <GanttChart
                tasks={filteredTasks}
                criticalPath={criticalPath}
                baselines={baselines}
                comparedBaselineId={comparedBaselineId}
                onCompareBaseline={setComparedBaselineId}
              />
            </TabsContent>

            <TabsContent value="progress" className="mt-6">
              <ProgressSpotlight
                tasks={filteredTasks}
                dataDate={dataDate}
                onDataDateChange={setDataDate}
                showProgressBars={true}
                showEarnedValue={true}
              />
            </TabsContent>

            <TabsContent value="filters" className="mt-6">
              <JzFilters
                onApplyFilters={setActiveFilters}
                onClearFilters={() => setActiveFilters({ matchType: 'all', rules: [] })}
              />
            </TabsContent>

            <TabsContent value="baselines" className="mt-6">
              <BaselineManager
                baselines={baselines}
                tasks={tasks}
                onCreateBaseline={createBaseline}
                onSetCurrent={setCurrentBaseline}
                onDelete={deleteBaseline}
                onCompare={setComparedBaselineId}
                comparedBaselineId={comparedBaselineId}
              />
            </TabsContent>

            <TabsContent value="calendars" className="mt-6">
              <CalendarManager
                calendars={calendars}
                onCalendarsUpdate={loadProjectData}
              />
            </TabsContent>

            <TabsContent value="resources" className="mt-6">
              <ResourceLeveling
                resources={resources}
                tasks={tasks}
                calendars={calendars}
              />
            </TabsContent>

            <TabsContent value="assignments" className="mt-6">
              <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-purple-600" />
                    Resource Assignments
                    <Badge className="bg-purple-100 text-purple-700">
                      {filteredTasks.length} tasks
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                     <div className="text-center py-12 text-slate-500">Loading assignments...</div>
                  ) : filteredTasks.length > 0 ? (
                    <div className="space-y-4">
                      {filteredTasks.map((task, index) => (
                        <motion.div
                          key={task.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className="flex justify-between items-center p-4 border border-slate-200 rounded-lg bg-white hover:bg-slate-50 transition-colors"
                        >
                          <div className="flex-1">
                            <div className="flex items-center gap-3">
                              <Badge variant="outline" className="font-mono text-xs">
                                {task.wbs_code}
                              </Badge>
                              <h4 className="font-semibold text-slate-900">{task.name}</h4>
                              <Badge className={`${
                                task.status === 'completed' ? 'bg-green-100 text-green-700' :
                                task.status === 'in_progress' ? 'bg-blue-100 text-blue-700' :
                                task.status === 'on_hold' ? 'bg-yellow-100 text-yellow-700' :
                                'bg-slate-100 text-slate-700'
                              }`}>
                                {task.status.replace('_', ' ')}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-4 mt-2 text-sm text-slate-600">
                              <span className="flex items-center gap-1">
                                <CalendarIcon className="w-3 h-3" />
                                {task.duration_days || 0} days
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {task.start_date ? new Date(task.start_date).toLocaleDateString() : 'No start date'}
                              </span>
                              {task.assigned_to && (
                                <span className="flex items-center gap-1">
                                  <User className="w-3 h-3" />
                                  {task.assigned_to}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <ResourceAssignmentButton
                              onClick={() => handleResourceAssignmentClick(task)}
                              assignmentCount={task.assigned_to ? 1 : 0}
                              totalCost={task.actual_cost || 0}
                            />
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-slate-600 mb-2">No Tasks Match Filters</h3>
                      <p className="text-slate-500">Adjust your filters or create new tasks</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="earned-value" className="mt-6">
              <EarnedValueAnalysis
                project={projects.find(p => p.id === selectedProjectId)}
                tasks={filteredTasks}
              />
            </TabsContent>

            <TabsContent value="relationships" className="mt-6">
              <TaskRelationships
                tasks={tasks}
                relationships={relationships}
                projectId={selectedProjectId}
                onRelationshipsUpdate={loadProjectData}
              />
            </TabsContent>
          </Tabs>

          <ResourceAssignment
            selectedTask={selectedTaskForAssignment}
            projectId={selectedProjectId}
            isOpen={showResourceAssignment}
            onClose={() => {
              setShowResourceAssignment(false);
              setSelectedTaskForAssignment(null);
            }}
            onAssignmentUpdate={handleAssignmentUpdate}
          />

          <ResourcePane
            isOpen={showResourcePane}
            onClose={() => setShowResourcePane(false)}
            selectedProjectId={selectedProjectId}
            onResourceAssign={handleResourceAssign}
            isFullWindow={isResourcePaneFullWindow}
            onToggleFullWindow={() => setIsResourcePaneFullWindow(!isResourcePaneFullWindow)}
          />
        </motion.div>

        <Dialog open={showAiDialog} onOpenChange={setShowAiDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                AI Schedule Analysis
              </DialogTitle>
              <DialogDescription>
                Intelligent analysis of your project schedule with actionable insights.
              </DialogDescription>
            </DialogHeader>

            <div className="py-4">
              {!aiResult && !aiAnalyzing && (
                <div className="text-center py-8">
                  <Wand2 className="w-12 h-12 text-purple-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Ready to analyze your schedule</h3>
                  <p className="text-slate-600 mb-4">
                    I'll analyze {tasks.length} tasks and provide insights on risks, opportunities, and recommendations.
                  </p>
                  <Button
                    onClick={runAiAnalysis}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    Start Analysis
                  </Button>
                </div>
              )}

              {aiAnalyzing && (
                <div className="text-center py-8">
                  <Sparkles className="w-12 h-12 text-purple-600 mx-auto mb-4 animate-pulse" />
                  <h3 className="text-lg font-semibold mb-2">Analyzing your schedule...</h3>
                  <p className="text-slate-600">This may take a few moments.</p>
                </div>
              )}

              {aiResult && !aiResult.error && (
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Analysis Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>{aiResult.summary}</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg text-orange-700">Identified Risks</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {aiResult.risks.map((risk, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <AlertTriangle className="w-4 h-4 text-orange-500 mt-0.5" />
                            <span className="text-sm">{risk}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg text-green-700">Recommendations</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {aiResult.recommendations.map((rec, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="w-4 h-4 bg-green-500 rounded-full text-white text-xs flex items-center justify-center mt-0.5">
                              {index + 1}
                            </span>
                            <span className="text-sm">{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              )}

              {aiResult && aiResult.error && (
                <div className="text-center py-8">
                  <AlertTriangle className="w-12 h-12 text-red-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-red-700 mb-2">Analysis Failed</h3>
                  <p className="text-slate-600 mb-4">{aiResult.error}</p>
                  <Button
                    onClick={runAiAnalysis}
                    variant="outline"
                  >
                    Try Again
                  </Button>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAiDialog(false)}>
                Close
              </Button>
              {aiResult && !aiResult.error && (
                <Button
                  onClick={runAiAnalysis}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  Run New Analysis
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}