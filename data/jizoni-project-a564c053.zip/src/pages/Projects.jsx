
import React, { useState, useEffect, useCallback } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Project } from "@/api/entities";
import { Task } from "@/api/entities";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { InvokeLLM } from "@/api/integrations";
import { claudeAI } from "@/api/functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Plus, Search, Filter, Calendar, DollarSign, Bot, Edit, Trash2, Eye, TrendingUp, FolderKanban, Wand2, Sparkles, AlertTriangle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [currentUser, setCurrentUser] = useState(null);
  const [editingProject, setEditingProject] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();
  const [isAiAssisting, setIsAiAssisting] = useState(false);

  const [newProject, setNewProject] = useState({
    name: "",
    description: "",
    start_date: "",
    end_date: "",
    budget: "",
    status: "planning",
    priority: "medium",
    team_size: 1,
    project_manager: "",
    project_type: "construction",
    site_location: "",
    identified_risks: []
  });

  const loadInitialData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [projectData, taskData, userData] = await Promise.all([
        Project.list("-updated_date"),
        Task.list("-updated_date", 2000), // Increase limit to get all tasks for accurate counts
        User.me().catch(() => null) // Handle user loading failure gracefully
      ]);
      setProjects(projectData || []);
      setTasks(taskData || []);
      if (userData) {
        setCurrentUser(userData);
        setNewProject(prev => ({ ...prev, project_manager: userData.full_name }));
      }
    } catch (error) {
      console.error("Error loading initial data:", error);
      setProjects([]);
      setTasks([]);
      setCurrentUser(null);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    loadInitialData();

    const params = new URLSearchParams(location.search);
    const statusFromUrl = params.get('status');
    if (statusFromUrl && statusFromUrl !== filterStatus) {
      setFilterStatus(statusFromUrl);
    } else if (!statusFromUrl && filterStatus !== 'all') {
      setFilterStatus('all');
    }
  }, [location.search, filterStatus, loadInitialData]);

  const handleAiAssist = async () => {
    if (!newProject.name || !newProject.description) {
        alert("Please provide a Project Name and Description for Jz-Agent to assist.");
        return;
    }
    setIsAiAssisting(true);
    try {
        const prompt = `Based on the following project information, and adhering to professional pre-planning protocols, provide suggestions for budget, team size, and identify key risks.

        Project Name: ${newProject.name}
        Project Type: ${newProject.project_type}
        Description: ${newProject.description}
        Start Date: ${newProject.start_date}
        End Date: ${newProject.end_date}
        
        Consider the following pre-start checks: Scope relationships, Division of Responsibility (DOR), long-lead equipment, subcontracts, and governing codes.

        Return a JSON object with keys: "suggested_budget" (number), "suggested_team_size" (number), and "potential_risks" (an array of strings detailing risks related to the pre-start checks).`;

        // Try Claude first, fallback to InvokeLLM
        let response;
        try {
          const { data } = await claudeAI({
            prompt,
            system_prompt: "You are an expert construction project manager. Provide realistic budget estimates, team size recommendations, and comprehensive risk assessments.",
            temperature: 0.3,
            max_tokens: 2000
          });
          
          if (data.error) {
            throw new Error(data.error);
          }
          
          // Parse Claude's response as JSON
          const jsonMatch = data.response.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            response = JSON.parse(jsonMatch[0]);
          } else {
            throw new Error("No valid JSON found in response");
          }
        } catch (claudeError) {
          console.log("Claude failed, falling back to InvokeLLM:", claudeError.message);
          // Fallback to original InvokeLLM
          response = await InvokeLLM({
              prompt,
              response_json_schema: {
                  type: "object",
                  properties: {
                      suggested_budget: { type: "number" },
                      suggested_team_size: { type: "number" },
                      potential_risks: { type: "array", items: { type: "string" } }
                  }
              }
          });
        }

        if (response) {
            setNewProject(prev => ({
                ...prev,
                budget: response.suggested_budget || prev.budget,
                team_size: response.suggested_team_size || prev.team_size,
                identified_risks: response.potential_risks || [],
            }));
        }
    } catch (error) {
        console.error("Jz-Agent Assist Error:", error);
        alert(`Jz-Agent failed to provide suggestions: ${error.message}`);
    }
    setIsAiAssisting(false);
  };

  const handleCreateProject = async () => {
    try {
      const projectData = {
        ...newProject,
        budget: newProject.budget ? parseFloat(newProject.budget) : 0,
        team_size: parseInt(newProject.team_size) || 1
      };
      
      if (editingProject) {
        await Project.update(editingProject.id, projectData);
      } else {
        await Project.create(projectData);
      }
      
      setShowCreateDialog(false);
      setEditingProject(null);
      resetForm();
      await loadInitialData(); // Refresh all data
    } catch (error) {
      console.error("Error saving project:", error);
      alert('Failed to save project. Please try again.');
    }
  };

  const handleEditProject = (project) => {
    setEditingProject(project);
    setNewProject({ ...project });
    setShowCreateDialog(true);
  };

  const handleDeleteProject = async (projectId) => {
    if (window.confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
      try {
        await Project.delete(projectId);
        setProjects(projects.filter(p => p.id !== projectId));
      } catch (error) {
        console.error("Error deleting project:", error);
        alert('Failed to delete project. Please try again.');
      }
    }
  };

  const resetForm = () => {
    setNewProject({
      name: "",
      description: "",
      start_date: "",
      end_date: "",
      budget: "",
      status: "planning",
      priority: "medium",
      team_size: 1,
      project_manager: currentUser?.full_name || "",
      project_type: "construction",
      site_location: "",
      identified_risks: []
    });
  };

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (project.description || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || project.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const statusCounts = {
    all: projects.length,
    planning: projects.filter(p => p.status === 'planning').length,
    active: projects.filter(p => p.status === 'active').length,
    completed: projects.filter(p => p.status === 'completed').length,
    on_hold: projects.filter(p => p.status === 'on_hold').length
  };

  // AI Insights calculations
  const getAIInsights = () => {
    const activeProjects = projects.filter(p => p.status === 'active');
    const projectTasks = tasks.filter(task => 
      activeProjects.some(project => project.id === task.project_id)
    );
    
    const overdueTasks = projectTasks.filter(task => 
      task.end_date && new Date(task.end_date) < new Date() && task.status !== 'completed'
    );

    const highPriorityTasks = projectTasks.filter(task => 
      task.priority === 'critical' || task.priority === 'high'
    );

    return {
      activeProjectsCount: activeProjects.length,
      overdueTasksCount: overdueTasks.length,
      highPriorityTasksCount: highPriorityTasks.length,
      avgCompletion: activeProjects.reduce((sum, p) => sum + (p.completion_percentage || 0), 0) / (activeProjects.length || 1)
    };
  };

  const aiInsights = getAIInsights();

  // Loading skeleton
  if (isLoading) {
    return (
      <div className="p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="animate-pulse h-12 w-1/3 bg-slate-200 rounded"></div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className="bg-white rounded-xl h-64 border border-slate-200"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Project Portfolio</h1>
            <p className="text-slate-600 mt-1">Manage all engineering and construction projects.</p>
          </div>
          
          <Dialog open={showCreateDialog} onOpenChange={(open) => {
            setShowCreateDialog(open);
            if (!open) {
              setEditingProject(null);
              resetForm();
            }
          }}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700 gap-2">
                <Plus className="w-4 h-4" />
                New Project
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>{editingProject ? 'Edit Project' : 'Create New Project'}</DialogTitle>
                <DialogDescription>
                  {editingProject ? 'Update the project details below.' : 'Add a new project. Use the Jz-Agent for suggestions on budget, team size, and risks.'}
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-6 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Project Name</Label>
                    <Input
                      id="name"
                      value={newProject.name}
                      onChange={(e) => setNewProject(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="e.g., Downtown Skyscraper"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="project_type">Project Type</Label>
                    <Select value={newProject.project_type} onValueChange={(value) => setNewProject(prev => ({...prev, project_type: value}))}>
                      <SelectTrigger id="project_type">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="construction">Construction</SelectItem>
                        <SelectItem value="engineering">Engineering</SelectItem>
                        <SelectItem value="infrastructure">Infrastructure</SelectItem>
                        <SelectItem value="industrial">Industrial</SelectItem>
                        <SelectItem value="research">Research</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newProject.description}
                    onChange={(e) => setNewProject(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Project scope, objectives, and key deliverables."
                    rows={3}
                  />
                </div>
                
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 text-center">
                  <Button
                    variant="outline"
                    onClick={handleAiAssist}
                    disabled={isAiAssisting}
                    className="gap-2 bg-white"
                  >
                    <Wand2 className="w-4 h-4 text-purple-600" />
                    {isAiAssisting ? "Jz-Agent Analyzing..." : "Jz-Agent Kickstart"}
                  </Button>
                  <p className="text-xs text-purple-700 mt-2">Let Jz-Agent suggest budget, team size & risks based on your project description.</p>
                </div>

                {newProject.project_type === 'construction' && (
                  <div className="space-y-2">
                    <Label htmlFor="site_location">Site Location</Label>
                    <Input
                      id="site_location"
                      value={newProject.site_location}
                      onChange={(e) => setNewProject(prev => ({ ...prev, site_location: e.target.value }))}
                      placeholder="e.g., 123 Main St, New York, NY"
                    />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="start_date">Start Date</Label>
                    <Input
                      id="start_date"
                      type="date"
                      value={newProject.start_date}
                      onChange={(e) => setNewProject(prev => ({ ...prev, start_date: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end_date">Target End Date</Label>
                    <Input
                      id="end_date"
                      type="date"
                      value={newProject.end_date}
                      onChange={(e) => setNewProject(prev => ({ ...prev, end_date: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="budget">Budget ($)</Label>
                    <Input
                      id="budget"
                      type="number"
                      value={newProject.budget}
                      onChange={(e) => setNewProject(prev => ({ ...prev, budget: e.target.value }))}
                      placeholder="e.g., 1000000"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="priority">Priority</Label>
                    <Select value={newProject.priority} onValueChange={(value) => setNewProject(prev => ({ ...prev, priority: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="team_size">Team Size</Label>
                    <Input
                      id="team_size"
                      type="number"
                      min="1"
                      value={newProject.team_size}
                      onChange={(e) => setNewProject(prev => ({ ...prev, team_size: e.target.value }))}
                    />
                  </div>
                </div>

                {newProject.identified_risks && newProject.identified_risks.length > 0 && (
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-orange-500" /> Jz-Agent Identified Risks</Label>
                    <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg space-y-1">
                      {newProject.identified_risks.map((risk, index) => (
                        <p key={index} className="text-sm text-orange-800">- {risk}</p>
                      ))}
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="project_manager">Project Manager</Label>
                  <Input
                    id="project_manager"
                    value={newProject.project_manager}
                    onChange={(e) => setNewProject(prev => ({ ...prev, project_manager: e.target.value }))}
                    placeholder="Lead engineer or project manager"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateProject} className="bg-blue-600 hover:bg-blue-700">
                  {editingProject ? 'Update Project' : 'Create Project'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </motion.div>

        {/* Filters and Search */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between"
        >
          <div className="flex gap-2 flex-wrap">
            {Object.entries(statusCounts).map(([status, count]) => (
              <Button
                key={status}
                variant={filterStatus === status ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  const currentParams = new URLSearchParams(location.search);
                  if (status === 'all') {
                    currentParams.delete('status');
                  } else {
                    currentParams.set('status', status);
                  }
                  navigate({ search: currentParams.toString() });
                }}
                className={`gap-2 ${filterStatus === status ? 'bg-blue-600' : ''}`}
              >
                {status.replace('_', ' ').replace(/^\w/, c => c.toUpperCase())}
                <Badge variant="secondary" className="ml-1">{count}</Badge>
              </Button>
            ))}
          </div>
          
          <div className="flex gap-2">
            <div className="relative w-full lg:w-80">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder="Search projects by name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white/80 backdrop-blur-sm border-slate-200"
              />
            </div>
          </div>
        </motion.div>

        {/* Projects Grid */}
        <AnimatePresence>
          {filteredProjects.length === 0 && !isLoading ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-16"
            >
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <FolderKanban className="h-8 w-8 text-slate-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-600">No projects found</h3>
                  <p className="text-slate-500 max-w-sm mx-auto mt-2 mb-6">
                    {searchTerm || filterStatus !== 'all' 
                      ? 'Try adjusting your search or filter criteria.'
                      : 'Get started by creating your first construction or engineering project.'
                    }
                  </p>
                  <Button 
                    onClick={() => setShowCreateDialog(true)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Your First Project
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            <motion.div 
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              {filteredProjects.map((project, index) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                >
                  <Card className="h-full bg-white/80 backdrop-blur-sm border-slate-200 hover:shadow-xl transition-all duration-300 group flex flex-col">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="space-y-2 flex-1 min-w-0">
                          <Link to={createPageUrl(`ProjectDetails?id=${project.id}`)} className="block">
                            <CardTitle className="text-lg group-hover:text-blue-700 transition-colors truncate">
                              {project.name}
                            </CardTitle>
                          </Link>
                          <div className="flex items-center gap-2 flex-wrap">
                            <Badge className={`${
                              project.priority === 'critical' ? 'bg-red-100 text-red-700' :
                              project.priority === 'high' ? 'bg-orange-100 text-orange-700' :
                              project.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                              'bg-slate-100 text-slate-600'
                            }`}>
                              {project.priority}
                            </Badge>
                             <Badge variant="outline" className={`${
                              project.status === 'active' ? 'border-green-300 bg-green-50 text-green-700' :
                              project.status === 'completed' ? 'border-blue-300 bg-blue-50 text-blue-700' :
                              project.status === 'on_hold' ? 'border-yellow-300 bg-yellow-50 text-yellow-700' :
                              'border-slate-300 bg-slate-50 text-slate-600'
                            }`}>
                              {project.status.replace('_', ' ').toUpperCase()}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => handleEditProject(project)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            className="w-8 h-8 text-red-600 hover:bg-red-100"
                            onClick={() => handleDeleteProject(project.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <CardDescription className="line-clamp-2 mt-2">{project.description}</CardDescription>
                    </CardHeader>

                    <CardContent className="space-y-4 flex-grow">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span className="font-semibold">{project.completion_percentage || 0}%</span>
                        </div>
                        <Progress value={project.completion_percentage || 0} className="h-2" />
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center space-x-2">
                          <Calendar className="h-4 w-4 text-slate-400" />
                          <div>
                            <span className="text-slate-500 block">End Date</span>
                            <p className="font-medium">
                              {project.end_date 
                                ? new Date(project.end_date).toLocaleDateString()
                                : 'Not set'
                              }
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <DollarSign className="h-4 w-4 text-slate-400" />
                          <div>
                            <span className="text-slate-500 block">Budget</span>
                            <p className="font-medium">
                              {project.budget ? `$${Number(project.budget).toLocaleString()}` : 'N/A'}
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    
                    <div className="p-4 pt-0">
                      <div className="flex space-x-2">
                         <Button asChild size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
                          <Link to={createPageUrl(`ProjectDetails?id=${project.id}`)}>
                            <Eye className="mr-2 h-3 w-3" />
                            View Details
                          </Link>
                        </Button>
                        <Button asChild size="sm" variant="outline">
                          <Link to={createPageUrl(`AIAssistant?projectId=${project.id}`)}>
                            <Bot className="mr-2 h-3 w-3" />
                            Jz-Agent
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
