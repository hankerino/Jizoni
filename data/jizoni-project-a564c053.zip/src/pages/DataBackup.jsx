import React, { useState } from "react";
import { exportAllData } from "@/api/functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Download, 
  Database, 
  FileJson,
  CheckCircle,
  Github,
  AlertCircle
} from "lucide-react";
import { motion } from "framer-motion";

export default function DataBackup() {
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [error, setError] = useState(null);

  const handleExport = async () => {
    setIsExporting(true);
    setExportSuccess(false);
    setError(null);

    try {
      const response = await exportAllData();
      
      if (response.status === 200) {
        // Get the blob data
        const blob = await response.data;
        
        // Create download link
        const url = window.URL.createObjectURL(new Blob([blob], { type: 'application/json' }));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `jizoni-project-data-${new Date().toISOString().split('T')[0]}.json`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.URL.revokeObjectURL(url);
        
        setExportSuccess(true);
        
        // Reset success message after 5 seconds
        setTimeout(() => setExportSuccess(false), 5000);
      } else {
        throw new Error('Export failed');
      }
    } catch (err) {
      console.error('Export error:', err);
      setError(err.message || 'Failed to export data');
    }
    
    setIsExporting(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3 mb-2">
            <Database className="w-8 h-8 text-blue-600" />
            Data Backup & Export
          </h1>
          <p className="text-slate-600">
            Export all your project data for backup or version control in GitHub.
          </p>
        </motion.div>

        {/* Export Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileJson className="w-5 h-5 text-green-600" />
                Full Database Export
              </CardTitle>
              <CardDescription>
                Export all entities including projects, tasks, resources, baselines, and more as a single JSON file.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* What's Included */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-blue-900 mb-3 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  What's Included:
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    'All Projects',
                    'All Tasks (WBS)',
                    'All Resources',
                    'All Baselines',
                    'Task Relationships',
                    'Resource Assignments',
                    'Calendars',
                    'Comments'
                  ].map((item, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm text-blue-800">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-600"></div>
                      {item}
                    </div>
                  ))}
                </div>
              </div>

              {/* Export Button */}
              <div className="flex flex-col items-center gap-4 py-4">
                <Button
                  onClick={handleExport}
                  disabled={isExporting}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 gap-2 px-8"
                >
                  {isExporting ? (
                    <>
                      <Download className="w-5 h-5 animate-bounce" />
                      Exporting...
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5" />
                      Export All Data
                    </>
                  )}
                </Button>

                {exportSuccess && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex items-center gap-2 text-green-700 bg-green-50 px-4 py-2 rounded-lg border border-green-200"
                  >
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-medium">Data exported successfully!</span>
                  </motion.div>
                )}

                {error && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex items-center gap-2 text-red-700 bg-red-50 px-4 py-2 rounded-lg border border-red-200"
                  >
                    <AlertCircle className="w-5 h-5" />
                    <span className="font-medium">{error}</span>
                  </motion.div>
                )}
              </div>

              {/* Instructions */}
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                  <Github className="w-4 h-4" />
                  How to Add to GitHub:
                </h3>
                <ol className="space-y-2 text-sm text-slate-700">
                  <li className="flex gap-2">
                    <Badge variant="outline" className="w-6 h-6 flex items-center justify-center flex-shrink-0">1</Badge>
                    <span>Click "Export All Data" to download the JSON file</span>
                  </li>
                  <li className="flex gap-2">
                    <Badge variant="outline" className="w-6 h-6 flex items-center justify-center flex-shrink-0">2</Badge>
                    <span>In your GitHub repo, create a folder called <code className="bg-slate-200 px-1 rounded">data/</code></span>
                  </li>
                  <li className="flex gap-2">
                    <Badge variant="outline" className="w-6 h-6 flex items-center justify-center flex-shrink-0">3</Badge>
                    <span>Move the downloaded file to the <code className="bg-slate-200 px-1 rounded">data/</code> folder</span>
                  </li>
                  <li className="flex gap-2">
                    <Badge variant="outline" className="w-6 h-6 flex items-center justify-center flex-shrink-0">4</Badge>
                    <span>Commit and push to GitHub: <code className="bg-slate-200 px-1 rounded">git add data/ && git commit -m "Add data backup" && git push</code></span>
                  </li>
                </ol>
              </div>

              {/* Info Note */}
              <div className="text-xs text-slate-500 text-center">
                💡 <strong>Pro Tip:</strong> Run this export regularly to maintain up-to-date backups of your project data.
                The exported file will be named with today's date for easy version tracking.
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-amber-50 border-amber-200">
            <CardContent className="p-4">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-amber-800">
                  <p className="font-medium mb-1">Important Notes:</p>
                  <ul className="space-y-1 list-disc list-inside">
                    <li>This exports a snapshot of your current data</li>
                    <li>The file includes all metadata (created dates, user info, etc.)</li>
                    <li>To restore data, you would need to re-import it manually or via API</li>
                    <li>GitHub is best for code versioning; consider cloud storage (S3, Google Drive) for large data backups</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}