
import React, { useState, useEffect } from "react";
import { Resource } from "@/api/entities";
import { Project } from "@/api/entities";
import { Task } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Users, 
  Plus, 
  Search, 
  Settings, 
  User, 
  Wrench, 
  Package,
  DollarSign,
  Edit,
  Trash2,
  Clock,
  FileBox, // New import
  Calendar // New import
} from "lucide-react";
import { motion } from "framer-motion";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"; // New import
import { Link } from "react-router-dom"; // New import

import ResourceForm from "../components/resources/ResourceForm";
import ResourceAssignmentButton from "../components/resources/ResourceAssignmentButton"; // New import, though not used in this snippet
import ResourceAssignment from "../components/resources/ResourceAssignment"; // New import

export default function Resources() {
  const [resources, setResources] = useState([]);
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  // Removed filterType state as tabs will manage type filtering
  const [showForm, setShowForm] = useState(false);
  const [editingResource, setEditingResource] = useState(null);
  const [showResourceAssignment, setShowResourceAssignment] = useState(false); // New state
  const [selectedTaskForAssignment, setSelectedTaskForAssignment] = useState(null); // New state
  const [selectedProjectId, setSelectedProjectId] = useState(null); // New state, needs to be populated if assignments are project-specific.

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [resourcesData, projectsData, tasksData] = await Promise.all([
        Resource.list("-updated_date"),
        Project.list("-updated_date"),
        Task.list("-updated_date", 200)
      ]);
      setResources(resourcesData || []);
      setProjects(projectsData || []);
      setTasks(tasksData || []);
      // Optionally set selectedProjectId to the first project's ID if available
      if (projectsData && projectsData.length > 0) {
        setSelectedProjectId(projectsData[0].id);
      }
    } catch (error) {
      console.error("Error loading data:", error);
      setResources([]);
      setProjects([]);
      setTasks([]);
    }
    setIsLoading(false);
  };

  const handleSave = async (resourceData) => {
    try {
      if (editingResource) {
        await Resource.update(editingResource.id, resourceData);
      } else {
        await Resource.create(resourceData);
      }
      setShowForm(false);
      setEditingResource(null);
      loadData();
    } catch (error) {
      console.error("Error saving resource:", error);
      alert("Failed to save resource. Please try again.");
    }
  };

  const handleEdit = (resource) => {
    setEditingResource(resource);
    setShowForm(true);
  };

  const handleDelete = async (resourceId) => {
    if (window.confirm("Are you sure you want to delete this resource?")) {
      try {
        await Resource.delete(resourceId);
        loadData();
      } catch (error) {
        console.error("Error deleting resource:", error);
        alert("Failed to delete resource. Please try again.");
      }
    }
  };

  const handleAddNew = () => {
    setEditingResource(null);
    setShowForm(true);
  };

  const handleResourceAssignmentClick = (task) => {
    setSelectedTaskForAssignment(task);
    setShowResourceAssignment(true);
  };

  const getResourceStats = () => {
    const totalMembers = resources.filter(r => r.type === 'person').length;
    const projectManagers = resources.filter(r => r.role && r.role.toLowerCase().includes('manager')).length;
    const teamMembers = totalMembers - projectManagers;
    
    // Calculate workloads
    const resourceWorkloads = resources.map(resource => {
      const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
      const activeTasks = assignedTasks.filter(task => 
        task.status === 'in_progress' || task.status === 'not_started'
      );
      const totalDays = activeTasks.reduce((sum, task) => sum + (task.duration_days || 0), 0);
      return { ...resource, workload: totalDays };
    });

    const avgWorkload = resourceWorkloads.length > 0 
      ? Math.round(resourceWorkloads.reduce((sum, r) => sum + r.workload, 0) / resourceWorkloads.length)
      : 0;
    
    const highWorkload = resourceWorkloads.filter(r => r.workload > 30).length;

    return {
      totalMembers: totalMembers || 0,
      projectManagers: projectManagers || 0,
      teamMembers: teamMembers || 0,
      avgWorkload: avgWorkload || 0,
      highWorkload: highWorkload || 0
    };
  };

  const getResourceIcon = (type) => {
    switch (type) {
      case 'person': return User;
      case 'equipment': return Wrench;
      case 'material': return Package;
      case 'cost': return DollarSign;
      default: return User;
    }
  };

  const getResourceWorkload = (resource) => {
    const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
    const activeTasks = assignedTasks.filter(task => 
      task.status === 'in_progress' || task.status === 'not_started'
    );
    return activeTasks.reduce((sum, task) => sum + (task.duration_days || 0), 0);
  };

  const getWorkloadColor = (workload) => {
    if (workload === 0) return "text-slate-500";
    if (workload <= 20) return "text-green-600";
    if (workload <= 40) return "text-yellow-600";
    return "text-red-600";
  };

  const getWorkloadStatus = (workload) => {
    if (workload === 0) return "Available";
    if (workload <= 20) return "Light";
    if (workload <= 40) return "Moderate";
    return "Overloaded";
  };

  const handleStatsCardClick = (cardType) => {
    switch (cardType) {
      case 'total_members':
        const totalMembers = resources.filter(r => r.type === 'person');
        alert(`Total Team Members: ${totalMembers.length}\n\nBreakdown:\n• People: ${totalMembers.length}\n• Equipment: ${resources.filter(r => r.type === 'equipment').length}\n• Materials: ${resources.filter(r => r.type === 'material').length}\n• Cost Resources: ${resources.filter(r => r.type === 'cost').length}\n\nClick to filter resources by type.`);
        break;
        
      case 'project_managers':
        const managers = resources.filter(r => r.role && r.role.toLowerCase().includes('manager'));
        const managerNames = managers.map(m => m.name).join(', ') || 'No managers assigned';
        alert(`Project Managers: ${managers.length}\n\nManagers:\n${managerNames}\n\nResponsible for overseeing project execution and team coordination.`);
        break;
        
      case 'team_members':
        const teamMembers = resources.filter(r => r.type === 'person' && (!r.role || !r.role.toLowerCase().includes('manager')));
        alert(`Team Members: ${teamMembers.length}\n\nActive Contributors:\n• Engineers: ${teamMembers.filter(r => r.role && r.role.toLowerCase().includes('engineer')).length}\n• Specialists: ${teamMembers.filter(r => r.role && !r.role.toLowerCase().includes('engineer') && !r.role.toLowerCase().includes('manager')).length}\n• Unassigned Role: ${teamMembers.filter(r => !r.role).length}\n\nClick to view detailed team roster.`);
        break;
        
      case 'avg_workload':
        const resourceWorkloads = resources.map(resource => {
          const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
          const activeTasks = assignedTasks.filter(task => task.status === 'in_progress' || task.status === 'not_started');
          return { name: resource.name, workload: activeTasks.reduce((sum, task) => sum + (task.duration_days || 0), 0) };
        });
        const avgWorkload = resourceWorkloads.length > 0 ? Math.round(resourceWorkloads.reduce((sum, r) => sum + r.workload, 0) / resourceWorkloads.length) : 0;
        const lightWorkload = resourceWorkloads.filter(r => r.workload > 0 && r.workload <= 20).length;
        const moderateWorkload = resourceWorkloads.filter(r => r.workload > 20 && r.workload <= 30).length;
        const heavyWorkload = resourceWorkloads.filter(r => r.workload > 30).length;
        const availableWorkload = resourceWorkloads.filter(r => r.workload === 0).length;

        alert(`Average Workload: ${avgWorkload} days\n\nWorkload Distribution:\n• Available (0 days): ${availableWorkload} resources\n• Light workload (1-20 days): ${lightWorkload} resources\n• Moderate workload (21-30 days): ${moderateWorkload} resources\n• Heavy workload (>30 days): ${heavyWorkload} resources\n\nClick to view detailed workload analysis.`);
        break;
        
      case 'high_workload':
        const overloadedResources = resources.filter(resource => {
          const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
          const activeTasks = assignedTasks.filter(task => task.status === 'in_progress' || task.status === 'not_started');
          const workload = activeTasks.reduce((sum, task) => sum + (task.duration_days || 0), 0);
          return workload > 30;
        });
        const overloadedNames = overloadedResources.map(r => `${r.name} (${getResourceWorkload(r)} days)`).join('\n') || 'No overloaded resources';
        alert(`High Workload Resources: ${overloadedResources.length}\n\nOverloaded (>30 days):\n${overloadedNames}\n\n⚠️ Consider redistributing tasks or adding resources to prevent burnout.`);
        break;
        
      default:
        break;
    }
  };

  // Helper function to get filtered resources based on tab and search term
  const getFilteredResources = (tabValue) => {
    let typeFilter = null;
    switch (tabValue) {
      case 'people': typeFilter = 'person'; break;
      case 'equipment': typeFilter = 'equipment'; break;
      case 'materials': typeFilter = 'material'; break;
      // 'overview' means all types, so typeFilter remains null
      case 'assignments': return []; // Assignments tab doesn't show resources
    }

    return resources.filter(resource => {
      const matchesSearch = resource.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           (resource.role || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                           (resource.email || '').toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesType = typeFilter === null || resource.type === typeFilter;
      
      return matchesSearch && matchesType;
    });
  };

  const stats = getResourceStats();

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <Users className="w-8 h-8 text-blue-600" />
              Jizoni Project Resources
            </h1>
            <p className="text-slate-600 mt-1">Manage team members, equipment, and resource allocation</p>
          </div>
          <Button onClick={handleAddNew} className="bg-blue-600 hover:bg-blue-700 gap-2">
            <Plus className="w-4 h-4" />
            Add Member
          </Button>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <Card 
            className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0 cursor-pointer hover:shadow-xl hover:scale-105 transition-all duration-300"
            onClick={() => handleStatsCardClick('total_members')}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-blue-100 text-xs font-medium">Total Members</p>
                  <h3 className="text-2xl font-bold">{stats.totalMembers}</h3>
                </div>
                <Users className="w-5 h-5 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card 
            className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0 cursor-pointer hover:shadow-xl hover:scale-105 transition-all duration-300"
            onClick={() => handleStatsCardClick('project_managers')}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-green-100 text-xs font-medium">Project Managers</p>
                  <h3 className="text-2xl font-bold">{stats.projectManagers}</h3>
                </div>
                <Settings className="w-5 h-5 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card 
            className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0 cursor-pointer hover:shadow-xl hover:scale-105 transition-all duration-300"
            onClick={() => handleStatsCardClick('team_members')}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-purple-100 text-xs font-medium">Team Members</p>
                  <h3 className="text-2xl font-bold">{stats.teamMembers}</h3>
                </div>
                <User className="w-5 h-5 text-purple-200" />
              </div>
            </CardContent>
          </Card>

          <Card 
            className="bg-gradient-to-r from-orange-500 to-orange-600 text-white border-0 cursor-pointer hover:shadow-xl hover:scale-105 transition-all duration-300"
            onClick={() => handleStatsCardClick('avg_workload')}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-orange-100 text-xs font-medium">Avg Workload</p>
                  <h3 className="text-2xl font-bold">{stats.avgWorkload}d</h3>
                </div>
                <Clock className="w-5 h-5 text-orange-200" />
              </div>
            </CardContent>
          </Card>

          <Card 
            className="bg-gradient-to-r from-red-500 to-red-600 text-white border-0 cursor-pointer hover:shadow-xl hover:scale-105 transition-all duration-300"
            onClick={() => handleStatsCardClick('high_workload')}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-red-100 text-xs font-medium">High Workload</p>
                  <h3 className="text-2xl font-bold">{stats.highWorkload}</h3>
                </div>
                <Badge className="bg-red-700 text-red-100">High</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search - Moved inside each tab content for relevant resource displays */}
        
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">
              Overview
              <Badge variant="secondary" className="ml-1 bg-blue-100 text-blue-700">{resources.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="people">
              People
              <Badge variant="secondary" className="ml-1 bg-purple-100 text-purple-700">{resources.filter(r => r.type === 'person').length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="equipment">
              Equipment
              <Badge variant="secondary" className="ml-1 bg-orange-100 text-orange-700">{resources.filter(r => r.type === 'equipment').length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="materials">
              Materials
              <Badge variant="secondary" className="ml-1 bg-green-100 text-green-700">{resources.filter(r => r.type === 'material').length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="assignments">Assignments</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between mb-6"
            >
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search resources..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white/80 backdrop-blur-sm border-slate-200"
                />
              </div>
            </motion.div>
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardHeader>
                <CardTitle>All Resources</CardTitle>
                <p className="text-sm text-slate-600">
                  {getFilteredResources('overview').length} resources found
                  {searchTerm && ` matching "${searchTerm}"`}
                </p>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array(6).fill(0).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="bg-slate-200 rounded-lg h-32"></div>
                      </div>
                    ))}
                  </div>
                ) : getFilteredResources('overview').length > 0 ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {getFilteredResources('overview').map((resource, index) => {
                      const IconComponent = getResourceIcon(resource.type);
                      const workload = getResourceWorkload(resource);
                      const workloadColor = getWorkloadColor(workload);
                      const workloadStatus = getWorkloadStatus(workload);
                      const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
                      const projectsCount = new Set(assignedTasks.map(task => task.project_id)).size;

                      return (
                        <motion.div
                          key={resource.id}
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.05 }}
                          className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-lg transition-shadow group"
                        >
                          <div className="flex justify-between items-start mb-3">
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                                resource.type === 'person' ? 'bg-blue-100' :
                                resource.type === 'equipment' ? 'bg-orange-100' :
                                resource.type === 'material' ? 'bg-green-100' :
                                'bg-purple-100'
                              }`}>
                                <IconComponent className={`w-5 h-5 ${
                                  resource.type === 'person' ? 'text-blue-600' :
                                  resource.type === 'equipment' ? 'text-orange-600' :
                                  resource.type === 'material' ? 'text-green-600' :
                                  'text-purple-600'
                                }`} />
                              </div>
                              <div>
                                <h4 className="font-semibold text-slate-900">{resource.name}</h4>
                                <div className="flex items-center gap-2">
                                  <p className="text-sm text-slate-600">{resource.role || resource.type}</p>
                                  <Badge 
                                    variant="outline" 
                                    className={`text-xs ${
                                      resource.type === 'person' ? 'border-blue-200 text-blue-700' :
                                      resource.type === 'equipment' ? 'border-orange-200 text-orange-700' :
                                      resource.type === 'material' ? 'border-green-200 text-green-700' :
                                      'border-purple-200 text-purple-700'
                                    }`}
                                  >
                                    {resource.type}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                            <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => handleEdit(resource)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon"
                                className="w-8 h-8 text-red-600 hover:bg-red-100"
                                onClick={() => handleDelete(resource.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>

                          {resource.email && (
                            <p className="text-sm text-slate-500 mb-3">{resource.email}</p>
                          )}

                          {resource.type === 'person' && (
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="text-slate-600">Current Workload</span>
                                <span className={`font-medium ${workloadColor}`}>{workload} days</span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span className="text-slate-600">Status</span>
                                <Badge variant={workload > 40 ? "destructive" : workload > 20 ? "secondary" : "default"}>
                                  {workloadStatus}
                                </Badge>
                              </div>
                            </div>
                          )}

                          <div className="grid grid-cols-3 gap-4 mt-4 text-center text-sm">
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">{projectsCount}</div>
                              <div className="text-slate-600">Projects</div>
                            </div>
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">{assignedTasks.length}</div>
                              <div className="text-slate-600">Tasks</div>
                            </div>
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">
                                {resource.type === 'person' 
                                  ? assignedTasks.filter(t => t.status === 'in_progress').length
                                  : resource.max_units || 100
                                }
                              </div>
                              <div className="text-slate-600">
                                {resource.type === 'person' ? 'Active' : 'Units'}
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-slate-600 mb-2">
                      No resources found
                    </h3>
                    <p className="text-slate-500 mb-4">
                      {searchTerm ? 'Try adjusting your search criteria.' : 'Add your first resource to get started.'}
                    </p>
                    <Button onClick={handleAddNew} className="bg-blue-600 hover:bg-blue-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Resource
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="people">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between mb-6"
            >
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search people..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white/80 backdrop-blur-sm border-slate-200"
                />
              </div>
            </motion.div>
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardHeader>
                <CardTitle>People Resources</CardTitle>
                <p className="text-sm text-slate-600">
                  {getFilteredResources('people').length} people found
                  {searchTerm && ` matching "${searchTerm}"`}
                </p>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array(3).fill(0).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="bg-slate-200 rounded-lg h-32"></div>
                      </div>
                    ))}
                  </div>
                ) : getFilteredResources('people').length > 0 ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {getFilteredResources('people').map((resource, index) => {
                      const IconComponent = getResourceIcon(resource.type);
                      const workload = getResourceWorkload(resource);
                      const workloadColor = getWorkloadColor(workload);
                      const workloadStatus = getWorkloadStatus(workload);
                      const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
                      const projectsCount = new Set(assignedTasks.map(task => task.project_id)).size;

                      return (
                        <motion.div
                          key={resource.id}
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.05 }}
                          className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-lg transition-shadow group"
                        >
                          <div className="flex justify-between items-start mb-3">
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                                resource.type === 'person' ? 'bg-blue-100' :
                                'bg-purple-100' // Should always be person for this tab
                              }`}>
                                <IconComponent className={`w-5 h-5 ${
                                  resource.type === 'person' ? 'text-blue-600' :
                                  'text-purple-600' // Should always be person for this tab
                                }`} />
                              </div>
                              <div>
                                <h4 className="font-semibold text-slate-900">{resource.name}</h4>
                                <div className="flex items-center gap-2">
                                  <p className="text-sm text-slate-600">{resource.role || resource.type}</p>
                                  <Badge 
                                    variant="outline" 
                                    className={`text-xs ${
                                      resource.type === 'person' ? 'border-blue-200 text-blue-700' :
                                      'border-purple-200 text-purple-700'
                                    }`}
                                  >
                                    {resource.type}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                            <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => handleEdit(resource)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon"
                                className="w-8 h-8 text-red-600 hover:bg-red-100"
                                onClick={() => handleDelete(resource.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>

                          {resource.email && (
                            <p className="text-sm text-slate-500 mb-3">{resource.email}</p>
                          )}

                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-slate-600">Current Workload</span>
                              <span className={`font-medium ${workloadColor}`}>{workload} days</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-slate-600">Status</span>
                              <Badge variant={workload > 40 ? "destructive" : workload > 20 ? "secondary" : "default"}>
                                {workloadStatus}
                              </Badge>
                            </div>
                          </div>

                          <div className="grid grid-cols-3 gap-4 mt-4 text-center text-sm">
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">{projectsCount}</div>
                              <div className="text-slate-600">Projects</div>
                            </div>
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">{assignedTasks.length}</div>
                              <div className="text-slate-600">Tasks</div>
                            </div>
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">
                                {assignedTasks.filter(t => t.status === 'in_progress').length}
                              </div>
                              <div className="text-slate-600">Active</div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-slate-600 mb-2">
                      No people resources found
                    </h3>
                    <p className="text-slate-500 mb-4">
                      {searchTerm ? 'Try adjusting your search criteria.' : 'Add your first team member to get started.'}
                    </p>
                    <Button onClick={handleAddNew} className="bg-blue-600 hover:bg-blue-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Person
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="equipment">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between mb-6"
            >
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search equipment..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white/80 backdrop-blur-sm border-slate-200"
                />
              </div>
            </motion.div>
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardHeader>
                <CardTitle>Equipment Resources</CardTitle>
                <p className="text-sm text-slate-600">
                  {getFilteredResources('equipment').length} equipment found
                  {searchTerm && ` matching "${searchTerm}"`}
                </p>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array(3).fill(0).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="bg-slate-200 rounded-lg h-32"></div>
                      </div>
                    ))}
                  </div>
                ) : getFilteredResources('equipment').length > 0 ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {getFilteredResources('equipment').map((resource, index) => {
                      const IconComponent = getResourceIcon(resource.type);
                      const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
                      const projectsCount = new Set(assignedTasks.map(task => task.project_id)).size;

                      return (
                        <motion.div
                          key={resource.id}
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.05 }}
                          className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-lg transition-shadow group"
                        >
                          <div className="flex justify-between items-start mb-3">
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                                resource.type === 'equipment' ? 'bg-orange-100' : 'bg-purple-100'
                              }`}>
                                <IconComponent className={`w-5 h-5 ${
                                  resource.type === 'equipment' ? 'text-orange-600' : 'text-purple-600'
                                }`} />
                              </div>
                              <div>
                                <h4 className="font-semibold text-slate-900">{resource.name}</h4>
                                <div className="flex items-center gap-2">
                                  <p className="text-sm text-slate-600">{resource.role || resource.type}</p>
                                  <Badge 
                                    variant="outline" 
                                    className={`text-xs ${
                                      resource.type === 'equipment' ? 'border-orange-200 text-orange-700' : 'border-purple-200 text-purple-700'
                                    }`}
                                  >
                                    {resource.type}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                            <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => handleEdit(resource)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon"
                                className="w-8 h-8 text-red-600 hover:bg-red-100"
                                onClick={() => handleDelete(resource.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>

                          {resource.email && (
                            <p className="text-sm text-slate-500 mb-3">{resource.email}</p>
                          )}
                          
                          <div className="grid grid-cols-3 gap-4 mt-4 text-center text-sm">
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">{projectsCount}</div>
                              <div className="text-slate-600">Projects</div>
                            </div>
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">{assignedTasks.length}</div>
                              <div className="text-slate-600">Tasks</div>
                            </div>
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">
                                {resource.max_units || 100}
                              </div>
                              <div className="text-slate-600">Units</div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Wrench className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-slate-600 mb-2">
                      No equipment resources found
                    </h3>
                    <p className="text-slate-500 mb-4">
                      {searchTerm ? 'Try adjusting your search criteria.' : 'Add your first equipment resource.'}
                    </p>
                    <Button onClick={handleAddNew} className="bg-blue-600 hover:bg-blue-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Equipment
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="materials">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between mb-6"
            >
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Search materials..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white/80 backdrop-blur-sm border-slate-200"
                />
              </div>
            </motion.div>
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardHeader>
                <CardTitle>Material Resources</CardTitle>
                <p className="text-sm text-slate-600">
                  {getFilteredResources('materials').length} materials found
                  {searchTerm && ` matching "${searchTerm}"`}
                </p>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array(3).fill(0).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="bg-slate-200 rounded-lg h-32"></div>
                      </div>
                    ))}
                  </div>
                ) : getFilteredResources('materials').length > 0 ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {getFilteredResources('materials').map((resource, index) => {
                      const IconComponent = getResourceIcon(resource.type);
                      const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
                      const projectsCount = new Set(assignedTasks.map(task => task.project_id)).size;

                      return (
                        <motion.div
                          key={resource.id}
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.05 }}
                          className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-lg transition-shadow group"
                        >
                          <div className="flex justify-between items-start mb-3">
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                                resource.type === 'material' ? 'bg-green-100' : 'bg-purple-100'
                              }`}>
                                <IconComponent className={`w-5 h-5 ${
                                  resource.type === 'material' ? 'text-green-600' : 'text-purple-600'
                                }`} />
                              </div>
                              <div>
                                <h4 className="font-semibold text-slate-900">{resource.name}</h4>
                                <div className="flex items-center gap-2">
                                  <p className="text-sm text-slate-600">{resource.role || resource.type}</p>
                                  <Badge 
                                    variant="outline" 
                                    className={`text-xs ${
                                      resource.type === 'material' ? 'border-green-200 text-green-700' : 'border-purple-200 text-purple-700'
                                    }`}
                                  >
                                    {resource.type}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                            <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => handleEdit(resource)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon"
                                className="w-8 h-8 text-red-600 hover:bg-red-100"
                                onClick={() => handleDelete(resource.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>

                          {resource.email && (
                            <p className="text-sm text-slate-500 mb-3">{resource.email}</p>
                          )}
                          
                          <div className="grid grid-cols-3 gap-4 mt-4 text-center text-sm">
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">{projectsCount}</div>
                              <div className="text-slate-600">Projects</div>
                            </div>
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">{assignedTasks.length}</div>
                              <div className="text-slate-600">Tasks</div>
                            </div>
                            <div className="p-2 bg-slate-50 rounded">
                              <div className="font-semibold text-slate-900">
                                {resource.max_units || 100}
                              </div>
                              <div className="text-slate-600">Units</div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-slate-600 mb-2">
                      No material resources found
                    </h3>
                    <p className="text-slate-500 mb-4">
                      {searchTerm ? 'Try adjusting your search criteria.' : 'Add your first material resource.'}
                    </p>
                    <Button onClick={handleAddNew} className="bg-blue-600 hover:bg-blue-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Material
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="assignments">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-green-600" />
                  Resource Assignment Center
                  <Badge className="bg-green-100 text-green-700">
                    Manage Task Assignments
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-600 mb-2">Resource Assignment Center</h3>
                  <p className="text-slate-500 mb-4">
                    Go to the <strong>WBS Editor</strong> or <strong>Scheduling</strong> page to assign resources to specific tasks.
                  </p>
                  <div className="flex gap-3 justify-center">
                    <Link to="/wbs-editor"> {/* Replaced createPageUrl */}
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        <FileBox className="w-4 h-4 mr-2" />
                        Go to WBS Editor
                      </Button>
                    </Link>
                    <Link to="/scheduling"> {/* Replaced createPageUrl */}
                      <Button variant="outline">
                        <Calendar className="w-4 h-4 mr-2" />
                        Go to Scheduling
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Resource Form Dialog */}
        <ResourceForm 
          open={showForm}
          onOpenChange={setShowForm}
          resource={editingResource}
          onSave={handleSave}
          projects={projects}
        />

        {/* Resource Assignment Dialog */}
        <ResourceAssignment
          selectedTask={selectedTaskForAssignment}
          projectId={selectedProjectId} // This will be null initially or set by first project. Adjust as needed.
          isOpen={showResourceAssignment}
          onClose={() => {
            setShowResourceAssignment(false);
            setSelectedTaskForAssignment(null);
          }}
          onAssignmentUpdate={(taskId, assignments) => {
            console.log('Resource assignments updated:', taskId, assignments);
            // Refresh data as needed, e.g., loadData() if task assignments affect resource stats/workload
          }}
        />
      </div>
    </div>
  );
}
