import React, { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import { Project } from "@/api/entities";
import { Task } from "@/api/entities";
import { claudeAI } from "@/api/functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import {
  Bot,
  Send,
  Lightbulb,
  AlertTriangle,
  TrendingUp,
  Clock,
  Users,
  Target,
  Zap,
  MessageCircle,
  HardHat,
  Brain,
  Network,
  Settings,
  Sparkles,
  FlaskConical
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function AIAssistant() {
  const [projects, setProjects] = useState([]);
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [systemPrompt, setSystemPrompt] = useState(`You are Jz-Agent, an AI assistant specialized in engineering and construction project management. You operate based on the following professional project scheduling protocols:

### PHASE 1: PRIOR TO START
- **Understand Scope:** Fully grasp the project scope, including relationships (Client, Contractor, Sub-Contractor), engineering/construction methods, and all deliverables.
- **Division of Responsibility (DOR):** Clearly identify the DOR for the complete project, including physical boundaries (Onshore, Offshore, Sub-sea) and quality/errors/omissions.
- **Risk Management:** Understand the assigned risk ownership (Owner, Contractor, Sub-Contractor).
- **Subcontracts & Equipment:** Identify all necessary subcontracts and long-lead equipment (Purchase or Lease).
- **Governing Codes:** Identify all governing codes and specifications.

### PHASE 2: ESTABLISH THE LOGIC
- **Interactive Planning:** Use methods like IAP (Interactive Planning) to determine predecessors and successors.
- **Forward Pass:** Plan the schedule forward with agreed-upon durations.
- **Optimization:** Identify opportunities for task overlap (fast-tracking) across disciplines (engineering, procurement, construction, commissioning).
- **Milestones & Contingency:** Identify hold/inspection/approval milestones and agree on contingency.
- **Baselining:** The final, approved schedule becomes the baseline for change management.
- **Schedule Structure:** Suggest separate, integrated schedules for Engineering, Procurement,Construction, Testing, and Commissioning, all rolling up to a master schedule.
- **Resource Loading & Reporting:** Ensure the schedule is resource-loaded and that tracking/review/report cycles are selected.

### DETAILED PROJECT COMPONENTS BREAKDOWN
**Engineering**
- Process Flow
- Project design criteria
- Raw material storage
- Conveyance (Material handling)
- Molten Capacities
- Environmental Protection-Scrubbers- Waste mgmt
- Output forming/cooling
- Output Storage (Standard Structural Shapes, rolled plate, pipe)

**Civil**
- Specifications
- Topography
- Drainage
- Site Grading
- Underground Utilities- Electrical Duct banks, Firewater Piping, Trenching, and grounding.

**Architectural**
- Building Specifications
- Design/Permit

**Mechanical Equipment**
- Equipment Specifications
- Equipment Lists
- Equipment Selections
- Equipment Layouts

**Electrical**
- Load List
- Power Source
- One Line Diagrams
- Electrical Equipment
- Layout and design

**Piping**
- Piping Specifications
- Process and Instrument Diagrams
- Material Specifications
- Utility Scope- Air/Water/Nitrogen
- Cooling Water
- Process support of Environmental piping requirements.
- Layout and design

**Structural**
- Structural Specifications
- Equipment / Piping/Electrical Support systems
- Foundation designs/calculations
- Layout and Design

**Procurement**
- ID long lead items for each discipline

**Construction**
- Establish Prime and Subcontractors
- ID equipment needed for Civil site prep
- ID equipment for erection of purchased equipment and Structural Steel
- Establish layout of site conditions determine:
  - Site Construction facilities
  - Equipment laydown area
  - Material laydown area
  - Craft facilities including transportation
  - Temporary power capabilities
- Construction Sequences
- Testing and acceptance criteria
- Post construction site restoration.

Your advice must always be detailed, technical, and actionable, reflecting these industry-standard protocols and component breakdowns.`);
  const [temperature, setTemperature] = useState([0.7]);
  const [maxTokens, setMaxTokens] = useState([4000]);
  
  const messagesEndRef = useRef(null);
  const location = useLocation();

  const loadProjects = useCallback(async (initialProjectId) => {
    try {
      const data = await Project.list("-updated_date");
      setProjects(data);
      if (!initialProjectId && data.length > 0) {
        setSelectedProjectId(data[0].id);
      }
    } catch (error) {
      console.error("Error loading projects:", error);
    }
  }, []);

  const addWelcomeMessage = useCallback(() => {
    setMessages([{
      id: Date.now(),
      type: 'assistant',
      content: `Hello! I'm **Jz-Agent**, your advanced AI assistant powered by Claude Sonnet. I specialize in engineering and construction project management. I can help with project planning, risk analysis, technical questions, and much more. Select a project to get started, or ask me anything!`,
    }]);
  }, []);
  
  const addContextMessage = useCallback(() => {
    const project = projects.find(p => p.id === selectedProjectId);
    if(project){
       setMessages(prev => [...prev, {
          id: Date.now(),
          type: 'system',
          content: `Context set to project: **${project.name}** (${project.project_type}). I now have access to your project details.`,
        }]);
    }
  }, [projects, selectedProjectId]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const projectIdFromUrl = params.get('projectId');
    if (projectIdFromUrl) {
      setSelectedProjectId(projectIdFromUrl);
    }
    loadProjects(projectIdFromUrl);
    addWelcomeMessage();
  }, [location.search, loadProjects, addWelcomeMessage]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  useEffect(() => {
    if(selectedProjectId){
      addContextMessage();
    }
  }, [selectedProjectId, addContextMessage]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const sendMessage = async (messageContent) => {
    const currentMessage = messageContent || inputMessage;
    if (!currentMessage.trim()) return;

    const userMessage = { id: Date.now(), type: 'user', content: currentMessage };
    setMessages(prev => [...prev, userMessage]);
    
    if (!messageContent) {
        setInputMessage("");
    }
    
    setIsLoading(true);

    try {
      let contextData = "";
      if (selectedProjectId) {
        const project = projects.find(p => p.id === selectedProjectId);
        if (project) { // Ensure project is found before accessing its properties
            const tasks = await Task.filter({ project_id: selectedProjectId }, "wbs_code");
            contextData = `Project Context: 
            - Name: ${project.name}
            - Type: ${project.project_type}
            - Status: ${project.status}
            - Priority: ${project.priority}
            - Budget: $${project.budget?.toLocaleString() || 'Not set'}
            - Team Size: ${project.team_size} members
            - Progress: ${project.completion_percentage || 0}%
            - Tasks: ${tasks.length} total tasks
            - Description: ${project.description || 'No description'}
            `;
        }
      }
      
      const fullPrompt = `User Question: ${currentMessage}\n\n${contextData}`;

      const { data } = await claudeAI({
        prompt: fullPrompt,
        system_prompt: systemPrompt,
        temperature: temperature[0],
        max_tokens: maxTokens[0]
      });

      if (!data || !data.response) {
        throw new Error("Received an empty or invalid response from the AI.");
      }

      const assistantMessage = { 
        id: Date.now() + 1, 
        type: 'assistant', 
        content: data.response,
        usage: data.usage,
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error sending message:", error);
      let detailMessage = error.message;

      if (error.response?.data) {
          const errorData = error.response.data;
          detailMessage = errorData.error || JSON.stringify(errorData);
          if (errorData.details) {
              try {
                  const nestedDetails = JSON.parse(errorData.details);
                  if (nestedDetails.error?.message) {
                      detailMessage = nestedDetails.error.message;
                  } else {
                      detailMessage += ` | Details: ${errorData.details}`;
                  }
              } catch (e) {
                  detailMessage += ` | Details: ${errorData.details}`;
              }
          }
      } else if (error.response) {
          detailMessage = `API Error: Status ${error.response.status} - ${error.response.statusText || 'Unknown error'}`;
      }
      
      const errorMessage = { 
        id: Date.now() + 1, 
        type: 'assistant', 
        content: `**Error:** An issue occurred while contacting the AI. Please try again.\n\n**Details:**\n\`\`\`\n${detailMessage}\n\`\`\``
      };
      setMessages(prev => [...prev, errorMessage]);
    }
    setIsLoading(false);
  };

  const quickPrompts = [
    "Analyze the critical path and potential bottlenecks in my project schedule",
    "What are the top 5 risks for this construction project and how should I mitigate them?",
    "Create a comprehensive safety checklist based on OSHA standards for this project type",
    "Suggest ways to optimize resource allocation and reduce project costs",
    "How can I accelerate this project timeline without compromising quality?",
    "Generate a stakeholder communication plan for this project",
  ];

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-8"
        >
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <Bot className="w-8 h-8 text-purple-600" />
              Jz-Agent
            </h1>
            <p className="text-slate-600 mt-1">Advanced AI-powered guidance for your engineering projects, powered by Claude.</p>
          </div>
          <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
            <SelectTrigger className="w-full lg:w-80">
              <SelectValue placeholder="Select project for context" />
            </SelectTrigger>
            <SelectContent>
              {projects.map(project => (
                <SelectItem key={project.id} value={project.id}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </motion.div>

        <div className="grid lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            <Tabs defaultValue="chat" className="space-y-6">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="chat" className="gap-2">
                  <MessageCircle className="w-4 h-4" />
                  Chat with Jz-Agent
                </TabsTrigger>
                <TabsTrigger value="settings" className="gap-2">
                  <Settings className="w-4 h-4" />
                  AI Settings
                </TabsTrigger>
              </TabsList>

              <TabsContent value="chat">
                <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
                  <CardContent className="p-4">
                    <div className="h-[60vh] overflow-y-auto mb-4 space-y-4 p-4 bg-slate-50 rounded-lg">
                      <AnimatePresence>
                        {messages.map((message) => (
                          <motion.div
                            key={message.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className={`flex ${message.type === 'user' ? 'justify-end' : message.type === 'system' ? 'justify-center' : 'justify-start'}`}
                          >
                           {message.type === 'system' ? (
                              <Badge variant="secondary" className="text-center">{message.content}</Badge>
                            ) : (
                              <div className={`max-w-[85%] p-4 rounded-lg ${
                                message.type === 'user' 
                                  ? 'bg-purple-600 text-white' 
                                  : 'bg-white border border-slate-200 shadow-sm'
                              }`}>
                                <ReactMarkdown className="prose prose-sm max-w-none prose-p:my-0">
                                  {message.content || ""}
                                </ReactMarkdown>
                                {message.usage && (
                                  <div className="mt-2 pt-2 border-t border-slate-200 text-xs text-slate-500">
                                    Tokens: {message.usage.input_tokens} in, {message.usage.output_tokens} out
                                  </div>
                                )}
                              </div>
                            )}
                          </motion.div>
                        ))}
                      </AnimatePresence>
                      {isLoading && (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                          <div className="bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
                            <div className="flex items-center gap-2 text-slate-500">
                              <Sparkles className="animate-spin h-4 w-4 text-purple-600" />
                              Claude is thinking...
                            </div>
                          </div>
                        </motion.div>
                      )}
                      <div ref={messagesEndRef} />
                    </div>
                    
                    <div className="mb-4">
                      <p className="text-sm text-slate-600 mb-2">Quick Prompts:</p>
                      <div className="flex flex-wrap gap-2">
                        {quickPrompts.map((prompt, index) => (
                          <Button 
                            key={index} 
                            variant="outline" 
                            size="sm" 
                            onClick={() => setInputMessage(prompt)}
                            className="text-xs h-8"
                          >
                            {prompt.length > 50 ? `${prompt.substring(0, 50)}...` : prompt}
                          </Button>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Input
                        value={inputMessage}
                        onChange={(e) => setInputMessage(e.target.value)}
                        placeholder="Ask Jz-Agent about your project..."
                        onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                        disabled={isLoading}
                        className="flex-1"
                      />
                      <Button 
                        onClick={() => sendMessage()} 
                        disabled={isLoading || !inputMessage.trim()}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="settings">
                <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="w-5 h-5 text-purple-600" />
                      Jz-Agent Configuration
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="system-prompt">System Prompt</Label>
                      <Textarea
                        id="system-prompt"
                        value={systemPrompt}
                        onChange={(e) => setSystemPrompt(e.target.value)}
                        placeholder="Define Claude's role and expertise..."
                        rows={4}
                        className="font-mono text-sm"
                      />
                      <p className="text-xs text-slate-500">
                        This defines the AI's personality and expertise area. Be specific about your domain.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label>Temperature: {temperature[0]}</Label>
                      <Slider
                        value={temperature}
                        onValueChange={setTemperature}
                        max={1}
                        min={0}
                        step={0.1}
                        className="w-full"
                      />
                      <p className="text-xs text-slate-500">
                        Lower values (0.1-0.3) for focused, consistent responses. Higher values (0.7-1.0) for creative, varied responses.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label>Max Tokens: {maxTokens[0]}</Label>
                      <Slider
                        value={maxTokens}
                        onValueChange={setMaxTokens}
                        max={8000}
                        min={500}
                        step={500}
                        className="w-full"
                      />
                      <p className="text-xs text-slate-500">
                        Maximum length of the AI's responses. Higher values allow for more detailed answers but cost more.
                      </p>
                    </div>

                    <div className="grid grid-cols-3 gap-4 p-4 bg-slate-50 rounded-lg">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">Claude 3.5</div>
                        <div className="text-sm text-slate-600">Sonnet Model</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">Fast</div>
                        <div className="text-sm text-slate-600">Response Time</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">200K</div>
                        <div className="text-sm text-slate-600">Context Window</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardHeader>
                <CardTitle className="text-base">Project Context</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedProjectId && projects.find(p => p.id === selectedProjectId) ? (
                    <div className="space-y-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-600">Project:</span>
                          <span className="font-medium text-right truncate max-w-32">
                            {projects.find(p => p.id === selectedProjectId)?.name}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Type:</span>
                          <Badge variant="outline">
                            {projects.find(p => p.id === selectedProjectId)?.project_type}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Status:</span>
                          <Badge variant="outline">
                            {projects.find(p => p.id === selectedProjectId)?.status}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-600">Progress:</span>
                          <span className="font-medium">
                            {projects.find(p => p.id === selectedProjectId)?.completion_percentage || 0}%
                          </span>
                        </div>
                    </div>
                ): (
                  <p className="text-sm text-slate-500">Select a project to provide context to the AI.</p>
                )}
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardHeader>
                <CardTitle className="text-base">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2" 
                  onClick={() => sendMessage("Analyze my project schedule for bottlenecks and delays.")}
                  disabled={!selectedProjectId || isLoading}
                >
                  <Clock className="w-4 h-4" />
                  Analyze Schedule
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2" 
                  onClick={() => sendMessage("What are the biggest risks in my project and how can I mitigate them?")}
                  disabled={!selectedProjectId || isLoading}
                >
                  <AlertTriangle className="w-4 h-4" />
                  Assess Risks
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2" 
                  onClick={() => sendMessage("How can I optimize resource allocation to improve efficiency?")}
                  disabled={!selectedProjectId || isLoading}
                >
                  <Users className="w-4 h-4" />
                  Optimize Resources
                </Button>
                 <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2 border-blue-500 text-blue-700 hover:bg-blue-50 hover:text-blue-800"
                  onClick={() => sendMessage("Generate a pre-construction checklist for the civil engineering phase, specifically focusing on underground utilities as per my project standards.")}
                  disabled={isLoading}
                >
                  <FlaskConical className="w-4 h-4" />
                  Test Civil Knowledge
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Brain className="w-5 h-5 text-purple-500" />
                  AI Specialties
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-center gap-2">
                  <HardHat className="w-4 h-4 text-orange-500" />
                  <span>Construction Management</span>
                </div>
                <div className="flex items-center gap-2">
                  <Network className="w-4 h-4 text-blue-500" />
                  <span>Project Planning & WBS</span>
                </div>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                  <span>Risk Assessment</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-green-500" />
                  <span>Resource Optimization</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-purple-500" />
                  <span>Schedule Analysis</span>
                </div>
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-indigo-500" />
                  <span>Quality Assurance</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
              <CardContent className="p-4 text-center">
                <Sparkles className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                <h3 className="font-semibold text-purple-800 mb-1">Jz-Agent</h3>
                <p className="text-xs text-purple-700">
                  Advanced AI reasoning and problem-solving for engineering projects, powered by Claude 3.5 Sonnet
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}