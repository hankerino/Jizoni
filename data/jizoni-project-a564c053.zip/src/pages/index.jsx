import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Projects from "./Projects";

import WBSEditor from "./WBSEditor";

import AIAssistant from "./AIAssistant";

import Reports from "./Reports";

import Resources from "./Resources";

import Scheduling from "./Scheduling";

import ProjectDetails from "./ProjectDetails";

import scheduling from "./scheduling";

import ClaudeAssistant from "./ClaudeAssistant";

import DataBackup from "./DataBackup";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Projects: Projects,
    
    WBSEditor: WBSEditor,
    
    AIAssistant: AIAssistant,
    
    Reports: Reports,
    
    Resources: Resources,
    
    Scheduling: Scheduling,
    
    ProjectDetails: ProjectDetails,
    
    scheduling: scheduling,
    
    ClaudeAssistant: ClaudeAssistant,
    
    DataBackup: DataBackup,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Projects" element={<Projects />} />
                
                <Route path="/WBSEditor" element={<WBSEditor />} />
                
                <Route path="/AIAssistant" element={<AIAssistant />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/Resources" element={<Resources />} />
                
                <Route path="/Scheduling" element={<Scheduling />} />
                
                <Route path="/ProjectDetails" element={<ProjectDetails />} />
                
                <Route path="/scheduling" element={<scheduling />} />
                
                <Route path="/ClaudeAssistant" element={<ClaudeAssistant />} />
                
                <Route path="/DataBackup" element={<DataBackup />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}