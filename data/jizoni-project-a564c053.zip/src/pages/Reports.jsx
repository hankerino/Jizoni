
import React, { useState, useEffect } from "react";
import { Project } from "@/api/entities";
import { Task } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge"; // Kept as it's used in the component
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart3,
  Download,
  Target, // Kept as it's used in the component
  TrendingUp,
  FileText,
} from "lucide-react";
import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPieChart, Cell } from 'recharts';
import { Pie } from "recharts";

export default function Reports() {
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [projectsData, tasksData] = await Promise.all([
        Project.list("-updated_date"),
        Task.list("-updated_date", 1000)
      ]);
      setProjects(projectsData);
      setTasks(tasksData);
      if (projectsData.length > 0 && !selectedProjectId) {
        setSelectedProjectId("all");
      }
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  };

  const getProjectStats = () => {
    const filteredProjects = selectedProjectId === "all"
      ? projects
      : projects.filter(p => p.id === selectedProjectId);

    const filteredTasks = selectedProjectId === "all"
      ? tasks
      : tasks.filter(t => t.project_id === selectedProjectId);

    return {
      totalProjects: filteredProjects.length,
      activeProjects: filteredProjects.filter(p => p.status === 'active').length,
      completedProjects: filteredProjects.filter(p => p.status === 'completed').length,
      totalTasks: filteredTasks.length,
      completedTasks: filteredTasks.filter(t => t.status === 'completed').length,
      inProgressTasks: filteredTasks.filter(t => t.status === 'in_progress').length,
      overallProgress: filteredProjects.reduce((sum, p) => sum + (p.completion_percentage || 0), 0) / (filteredProjects.length || 1),
      totalBudget: filteredProjects.reduce((sum, p) => sum + (p.budget || 0), 0)
    };
  };

  const getStatusDistribution = () => {
    const filteredProjects = selectedProjectId === "all"
      ? projects
      : projects.filter(p => p.id === selectedProjectId);

    const statusCounts = {
      planning: 0,
      active: 0,
      on_hold: 0,
      completed: 0,
      cancelled: 0
    };

    filteredProjects.forEach(project => {
      statusCounts[project.status] = (statusCounts[project.status] || 0) + 1;
    });

    return Object.entries(statusCounts).map(([status, count]) => ({
      name: status.replace('_', ' ').replace(/^\w/, c => c.toUpperCase()),
      value: count,
      color: {
        planning: '#3b82f6',
        active: '#10b981',
        on_hold: '#f59e0b',
        completed: '#06b6d4',
        cancelled: '#ef4444'
      }[status]
    }));
  };

  const getTaskPriorityDistribution = () => {
    const filteredTasks = selectedProjectId === "all"
      ? tasks
      : tasks.filter(t => t.project_id === selectedProjectId);

    const priorityCounts = {
      low: 0,
      medium: 0,
      high: 0,
      critical: 0
    };

    filteredTasks.forEach(task => {
      priorityCounts[task.priority] = (priorityCounts[task.priority] || 0) + 1;
    });

    return [
      { name: 'Low', value: priorityCounts.low, fill: '#64748b' },
      { name: 'Medium', value: priorityCounts.medium, fill: '#f97316' },
      { name: 'High', value: priorityCounts.high, fill: '#dc2626' },
      { name: 'Critical', value: priorityCounts.critical, fill: '#7c3aed' }
    ];
  };

  const getProjectTimeline = () => {
    const filteredProjects = selectedProjectId === "all"
      ? projects.slice(0, 10)
      : projects.filter(p => p.id === selectedProjectId);

    return filteredProjects.map(project => ({
      name: project.name.length > 15 ? project.name.substring(0, 15) + '...' : project.name,
      progress: project.completion_percentage || 0,
      budget: project.budget || 0
    }));
  };

  const exportReport = () => {
    const stats = getProjectStats();
    const reportData = {
      generatedAt: new Date().toISOString(),
      summary: stats,
      projects: selectedProjectId === "all" ? projects : projects.filter(p => p.id === selectedProjectId),
      tasks: selectedProjectId === "all" ? tasks : tasks.filter(t => t.project_id === selectedProjectId)
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `project-report-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const stats = getProjectStats();
  const projectTimeline = getProjectTimeline();
  const statusDistribution = getStatusDistribution();
  const taskPriorityDistribution = getTaskPriorityDistribution();

  const handleStatsCardClick = (cardType) => {
    switch (cardType) {
      case 'projects':
        // Show project breakdown dialog or navigate to projects
        alert(`Total Projects: ${stats.totalProjects}\n\nActive: ${stats.activeProjects}\nCompleted: ${stats.completedProjects}\n\nClick to view detailed project list.`);
        break;
      case 'tasks':
        // Show task breakdown
        alert(`Task Summary:\n\nTotal Tasks: ${stats.totalTasks}\nCompleted: ${stats.completedTasks}\nIn Progress: ${stats.inProgressTasks}\n\nCompletion Rate: ${Math.round((stats.completedTasks / (stats.totalTasks || 1)) * 100)}%`);
        break;
      case 'progress':
        // Show progress details
        alert(`Progress Analysis:\n\nOverall Progress: ${Math.round(stats.overallProgress)}%\n\nProject Performance:\n• Active Projects: ${stats.activeProjects}\n• Completion Rate: ${Math.round((stats.completedTasks / (stats.totalTasks || 1)) * 100)}%\n\nClick to view detailed progress analytics.`);
        break;
      case 'budget':
        // Show budget breakdown
        const avgBudgetPerProject = stats.totalBudget / (stats.totalProjects || 1);
        alert(`Budget Analysis:\n\nTotal Budget: $${stats.totalBudget.toLocaleString()}\nAverage per Project: $${Math.round(avgBudgetPerProject).toLocaleString()}\n\nBudget Distribution:\n• Active Projects: ${stats.activeProjects}\n• Total Projects: ${stats.totalProjects}\n\nClick to view detailed budget analytics.`);
        break;
      default:
        break;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <BarChart3 className="w-8 h-8 text-blue-600" />
              Project Reports
            </h1>
            <p className="text-slate-600 mt-1">Generate comprehensive project reports and analytics.</p>
          </div>

          <div className="flex gap-3">
            <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Select project scope" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projects.map(project => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={exportReport} variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Export Report
            </Button>
          </div>
        </motion.div>

        {/* Summary Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          <Card
            className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0 cursor-pointer hover:shadow-xl hover:scale-105 transition-all duration-300"
            onClick={() => handleStatsCardClick('projects')}
          >
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-blue-100 text-sm font-medium">Total Projects</p>
                  <h3 className="text-3xl font-bold mt-2">{stats.totalProjects}</h3>
                  <p className="text-blue-100 text-xs mt-1">
                    {stats.activeProjects} active • {stats.completedProjects} completed
                  </p>
                </div>
                <Target className="w-6 h-6 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card
            className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0 cursor-pointer hover:shadow-xl hover:scale-105 transition-all duration-300"
            onClick={() => handleStatsCardClick('tasks')}
          >
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-green-100 text-sm font-medium">Completed Tasks</p>
                  <h3 className="text-3xl font-bold mt-2">{stats.completedTasks}</h3>
                  <p className="text-green-100 text-xs mt-1">
                    of {stats.totalTasks} total • {Math.round((stats.completedTasks / (stats.totalTasks || 1)) * 100)}% complete
                  </p>
                </div>
                <TrendingUp className="w-6 h-6 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card
            className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0 cursor-pointer hover:shadow-xl hover:scale-105 transition-all duration-300"
            onClick={() => handleStatsCardClick('progress')}
          >
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-purple-100 text-sm font-medium">Overall Progress</p>
                  <h3 className="text-3xl font-bold mt-2">{Math.round(stats.overallProgress)}%</h3>
                  <p className="text-purple-100 text-xs mt-1">
                    across all projects
                  </p>
                </div>
                <BarChart3 className="w-6 h-6 text-purple-200" />
              </div>
            </CardContent>
          </Card>

          <Card
            className="bg-gradient-to-r from-orange-500 to-orange-600 text-white border-0 cursor-pointer hover:shadow-xl hover:scale-105 transition-all duration-300"
            onClick={() => handleStatsCardClick('budget')}
          >
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-orange-100 text-sm font-medium">Total Budget</p>
                  <h3 className="text-3xl font-bold mt-2">${stats.totalBudget.toLocaleString()}</h3>
                  <p className="text-orange-100 text-xs mt-1">
                    ${Math.round(stats.totalBudget / (stats.totalProjects || 1)).toLocaleString()} avg per project
                  </p>
                </div>
                <FileText className="w-6 h-6 text-orange-200" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Charts and Analytics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Project Overview</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="resources">Resources</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Project Progress Chart */}
                <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
                  <CardHeader>
                    <CardTitle>Project Progress</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={projectTimeline}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" fontSize={12} />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="progress" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                {/* Status Distribution */}
                <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
                  <CardHeader>
                    <CardTitle>Project Status Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {statusDistribution.map((item, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div
                              className="w-4 h-4 rounded-full"
                              style={{ backgroundColor: item.color }}
                            />
                            <span className="text-sm font-medium">{item.name}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-slate-600">{item.value}</span>
                            <div className="w-24 bg-slate-200 rounded-full h-2">
                              <div
                                className="h-2 rounded-full transition-all duration-300"
                                style={{
                                  backgroundColor: item.color,
                                  width: `${(item.value / Math.max(...statusDistribution.map(s => s.value), 1) * 100)}%`
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="performance" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Task Priority Distribution */}
                <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
                  <CardHeader>
                    <CardTitle>Task Priority Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <RechartsPieChart>
                        <Pie
                          data={taskPriorityDistribution}
                          cx="50%"
                          cy="50%"
                          outerRadius={100}
                          dataKey="value"
                          label={({name, value}) => `${name}: ${value}`}
                        >
                          {taskPriorityDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </RechartsPieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                {/* Performance Metrics */}
                <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
                  <CardHeader>
                    <CardTitle>Performance Metrics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Task Completion Rate</span>
                        <span className="font-semibold">
                          {Math.round((stats.completedTasks / (stats.totalTasks || 1)) * 100)}%
                        </span>
                      </div>
                      <Progress
                        value={(stats.completedTasks / (stats.totalTasks || 1)) * 100}
                        className="h-2"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Active Projects</span>
                        <span className="font-semibold">
                          {Math.round((stats.activeProjects / (stats.totalProjects || 1)) * 100)}%
                        </span>
                      </div>
                      <Progress
                        value={(stats.activeProjects / (stats.totalProjects || 1)) * 100}
                        className="h-2"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Project Completion</span>
                        <span className="font-semibold">
                          {Math.round((stats.completedProjects / (stats.totalProjects || 1)) * 100)}%
                        </span>
                      </div>
                      <Progress
                        value={(stats.completedProjects / (stats.totalProjects || 1)) * 100}
                        className="h-2"
                      />
                    </div>

                    <div className="pt-4 border-t border-slate-200">
                      <div className="grid grid-cols-2 gap-4 text-center">
                        <div>
                          <div className="text-2xl font-bold text-green-600">
                            {stats.completedTasks}
                          </div>
                          <div className="text-xs text-slate-500">Completed Tasks</div>
                        </div>
                        <div>
                          <div className="text-2xl font-bold text-blue-600">
                            {stats.inProgressTasks}
                          </div>
                          <div className="text-xs text-slate-500">In Progress</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="resources" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Budget Breakdown */}
                <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
                  <CardHeader>
                    <CardTitle>Budget Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="text-center p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-100">
                        <div className="text-3xl font-bold text-green-600">
                          ${stats.totalBudget.toLocaleString()}
                        </div>
                        <div className="text-sm text-slate-600">Total Allocated Budget</div>
                      </div>

                      <div className="space-y-3">
                        {projects.slice(0, 5).map((project, index) => (
                          <div key={project.id} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                            <div>
                              <div className="font-medium text-sm">{project.name}</div>
                              <div className="text-xs text-slate-500">
                                {project.completion_percentage}% complete
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-semibold">${(project.budget || 0).toLocaleString()}</div>
                              <Badge variant="outline" className="text-xs">
                                {project.status}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Team Utilization */}
                <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
                  <CardHeader>
                    <CardTitle>Resource Utilization</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="text-center p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100">
                        <div className="text-3xl font-bold text-blue-600">
                          {projects.reduce((sum, p) => sum + (p.team_size || 0), 0)}
                        </div>
                        <div className="text-sm text-slate-600">Total Team Members</div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                          <span className="text-sm font-medium">Average Team Size</span>
                          <span className="font-semibold">
                            {Math.round(projects.reduce((sum, p) => sum + (p.team_size || 0), 0) / (projects.length || 1))}
                          </span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                          <span className="text-sm font-medium">Active Projects</span>
                          <span className="font-semibold">{stats.activeProjects}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                          <span className="text-sm font-medium">Tasks per Project</span>
                          <span className="font-semibold">
                            {Math.round(stats.totalTasks / (stats.totalProjects || 1))}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}
