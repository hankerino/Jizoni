
import React from "react";

export default function ClaudeAssistant() {
  return null;
}
