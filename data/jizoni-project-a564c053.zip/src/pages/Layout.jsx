

import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  LayoutDashboard,
  FolderKanban,
  FileBox,
  Calendar,
  Bot,
  BarChart,
  Users,
  Menu,
  Settings,
  Database // Added Database icon
} from 'lucide-react';
import { createPageUrl } from '@/utils';
import UserPreferences from '@/components/common/UserPreferences';

const navItems = [
  { page: 'Dashboard', icon: LayoutDashboard },
  { page: 'Projects', icon: FolderKanban },
  { page: 'WBSEditor', label: 'WBS Editor', icon: FileBox },
  { page: 'scheduling', icon: Calendar },
  { page: 'AIAssistant', label: 'Jz-Agent', icon: Bot },
  { page: 'Reports', icon: BarChart },
  { page: 'Resources', icon: Users },
  { page: 'DataBackup', label: 'Data Backup', icon: Database }, // Added Data Backup item
];

const NavLink = ({ item, pathname }) => (
  <Link
    to={createPageUrl(item.page)}
    className={`flex items-center gap-3 rounded-lg px-3 py-2 text-slate-700 transition-all hover:bg-slate-100 hover:text-slate-900 ${
      pathname.startsWith(createPageUrl(item.page)) ? 'bg-slate-200 text-slate-900 font-semibold' : ''
    }`}
  >
    <item.icon className="h-4 w-4" />
    {item.label || item.page}
  </Link>
);

export default function Layout({ children }) {
    const location = useLocation();
    const [showPreferences, setShowPreferences] = useState(false);

    const sidebarContent = (
        <div className="flex h-full max-h-screen flex-col gap-2">
            <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
                 <Link to={createPageUrl("Dashboard")} className="flex items-center gap-3 flex-1">
                    <img 
                      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/352642725_JizoniProject_logo.png" 
                      alt="Jizoni Project Logo"
                      className="w-8 h-8 object-cover rounded-lg shadow-sm"
                    />
                    <div>
                        <h2 className="font-bold text-slate-900 text-lg">Jizoni Project</h2>
                        <p className="text-xs text-slate-500 font-medium">Advanced Project Controls</p>
                    </div>
                 </Link>
                 <Button
                   variant="ghost" 
                   size="sm"
                   onClick={() => setShowPreferences(true)}
                   className="ml-2 p-2"
                   title="User Preferences"
                 >
                   <Settings className="w-4 h-4" />
                 </Button>
            </div>
            <div className="flex-1">
                <nav className="grid items-start px-2 text-sm font-medium lg:px-4 gap-1 py-4">
                    {navItems.map((item) => (
                        <NavLink key={item.page} item={item} pathname={location.pathname} />
                    ))}
                </nav>
            </div>
        </div>
    );
    
    return (
        <div className="grid min-h-screen w-full md:grid-cols-[260px_1fr] lg:grid-cols-[280px_1fr]">
            <div className="hidden border-r bg-white/90 backdrop-blur-sm md:block">
                {sidebarContent}
            </div>
            <div className="flex flex-col">
                <header className="flex h-14 items-center gap-4 border-b bg-white/90 backdrop-blur-sm px-4 lg:h-[60px] lg:px-6 md:hidden">
                    <Sheet>
                        <SheetTrigger asChild>
                            <Button
                                variant="outline"
                                size="icon"
                                className="shrink-0"
                            >
                                <Menu className="h-5 w-5" />
                                <span className="sr-only">Toggle navigation menu</span>
                            </Button>
                        </SheetTrigger>
                        <SheetContent side="left" className="flex flex-col w-[280px] p-0 bg-white">
                            {sidebarContent}
                        </SheetContent>
                    </Sheet>
                     <div className="flex items-center gap-3">
                        <img 
                          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/352642725_JizoniProject_logo.png" 
                          alt="Jizoni Project Logo"
                          className="w-8 h-8 object-cover rounded-lg"
                        />
                        <h1 className="text-lg font-bold text-slate-900">Jizoni Project</h1>
                      </div>
                </header>
                <main className="flex flex-1 flex-col bg-slate-50/50">
                    <div className="flex-1 overflow-auto p-4 lg:p-6">
                        {children}
                    </div>
                </main>
            </div>
            <UserPreferences
              isOpen={showPreferences} 
              onClose={() => setShowPreferences(false)} 
            />
        </div>
    );
}

