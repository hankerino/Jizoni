
import React, { useState, useEffect, useCallback } from "react";
import { Project } from "@/api/entities";
import { Task } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations"; // Remove claudeAI
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { dissolveTask } from "@/api/functions"; 
import { 
  Network, 
  Plus, 
  Bot, 
  ChevronRight, 
  ChevronDown, 
  Clock,
  User,
  Trash2,
  Edit,
  Wand2,
  Sparkles,
  Combine // FIX: Replaced GitMerge with a more intuitive icon
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import ResourceAssignmentButton from "../components/resources/ResourceAssignmentButton";
import ResourceAssignment from "../components/resources/ResourceAssignment";

export default function WBSEditor() {
  const [projects, setProjects] = useState([]);
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [tasks, setTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showAIDialog, setShowAIDialog] = useState(false);
  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [expandedTasks, setExpandedTasks] = useState(new Set());
  const [showResourceAssignment, setShowResourceAssignment] = useState(false);
  const [selectedTaskForAssignment, setSelectedTaskForAssignment] = useState(null);
  const [isAiSuggesting, setIsAiSuggesting] = useState(false);
  const [selectedTaskForAISuggestion, setSelectedTaskForAISuggestion] = useState(null);

  const [aiPrompt, setAiPrompt] = useState("");
  const [newTask, setNewTask] = useState({
    name: "",
    description: "",
    wbs_code: "",
    parent_task_id: null,
    level: 1,
    start_date: "",
    end_date: "",
    duration_days: 1,
    status: "not_started",
    priority: "medium",
    assigned_to: ""
  });

  const loadProjects = useCallback(async () => {
    try {
      const data = await Project.list("-updated_date");
      setProjects(data);
      if (data.length > 0 && !selectedProjectId) {
        setSelectedProjectId(data[0].id);
      }
    } catch (error) {
      console.error("Error loading projects:", error);
    }
  }, [selectedProjectId]);

  const loadTasks = useCallback(async () => {
    if (!selectedProjectId) return;
    
    setIsLoading(true);
    try {
      const data = await Task.filter({ project_id: selectedProjectId }, "wbs_code");
      setTasks(data);
      if (expandedTasks.size === 0 && data.length > 0) {
        const rootTaskIds = data.filter(t => !t.parent_task_id).map(t => t.id);
        setExpandedTasks(new Set(rootTaskIds));
      }
    } catch (error) {
      console.error("Error loading tasks:", error);
    }
    setIsLoading(false);
  }, [selectedProjectId, expandedTasks.size]); // expandedTasks.size is used to decide initial expansion

  useEffect(() => {
    loadProjects();
  }, [loadProjects]);

  useEffect(() => {
    if (selectedProjectId) {
      loadTasks();
    } else {
      setTasks([]);
    }
  }, [selectedProjectId, loadTasks]);

  const generateWBSWithAI = async () => {
    if (!aiPrompt.trim() || !selectedProjectId) return;

    setIsGenerating(true);
    try {
      const project = projects.find(p => p.id === selectedProjectId);
      const prompt = `Generate a detailed Work Breakdown Structure for the following construction/engineering project, structuring it into distinct, logical schedules for different phases.

Project Name: ${project.name}
Project Description: ${project.description || 'No description provided'}
Project Type: ${project.project_type}
Additional Requirements: ${aiPrompt}

Structure the WBS into the main lifecycle phases:
- Engineering
- Procurement
- Construction
- Testing
- Commissioning

For each item within these phases, provide:
- name: Clear, action-oriented task name.
- wbs_code: Hierarchical numbering (e.g., 1.1, 1.1.1).
- level: The hierarchy level (1, 2, or 3).
- duration_days: A realistic duration estimate in whole days.
- description: A brief description of the work, noting any key deliverables or long-lead items.

Return as a JSON object with a single key "tasks" containing an array of these items.`;

      const response = await InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            tasks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  wbs_code: { type: "string" },
                  level: { type: "number" },
                  duration_days: { type: "number" },
                  description: { type: "string" },
                },
                required: ["name", "wbs_code", "level", "duration_days", "description"]
              }
            }
          }
        },
        system_prompt: "You are an expert project manager specializing in construction and engineering. Generate detailed, realistic work breakdown structures."
      });

      if (response.tasks) {
        const tasksToCreate = response.tasks.map(task => ({
            ...task,
            project_id: selectedProjectId,
            status: "not_started",
            priority: "medium",
          }));
        await Task.bulkCreate(tasksToCreate);
        setShowAIDialog(false);
        setAiPrompt("");
        loadTasks();
      }
    } catch (error) {
      console.error("Error generating WBS:", error);
      alert(`Failed to generate WBS: ${error.message}`);
    }
    setIsGenerating(false);
  };
  
  const handleAiSuggestSubtasks = async (parentTask) => {
    setSelectedTaskForAISuggestion(parentTask);
    setIsAiSuggesting(true);
    try {
        const prompt = `Given the parent task "${parentTask.name}" (WBS: ${parentTask.wbs_code}) with description "${parentTask.description}", generate a list of detailed sub-tasks. 
        For each sub-task, provide a 'name', an estimated 'duration_days', and a short 'description'. 
        Return a JSON object with a "sub_tasks" array.`;

        const response = await InvokeLLM({
            prompt,
            response_json_schema: {
                type: "object",
                properties: {
                    sub_tasks: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                name: { type: "string" },
                                duration_days: { type: "number" },
                                description: { type: "string" }
                            },
                            required: ["name", "duration_days", "description"]
                        }
                    }
                }
            },
            system_prompt: "You are an expert construction project manager. Break down tasks into logical, executable sub-tasks."
        });

        if (response && response.sub_tasks) {
            const newTasks = response.sub_tasks.map((sub, index) => ({
                ...sub,
                project_id: selectedProjectId,
                parent_task_id: parentTask.id,
                wbs_code: `${parentTask.wbs_code}.${index + 1}`,
                level: parentTask.level + 1,
                status: "not_started",
                priority: "medium"
            }));
            await Task.bulkCreate(newTasks);
            loadTasks();
            setExpandedTasks(prev => new Set(prev).add(parentTask.id));
        }
    } catch (error) {
        console.error("AI Sub-task suggestion error:", error);
        alert(`Failed to generate subtasks: ${error.message}`);
    }
    setIsAiSuggesting(false);
    setSelectedTaskForAISuggestion(null);
  };
  
  const handleSaveTask = async () => {
    try {
        const taskData = {
            ...newTask,
            project_id: selectedProjectId,
            duration_days: parseInt(newTask.duration_days) || 1,
            level: parseInt(newTask.level) || 1,
            parent_task_id: newTask.parent_task_id ? tasks.find(t => t.wbs_code === newTask.parent_task_id)?.id : null
        };
        
        if (editingTask) {
            await Task.update(editingTask.id, taskData);
        } else {
            await Task.create(taskData);
        }
        
        setShowTaskDialog(false);
        setEditingTask(null);
        resetNewTask();
        loadTasks();
    } catch (error) {
        console.error("Error saving task:", error);
    }
  };

  const handleDissolveTask = async (taskId) => {
    const taskToDissolve = tasks.find(t => t.id === taskId);
    if (!taskToDissolve) return;

    if (window.confirm(`Are you sure you want to dissolve "${taskToDissolve.name}"? Its child tasks will be promoted and its dependencies re-linked. This action cannot be undone.`)) {
      try {
        await dissolveTask({ taskId });
        loadTasks();
      } catch (error) {
        console.error("Error dissolving task:", error);
        alert("Failed to dissolve the task. Check the console for more details.");
      }
    }
  };

  const handleDeleteTask = async (taskId) => {
    if (window.confirm("Are you sure you want to delete this task and all its sub-tasks?")) {
        try {
            const tasksToDelete = [taskId];
            const getChildren = (parentId) => {
              tasks.filter(t => t.parent_task_id === parentId).forEach(child => {
                tasksToDelete.push(child.id);
                getChildren(child.id);
              });
            };
            getChildren(taskId);
            
            const tasksToDeleteObjects = tasks.filter(t => tasksToDelete.includes(t.id)).sort((a,b) => b.level - a.level);
            for (const task of tasksToDeleteObjects) {
                await Task.delete(task.id);
            }
            loadTasks();
        } catch(error) {
            console.error("Error deleting task:", error);
        }
    }
  };

  const resetNewTask = () => {
    setNewTask({
      name: "",
      description: "",
      wbs_code: "",
      parent_task_id: null,
      level: 1,
      start_date: "",
      end_date: "",
      duration_days: 1,
      status: "not_started",
      priority: "medium",
      assigned_to: ""
    });
  };

  const toggleTaskExpansion = (taskId) => {
    const newExpanded = new Set(expandedTasks);
    if (newExpanded.has(taskId)) {
      newExpanded.delete(taskId);
    } else {
      newExpanded.add(taskId);
    }
    setExpandedTasks(newExpanded);
  };

  const getTaskHierarchy = () => {
    const taskMap = new Map();
    tasks.forEach(task => taskMap.set(task.id, { ...task, children: [] }));

    const roots = [];
    tasks.forEach(task => {
        if (task.parent_task_id && taskMap.has(task.parent_task_id)) {
            taskMap.get(task.parent_task_id).children.push(taskMap.get(task.id));
        } else {
            roots.push(taskMap.get(task.id));
        }
    });

    taskMap.forEach(task => {
      task.children.sort((a,b) => a.wbs_code.localeCompare(b.wbs_code, undefined, {numeric: true}));
    });

    return roots.sort((a,b) => a.wbs_code.localeCompare(b.wbs_code, undefined, {numeric: true}));
  };

  const handleResourceAssignmentClick = (task) => {
    setSelectedTaskForAssignment(task);
    setShowResourceAssignment(true);
  };

  const handleAssignmentUpdate = (taskId, assignments) => {
    console.log('Assignments updated for task:', taskId, assignments);
    setShowResourceAssignment(false);
    setSelectedTaskForAssignment(null);
  };

  const TaskItem = ({ task, depth = 0 }) => {
    const hasChildren = task.children && task.children.length > 0;
    const isExpanded = expandedTasks.has(task.id);

    const statusColors = {
      not_started: "bg-slate-100 text-slate-600",
      in_progress: "bg-blue-100 text-blue-700",
      completed: "bg-green-100 text-green-700",
      on_hold: "bg-yellow-100 text-yellow-700"
    };

    return (
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="space-y-2"
      >
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200 hover:shadow-md transition-shadow group">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <div style={{ paddingLeft: `${depth * 24}px` }} className="flex items-center gap-2">
                  {hasChildren ? (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-6 h-6"
                      onClick={() => toggleTaskExpansion(task.id)}
                    >
                      {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    </Button>
                  ) : <div className="w-6 h-6"/>}
                
                  <span className="font-mono text-sm text-slate-500 bg-slate-100 px-2 py-1 rounded">
                    {task.wbs_code}
                  </span>
                </div>
                
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-slate-900 truncate">{task.name}</p>
                </div>
              </div>

              <div className="flex items-center gap-4 mx-4">
                <Badge className={statusColors[task.status]} variant="secondary">
                  {task.status.replace('_', ' ')}
                </Badge>
                <div className="flex items-center gap-1 text-sm text-slate-500 w-20">
                  <Clock className="w-3 h-3" />
                  {task.duration_days} days
                </div>
                <div className="flex items-center gap-1 text-sm text-slate-500 w-32 truncate">
                  <User className="w-3 h-3" />
                  {task.assigned_to || 'Unassigned'}
                </div>
              </div>

              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  variant="ghost"
                  size="icon"
                  className="w-8 h-8"
                  onClick={() => {
                    setEditingTask(task);
                    const parentTaskObj = tasks.find(t => t.id === task.parent_task_id);
                    setNewTask({ 
                      ...task, 
                      parent_task_id: parentTaskObj ? parentTaskObj.wbs_code : "" 
                    });
                    setShowTaskDialog(true);
                  }}
                  title="Edit Task"
                >
                  <Edit className="w-4 h-4" />
                </Button>
                
                <Button
                  variant="ghost"
                  size="icon"
                  className="w-8 h-8 text-blue-500 hover:bg-blue-100"
                  onClick={() => handleAiSuggestSubtasks(task)}
                  disabled={isAiSuggesting && selectedTaskForAISuggestion?.id === task.id}
                  title="AI Suggest Sub-tasks"
                >
                  {isAiSuggesting && selectedTaskForAISuggestion?.id === task.id ? 
                    <Sparkles className="w-4 h-4 animate-spin" /> : 
                    <Wand2 className="w-4 h-4" />
                  }
                </Button>
                
                <Button
                  variant="ghost"
                  size="icon"
                  className="w-8 h-8 text-purple-500 hover:bg-purple-100" // Updated class name
                  onClick={() => handleDissolveTask(task.id)}
                  title="Dissolve Task" // Added a tooltip for clarity
                >
                  <Combine className="w-4 h-4" /> {/* Updated icon */}
                </Button>
                
                <ResourceAssignmentButton
                  onClick={() => handleResourceAssignmentClick(task)}
                  assignmentCount={0}
                  totalCost={0}
                />
                
                <Button
                  variant="ghost"
                  size="icon"
                  className="w-8 h-8 text-red-500 hover:bg-red-100"
                  onClick={() => handleDeleteTask(task.id)}
                  title="Delete Task"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <AnimatePresence>
          {hasChildren && isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
            >
              {task.children.map(child => (
                <TaskItem key={child.id} task={child} depth={depth + 1} />
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    );
  };

  const taskHierarchy = getTaskHierarchy();

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <Network className="w-8 h-8 text-blue-600" />
              Work Breakdown Structure
            </h1>
            <p className="text-slate-600 mt-1">Deconstruct your project into manageable work packages.</p>
          </div>
          
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={() => setShowAIDialog(true)}
              disabled={!selectedProjectId}
              className="gap-2"
            >
              <Bot className="w-4 h-4" />
              Jz-Agent Generate WBS
            </Button>
            <Button 
              onClick={() => { setEditingTask(null); resetNewTask(); setShowTaskDialog(true); }}
              disabled={!selectedProjectId}
              className="bg-blue-600 hover:bg-blue-700 gap-2"
            >
              <Plus className="w-4 h-4" />
              Add Task
            </Button>
          </div>
        </motion.div>

        {/* Project Selection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
            <CardHeader>
              <CardTitle>Selected Project</CardTitle>
              <CardDescription>Choose the project you want to structure.</CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
                <SelectTrigger className="w-full lg:w-1/3">
                  <SelectValue placeholder="Choose a project..." />
                </SelectTrigger>
                <SelectContent>
                  {projects.map(project => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </motion.div>

        {/* WBS Structure */}
        {selectedProjectId && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            {isLoading ? (
              <div className="space-y-3">
                {Array(5).fill(0).map((_, i) => (
                  <div key={i} className="animate-pulse bg-white/50 rounded-lg h-16 border border-slate-200"></div>
                ))}
              </div>
            ) : taskHierarchy.length > 0 ? (
              <div className="space-y-2">
                {taskHierarchy.map(task => (
                  <TaskItem key={task.id} task={task} />
                ))}
              </div>
            ) : (
              <Card className="text-center py-16">
                <CardContent>
                  <Network className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-600 mb-2">Empty Work Breakdown Structure</h3>
                  <p className="text-slate-500 mb-6">Begin by adding your first task or use AI to generate the entire WBS.</p>
                  <div className="flex gap-3 justify-center">
                    <Button 
                      variant="outline" 
                      onClick={() => setShowAIDialog(true)}
                      className="gap-2"
                    >
                      <Bot className="w-4 h-4" />
                      Generate with Jz-Agent
                    </Button>
                    <Button 
                      onClick={() => { setEditingTask(null); resetNewTask(); setShowTaskDialog(true); }}
                      className="bg-blue-600 hover:bg-blue-700 gap-2"
                    >
                      <Plus className="w-4 h-4" />
                      Add First Task
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </motion.div>
        )}

        {/* AI Generation Dialog */}
        <Dialog open={showAIDialog} onOpenChange={setShowAIDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-blue-600" />
                Jz-Agent WBS Generator
              </DialogTitle>
              <DialogDescription>Describe your project requirements, and Jz-Agent will create a detailed WBS for you.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <Label htmlFor="ai-prompt">Key Deliverables & Phases</Label>
                <Textarea
                  id="ai-prompt"
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="e.g., Key phases are site prep, foundation, structural, facade, and interiors. Mention key deliverables like MEP systems and landscaping."
                  rows={4}
                />
              </div>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium text-purple-800">Powered by Jz-Agent</span>
                </div>
                <p className="text-xs text-purple-700">
                  Advanced AI will analyze your project and generate a comprehensive work breakdown structure with realistic timelines and dependencies.
                </p>
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setShowAIDialog(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={generateWBSWithAI}
                  disabled={isGenerating}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  {isGenerating ? (
                    <>
                      <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                      Jz-Agent Generating...
                    </>
                  ) : (
                    <>
                      <Bot className="w-4 h-4 mr-2" />
                      Generate with Jz-Agent
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Resource Assignment Dialog */}
        <ResourceAssignment
          selectedTask={selectedTaskForAssignment}
          projectId={selectedProjectId}
          isOpen={showResourceAssignment}
          onClose={() => {
            setShowResourceAssignment(false);
            setSelectedTaskForAssignment(null);
          }}
          onAssignmentUpdate={handleAssignmentUpdate}
        />

        {/* Task Creation/Edit Dialog */}
        <Dialog open={showTaskDialog} onOpenChange={(open) => { if(!open) setEditingTask(null); setShowTaskDialog(open)}}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingTask ? "Edit Task / Work Package" : "Add New Task / Work Package"}
              </DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
               <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label htmlFor="parent_task_id">Parent Task (WBS Code)</Label>
                        <Input
                            id="parent_task_id"
                            value={newTask.parent_task_id || ""}
                            onChange={(e) => setNewTask(prev => ({ ...prev, parent_task_id: e.target.value }))}
                            placeholder="e.g., 1.1 (optional)"
                         />
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="level">WBS Level</Label>
                        <Input
                            id="level"
                            type="number"
                            value={newTask.level}
                            onChange={(e) => setNewTask(prev => ({ ...prev, level: e.target.value }))}
                        />
                    </div>
                </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="task-name">Name</Label>
                  <Input
                    id="task-name"
                    value={newTask.name}
                    onChange={(e) => setNewTask(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Concrete Pouring"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="wbs-code">WBS Code</Label>
                  <Input
                    id="wbs-code"
                    value={newTask.wbs_code}
                    onChange={(e) => setNewTask(prev => ({ ...prev, wbs_code: e.target.value }))}
                    placeholder="e.g., 1.1.2"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="task-description">Description</Label>
                <Textarea
                  id="task-description"
                  value={newTask.description}
                  onChange={(e) => setNewTask(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Task scope and completion criteria."
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (days)</Label>
                  <Input
                    id="duration"
                    type="number"
                    min="0"
                    value={newTask.duration_days}
                    onChange={(e) => setNewTask(prev => ({ ...prev, duration_days: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select value={newTask.status} onValueChange={(value) => setNewTask(prev => ({ ...prev, status: value }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="not_started">Not Started</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="on_hold">On Hold</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={newTask.priority} onValueChange={(value) => setNewTask(prev => ({ ...prev, priority: value }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="assigned-to">Assigned To / Discipline</Label>
                <Input
                  id="assigned-to"
                  value={newTask.assigned_to}
                  onChange={(e) => setNewTask(prev => ({ ...prev, assigned_to: e.target.value }))}
                  placeholder="e.g., Structural Team, John Doe"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <Button 
                variant="outline" 
                onClick={() => { setShowTaskDialog(false); setEditingTask(null); }}
              >
                Cancel
              </Button>
              <Button onClick={handleSaveTask} className="bg-blue-600 hover:bg-blue-700">
                {editingTask ? "Update Task" : "Create Task"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
