
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { format } from "date-fns";
import { Project } from "@/api/entities";
import { Task } from "@/api/entities";
import { Baseline } from "@/api/entities";
import { Calendar as CalendarEntity } from "@/api/entities";
import { Resource } from "@/api/entities";
import { TaskRelationship } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { claudeAI } from "@/api/functions";
import { fixScheduleIssues } from "@/api/functions"; // Import the new function
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Calendar as CalendarIcon,
  Users,
  AlertTriangle,
  Clock,
  User,
  Wand2,
  Sparkles,
  Stethoscope, // Added for diagnostics
  ShieldCheck, // Added for diagnostics
  CheckCircle, // Added for diagnostics
  Wrench, // Added for fix button
  ChevronsUpDown, // Added for collapsible
} from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"; // Import Collapsible components

// Import components with error handling
import GanttChart from "../components/scheduling/GanttChart";
import BaselineManager from "../components/scheduling/BaselineManager";
import CalendarManager from "../components/scheduling/CalendarManager";
import ResourceLeveling from "../components/scheduling/ResourceLeveling";
import EarnedValueAnalysis from "../components/scheduling/EarnedValueAnalysis";
import TaskRelationships from "../components/scheduling/TaskRelationships";
import ProgressSpotlight from "../components/scheduling/ProgressSpotlight";
import JzFilters from "../components/scheduling/JzFilters";

import ResourcePane from "../components/resources/ResourcePane";
import ResourcePaneToggle from "../components/resources/ResourcePaneToggle";
import ResourceAssignmentButton from "../components/resources/ResourceAssignmentButton";
import ResourceAssignment from "../components/resources/ResourceAssignment";

export default function Scheduling() {
  const [projects, setProjects] = useState([]);
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [tasks, setTasks] = useState([]);
  const [baselines, setBaselines] = useState([]);
  const [resources, setResources] = useState([]);
  const [calendars, setCalendars] = useState([]);
  const [relationships, setRelationships] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [criticalPath, setCriticalPath] = useState([]);
  const [scheduleMetrics, setScheduleMetrics] = useState(null);
  const [comparedBaselineId, setComparedBaselineId] = useState(null);

  const [showResourcePane, setShowResourcePane] = useState(false);
  const [showResourceAssignment, setShowResourceAssignment] = useState(false);
  const [selectedTaskForAssignment, setSelectedTaskForAssignment] = useState(null);

  const [dataDate, setDataDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [showAiDialog, setShowAiDialog] = useState(false);
  const [aiAnalyzing, setAiAnalyzing] = useState(false);
  const [aiResult, setAiResult] = useState(null);

  const [showDiagnosticsDialog, setShowDiagnosticsDialog] = useState(false);
  const [diagnosticsResult, setDiagnosticsResult] = useState(null);
  const [isFixing, setIsFixing] = useState(false);

  const [activeFilters, setActiveFilters] = useState({ matchType: 'all', rules: [] });
  const [initialLoad, setInitialLoad] = useState(true); // Added: initialLoad state

  const calculateCriticalPath = useCallback((taskList) => {
    if (!taskList || taskList.length === 0) {
      setCriticalPath([]);
      return [];
    }

    // Simple critical path calculation - tasks with zero or negative float
    const criticalTasks = taskList.filter(task =>
      task.priority === 'critical' ||
      (task.total_float !== undefined && task.total_float <= 0) ||
      task.status === 'in_progress' // Active tasks are often critical
    );

    const criticalTaskIds = criticalTasks.map(task => task.id);
    setCriticalPath(criticalTaskIds);
    return criticalTaskIds;
  }, [setCriticalPath]);

  const calculateScheduleMetrics = useCallback((taskList) => {
    if (!taskList || taskList.length === 0) {
      setScheduleMetrics(null);
      return;
    }

    const validTasks = taskList.filter(t => t.start_date && t.end_date);
    if (validTasks.length === 0) {
      setScheduleMetrics(null);
      return;
    }

    try {
      // Calculate project timeline
      const startDates = validTasks.map(t => new Date(t.start_date).getTime());
      const endDates = validTasks.map(t => new Date(t.end_date).getTime());

      const projectStart = Math.min(...startDates);
      const projectEnd = Math.max(...endDates);
      const totalDuration = Math.ceil((projectEnd - projectStart) / (1000 * 60 * 60 * 24));

      // Calculate SPI (Schedule Performance Index)
      const totalPV = taskList.reduce((acc, t) => acc + (t.planned_value || 0), 0);
      const totalEV = taskList.reduce((acc, t) => acc + (t.earned_value || 0), 0);
      const spi = totalPV > 0 ? totalEV / totalPV : 1.0;

      // Calculate total float
      const floatValues = taskList.map(t => t.total_float || 0);
      const minFloat = floatValues.length > 0 ? Math.min(...floatValues) : 0;

      // Calculate resource utilization
      const assignedTasks = taskList.filter(t => t.assigned_to);
      const resourceUtilization = taskList.length > 0
        ? Math.round((assignedTasks.length / taskList.length) * 100)
        : 0;

      // Determine schedule risk
      let scheduleRisk = "Low";
      if (spi < 0.9 || minFloat < 0) scheduleRisk = "High";
      else if (spi < 0.95 || minFloat < 5) scheduleRisk = "Medium";

      setScheduleMetrics({
        spi: Math.round(spi * 100) / 100,
        critical_path_duration: totalDuration,
        total_float_days: minFloat,
        resource_utilization: resourceUtilization,
        schedule_risk: scheduleRisk,
      });
    } catch (error) {
      console.error("Error calculating schedule metrics:", error);
      setScheduleMetrics(null);
    }
  }, [setScheduleMetrics]);

  // Modified: loadProjectData takes projectId as argument and includes finally block
  const loadProjectData = useCallback(async (projectId) => {
    if (!projectId) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const [tasksData, baselinesData, resourcesData, calendarsData, relationshipsData] = await Promise.all([
        Task.filter({ project_id: projectId }, "wbs_code").catch(() => []),
        Baseline.filter({ project_id: projectId }, "-created_date").catch(() => []),
        Resource.filter({ project_id: projectId }).catch(() => []),
        CalendarEntity.list().catch(() => []),
        TaskRelationship.filter({ project_id: projectId }).catch(() => [])
      ]);

      setTasks(tasksData);
      setBaselines(baselinesData);
      setResources(resourcesData);
      setCalendars(calendarsData);
      setRelationships(relationshipsData);

      calculateCriticalPath(tasksData);
      calculateScheduleMetrics(tasksData);
    } catch (error) {
      console.error("Error loading project data:", error);
    } finally {
      setIsLoading(false);
    }
  }, [calculateCriticalPath, calculateScheduleMetrics]); // Dependencies for useCallback

  // Replaced old loadProjects: Handles initial project list load and selects the first project.
  useEffect(() => {
    const fetchProjects = async () => {
      setIsLoading(true); // Start loading for project list
      let data = []; // Declare data here to be accessible in finally
      try {
        data = await Project.list("-updated_date");
        setProjects(data || []);
        if (data && data.length > 0 && initialLoad) { // Only run this logic on initial load
          const newProject = data[0];
          setSelectedProjectId(newProject.id);
          await loadProjectData(newProject.id); // Load data for the first project
          setInitialLoad(false); // Mark initial load as complete
        }
      } catch (error) {
        console.error("Error loading projects:", error);
        setProjects([]);
      } finally {
        if (initialLoad) { // Ensure loading is off if no projects were found on initial load
            setIsLoading(false); // This ensures isLoading is set to false if Project.list fails or returns empty, and initialLoad is still true.
        }
      }
    };
    fetchProjects();
  }, [initialLoad, loadProjectData]); // Dependencies for this effect

  // Modified: Load project-specific data when the selection changes (after initial load)
  useEffect(() => {
    if (selectedProjectId && !initialLoad) { // Only trigger if an ID is selected AND it's not the initial load that already triggered it
      loadProjectData(selectedProjectId);
    }
  }, [selectedProjectId, initialLoad, loadProjectData]); // Dependencies for this effect

  const runScheduleDiagnostics = useCallback(() => {
    if (!tasks || tasks.length === 0) {
      setDiagnosticsResult({ summary: "No tasks to analyze.", checks: [] });
      setShowDiagnosticsDialog(true);
      return;
    }

    // 1. Check for unassigned tasks
    const unassignedTasks = tasks.filter(t => !t.assigned_to);

    // 2. Check for tasks with negative float
    const negativeFloatTasks = tasks.filter(t => (t.total_float || 0) < 0);

    // 3. Check for open-ended tasks (simplified check)
    // A task is 'open-ended' if it has no successors.
    const taskIds = new Set(tasks.map(t => t.id));
    const tasksWithSuccessors = new Set(relationships.map(r => r.predecessor_task_id));
    const openEndedTasks = tasks.filter(t => !tasksWithSuccessors.has(t.id) && t.status !== 'completed');

    // 4. Check for tasks missing key dates
    const missingDatesTasks = tasks.filter(t => !t.start_date || !t.end_date);

    const totalIssues = unassignedTasks.length + negativeFloatTasks.length + openEndedTasks.length + missingDatesTasks.length;

    const results = {
      summary: totalIssues === 0
        ? "All checks passed. Your schedule is in good health."
        : `Found ${totalIssues} potential issues in your schedule.`,
      checks: [
        { name: "Unassigned Tasks", count: unassignedTasks.length, details: unassignedTasks.map(t => t.name) },
        { name: "Tasks with Negative Float", count: negativeFloatTasks.length, details: negativeFloatTasks.map(t => t.name) },
        { name: "Open-Ended Tasks", count: openEndedTasks.length, details: openEndedTasks.map(t => t.name) },
        { name: "Tasks with Missing Dates", count: missingDatesTasks.length, details: missingDatesTasks.map(t => t.name) },
      ]
    };

    setDiagnosticsResult(results);
    setShowDiagnosticsDialog(true);
  }, [tasks, relationships]);

  const handleFixIssues = async () => {
    setIsFixing(true);
    try {
      await fixScheduleIssues({ projectId: selectedProjectId });
      
      // Reload data to reflect the fixes
      await loadProjectData(selectedProjectId);
      
      setShowDiagnosticsDialog(false);
      alert("Schedule issues have been fixed. Please run diagnostics again to verify the changes.");
    } catch (error) {
      console.error("Failed to fix issues:", error);
      alert(`An error occurred while fixing the schedule: ${error.message}`);
    } finally {
      setIsFixing(false);
    }
  };


  const createBaseline = async (name, description) => {
    if (!selectedProjectId || !name.trim()) {
      alert("Please provide a baseline name");
      return;
    }

    try {
      const nextBaselineNumber = baselines.length > 0
        ? Math.max(...baselines.map(b => b.baseline_number || 0)) + 1
        : 0;

      // Capture current project state
      const baselineData = {
        tasks: tasks.map(task => ({
          id: task.id,
          name: task.name,
          start_date: task.start_date,
          end_date: task.end_date,
          duration_days: task.duration_days,
          wbs_code: task.wbs_code,
          status: task.status
        })),
        captured_date: new Date().toISOString()
      };

      await Baseline.create({
        project_id: selectedProjectId,
        name: name.trim(),
        description: description || "",
        baseline_date: new Date().toISOString().split('T')[0],
        baseline_number: nextBaselineNumber,
        is_current: baselines.length === 0, // First baseline is current
        baseline_data: baselineData
      });

      loadProjectData(selectedProjectId); // Reload to get updated baselines
    } catch (error) {
      console.error("Error creating baseline:", error);
      alert("Failed to create baseline. Please try again.");
    }
  };

  const setCurrentBaseline = async (baselineId) => {
    try {
      // Set all baselines to not current, then set selected as current
      await Promise.all(baselines.map(b =>
        Baseline.update(b.id, { is_current: b.id === baselineId })
      ));
      loadProjectData(selectedProjectId); // Reload to get updated baselines
    } catch (error) {
      console.error("Error setting current baseline:", error);
      alert("Failed to set current baseline. Please try again.");
    }
  };

  const deleteBaseline = async (baselineId) => {
    const baseline = baselines.find(b => b.id === baselineId);
    if (!baseline) return;

    if (baseline.is_current) {
      alert("Cannot delete the current baseline. Please set another baseline as current first.");
      return;
    }

    if (window.confirm(`Are you sure you want to delete baseline "${baseline.name}"?`)) {
      try {
        await Baseline.delete(baselineId);
        loadProjectData(selectedProjectId); // Reload to get updated baselines
      } catch (error) {
        console.error("Error deleting baseline:", error);
        alert("Failed to delete baseline. Please try again.");
      }
    }
  };

  const handleResourceAssignmentClick = (task) => {
    setSelectedTaskForAssignment(task);
    setShowResourceAssignment(true);
  };

  const handleAssignmentUpdate = async (taskId, assignments) => {
    try {
      // For now, just update the assigned_to field with the first resource
      const primaryAssignment = assignments.length > 0 ? assignments[0] : null;
      const resourceName = primaryAssignment
        ? resources.find(r => r.id === primaryAssignment.resource_id)?.name
        : "";

      await Task.update(taskId, { assigned_to: resourceName || "" });
      loadProjectData(selectedProjectId); // Reload data after update
    } catch (error) {
      console.error("Error updating task assignment:", error);
      alert("Failed to update task assignment.");
    }
  };

  const getOverallocatedResourcesCount = () => {
    if (!resources || resources.length === 0) return 0;

    return resources.filter(resource => {
      const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
      const totalWorkload = assignedTasks.reduce((sum, task) => sum + (task.duration_days || 0), 0);
      const utilization = Math.min((totalWorkload / 20) * 100, 150); // Assuming 20 days = 100%
      return utilization > 100;
    }).length;
  };

  const runAiAnalysis = async () => {
    setAiAnalyzing(true);
    setAiResult(null);

    try {
      const project = projects.find(p => p.id === selectedProjectId);
      if (!project) {
        throw new Error("No project selected");
      }

      const prompt = `Analyze the following project schedule based on professional scheduling protocols and provide insights:

Project: ${project.name}
Total Tasks: ${tasks.length}
Critical Path Length: ${scheduleMetrics?.critical_path_duration || 'N/A'} days
Overall SPI: ${scheduleMetrics?.spi || 'N/A'}
Resources: ${resources.length}

Critical Analysis Areas based on industry standards:
1.  **Schedule Logic:** Review predecessor/successor links. Is the logic sound?
2.  **Optimization:** Are there clear opportunities for task overlap (fast-tracking) to shorten the schedule?
3.  **Milestones & Contingency:** Are key hold/inspection/approval milestones present? Is there adequate contingency (float) on non-critical paths?
4.  **Resource Loading:** Are there signs of overallocated resources that could cause delays?
5.  **Risk Assessment:** What are the top 3 risks to the schedule's completion date?

Provide specific, actionable recommendations for this project.`;

      let analysis;
      try {
        const { data } = await claudeAI({
          prompt,
          system_prompt: "You are Jz-Agent, an expert project scheduler and risk analyst. Provide detailed, actionable insights for construction and engineering projects.",
          temperature: 0.4,
          max_tokens: 3000
        });

        if (data.error) {
          throw new Error(data.error);
        }

        // Parse Claude's response
        const response = data.response;
        analysis = {
          summary: `Jz-Agent analyzed ${tasks.length} tasks in ${project.name}`,
          risks: extractSection(response, "Risk") || [
            `${tasks.filter(t => !t.assigned_to).length} tasks without resource assignments`,
            `${tasks.filter(t => t.status === 'not_started').length} tasks not yet started`,
            `${tasks.filter(t => !t.end_date).length} tasks missing end dates`
          ],
          recommendations: extractSection(response, "Recommendation") || [
            "Assign resources to all unassigned tasks",
            "Set realistic end dates for all tasks",
            "Review task dependencies and critical path"
          ],
          detailed_analysis: response
        };
      } catch (claudeError) {
        console.log("Claude failed, using fallback analysis:", claudeError.message);
        // Fallback analysis
        analysis = {
          summary: `Analysis of ${tasks.length} tasks in the selected project`,
          risks: [
            `${tasks.filter(t => !t.assigned_to).length} tasks without resource assignments`,
            `${tasks.filter(t => t.status === 'not_started').length} tasks not yet started`,
            `${tasks.filter(t => !t.end_date).length} tasks missing end dates`,
            `${getOverallocatedResourcesCount()} overallocated resources`
          ],
          recommendations: [
            "Assign resources to all unassigned tasks",
            "Set realistic end dates for all tasks",
            "Review task dependencies and critical path",
            "Consider resource leveling for overallocated resources"
          ]
        };
      }

      setAiResult(analysis);
    } catch (error) {
      console.error("AI Analysis error:", error);
      setAiResult({ error: `Analysis failed: ${error.message}` });
    }

    setAiAnalyzing(false);
  };

  // Helper function to extract sections from Claude's response
  const extractSection = (text, sectionName) => {
    const regex = new RegExp(`${sectionName}[s]?:(.*?)(?=\\n\\n|$)`, 'is');
    const match = text.match(regex);
    if (match) {
      return match[1]
        .split('\n')
        .filter(line => line.trim() && !line.match(/^\d+\./))
        .map(line => line.replace(/^[-•*]\s*/, '').trim())
        .filter(line => line.length > 10)
        .slice(0, 5);
    }
    return null;
  };

  // Filter tasks based on active filters
  const filteredTasks = useMemo(() => {
    if (!activeFilters || !activeFilters.rules || activeFilters.rules.length === 0) {
      return tasks;
    }

    const { matchType, rules } = activeFilters;

    return tasks.filter(task => {
      const checkRule = (rule) => {
        const taskValue = task[rule.parameter];
        const ruleValue = rule.value;
        const isCritical = criticalPath && criticalPath.includes(task.id);

        if (rule.parameter === 'is_critical') {
          return String(isCritical) === ruleValue;
        }

        if (taskValue === undefined || taskValue === null) {
          if (rule.condition === 'is_not' && ruleValue === '') return true;
          if (rule.condition === 'is' && ruleValue === '') return true;
          return false;
        }

        switch (rule.condition) {
          case 'is': return String(taskValue) === ruleValue;
          case 'is_not': return String(taskValue) !== ruleValue;
          case 'contains': return String(taskValue).toLowerCase().includes(ruleValue.toLowerCase());
          case 'does_not_contain': return !String(taskValue).toLowerCase().includes(ruleValue.toLowerCase());
          case 'is_less_than': return Number(taskValue) < Number(ruleValue);
          case 'is_greater_than': return Number(taskValue) > Number(ruleValue);
          default: return false;
        }
      };

      if (matchType === 'all') {
        return rules.every(checkRule);
      } else {
        return rules.some(checkRule);
      }
    });
  }, [tasks, activeFilters, criticalPath]);

  // The condition for displaying the loading spinner is intentionally kept here
  // to ensure it shows when the initial project list is being fetched,
  // especially if there are no projects or if the first project's data is loading.
  if (isLoading && projects.length === 0 && initialLoad) {
    return (
        <div className="flex justify-center items-center h-screen">
            <div className="text-center">
                <Sparkles className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-spin" />
                <h2 className="text-xl font-semibold">Loading Projects...</h2>
            </div>
        </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4"
        >
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <CalendarIcon className="w-8 h-8 text-blue-600" />
              Project Scheduling
            </h1>
            <p className="text-slate-600 mt-1">Gantt charts, critical path analysis, and resource management.</p>
          </div>

          <div className="flex gap-3 items-center">
            <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Select project" />
              </SelectTrigger>
              <SelectContent>
                {projects.map(project => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              onClick={runScheduleDiagnostics}
              variant="outline"
              className="gap-2"
              disabled={!selectedProjectId || isLoading}
            >
              <Stethoscope className="w-4 h-4" />
              Run Schedule Diagnostics
            </Button>

            <Button
              onClick={() => setShowAiDialog(true)}
              className="bg-purple-600 hover:bg-purple-700 gap-2"
              disabled={!selectedProjectId || isLoading}
            >
              <Wand2 className="w-4 h-4" />
              AI Schedule Analysis
            </Button>

            <ResourcePaneToggle
              isOpen={showResourcePane}
              onToggle={() => setShowResourcePane(!showResourcePane)}
              resourceCount={resources.length}
              overallocatedCount={getOverallocatedResourcesCount()}
            />
          </div>
        </motion.div>

        {/* Schedule Metrics */}
        {scheduleMetrics && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6"
          >
            <Card className="bg-white/80">
              <CardContent className="p-4">
                <p className="text-slate-500 text-xs font-medium">SPI</p>
                <h3 className="text-2xl font-bold">{scheduleMetrics.spi.toFixed(2)}</h3>
              </CardContent>
            </Card>
            <Card className="bg-white/80">
              <CardContent className="p-4">
                <p className="text-slate-500 text-xs font-medium">Critical Path</p>
                <h3 className="text-2xl font-bold">{scheduleMetrics.critical_path_duration}d</h3>
              </CardContent>
            </Card>
            <Card className="bg-white/80">
              <CardContent className="p-4">
                <p className="text-slate-500 text-xs font-medium">Total Float</p>
                <h3 className="text-2xl font-bold">{scheduleMetrics.total_float_days}d</h3>
              </CardContent>
            </Card>
            <Card className="bg-white/80">
              <CardContent className="p-4">
                <p className="text-slate-500 text-xs font-medium">Resource Util.</p>
                <h3 className="text-2xl font-bold">{scheduleMetrics.resource_utilization}%</h3>
              </CardContent>
            </Card>
            <Card className="bg-white/80">
              <CardContent className="p-4">
                <p className="text-slate-500 text-xs font-medium">Schedule Risk</p>
                <h3 className="text-lg font-bold flex items-center gap-2">
                  {scheduleMetrics.schedule_risk}
                  <AlertTriangle className="w-4 h-4 text-orange-500"/>
                </h3>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="relative"
        >
          {selectedProjectId ? (
            <Tabs defaultValue="gantt" className="w-full">
              <TabsList className="grid w-full grid-cols-9">
                <TabsTrigger value="gantt">Gantt Chart</TabsTrigger>
                <TabsTrigger value="progress">Progress Spotlight</TabsTrigger>
                <TabsTrigger value="filters">Jz-Filters</TabsTrigger>
                <TabsTrigger value="baselines">Baselines</TabsTrigger>
                <TabsTrigger value="calendars">Calendars</TabsTrigger>
                <TabsTrigger value="resources">Resources</TabsTrigger>
                <TabsTrigger value="assignments">Assignments</TabsTrigger>
                <TabsTrigger value="earned-value">Earned Value</TabsTrigger>
                <TabsTrigger value="relationships">Dependencies</TabsTrigger>
              </TabsList>

              <TabsContent value="gantt" className="mt-6">
                <GanttChart
                  tasks={filteredTasks}
                  criticalPath={criticalPath}
                  baselines={baselines}
                  comparedBaselineId={comparedBaselineId}
                  onCompareBaseline={setComparedBaselineId}
                />
              </TabsContent>

              <TabsContent value="progress" className="mt-6">
                <ProgressSpotlight
                  tasks={filteredTasks}
                  dataDate={dataDate}
                  onDataDateChange={setDataDate}
                  showProgressBars={true}
                  showEarnedValue={true}
                />
              </TabsContent>

              <TabsContent value="filters" className="mt-6">
                <JzFilters
                  onApplyFilters={setActiveFilters}
                  onClearFilters={() => setActiveFilters({ matchType: 'all', rules: [] })}
                />
              </TabsContent>

              <TabsContent value="baselines" className="mt-6">
                <BaselineManager
                  baselines={baselines}
                  tasks={tasks}
                  onCreateBaseline={createBaseline}
                  onSetCurrent={setCurrentBaseline}
                  onDelete={deleteBaseline}
                  onCompare={setComparedBaselineId}
                  comparedBaselineId={comparedBaselineId}
                />
              </TabsContent>

              <TabsContent value="calendars" className="mt-6">
                <CalendarManager
                  calendars={calendars}
                  onCalendarsUpdate={() => loadProjectData(selectedProjectId)}
                />
              </TabsContent>

              <TabsContent value="resources" className="mt-6">
                <ResourceLeveling
                  resources={resources}
                  tasks={tasks}
                  calendars={calendars}
                />
              </TabsContent>

              <TabsContent value="assignments" className="mt-6">
                <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="w-5 h-5 text-purple-600" />
                      Resource Assignments
                      <Badge className="bg-purple-100 text-purple-700">
                        {filteredTasks.length} tasks
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {filteredTasks.length > 0 ? (
                      <div className="space-y-4">
                        {filteredTasks.map((task, index) => (
                          <motion.div
                            key={task.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.05 }}
                            className="flex justify-between items-center p-4 border border-slate-200 rounded-lg bg-white hover:bg-slate-50 transition-colors"
                          >
                            <div className="flex-1">
                              <div className="flex items-center gap-3">
                                <Badge variant="outline" className="font-mono text-xs">
                                  {task.wbs_code}
                                </Badge>
                                <h4 className="font-semibold text-slate-900">{task.name}</h4>
                                <Badge className={`${
                                  task.status === 'completed' ? 'bg-green-100 text-green-700' :
                                  task.status === 'in_progress' ? 'bg-blue-100 text-blue-700' :
                                  task.status === 'on_hold' ? 'bg-yellow-100 text-yellow-700' :
                                  'bg-slate-100 text-slate-700'
                                }`}>
                                  {task.status.replace('_', ' ')}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-4 mt-2 text-sm text-slate-600">
                                <span className="flex items-center gap-1">
                                  <CalendarIcon className="w-3 h-3" />
                                  {task.duration_days || 0} days
                                </span>
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {task.start_date ? new Date(task.start_date).toLocaleDateString() : 'No start date'}
                                </span>
                                {task.assigned_to && (
                                  <span className="flex items-center gap-1">
                                    <User className="w-3 h-3" />
                                    {task.assigned_to}
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <ResourceAssignmentButton
                                onClick={() => handleResourceAssignmentClick(task)}
                                assignmentCount={task.assigned_to ? 1 : 0}
                                totalCost={task.actual_cost || 0}
                              />
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-slate-600 mb-2">No Tasks Match Filters</h3>
                        <p className="text-slate-500">Adjust your filters or create new tasks</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="earned-value" className="mt-6">
                <EarnedValueAnalysis
                  project={projects.find(p => p.id === selectedProjectId)}
                  tasks={filteredTasks}
                />
              </TabsContent>

              <TabsContent value="relationships" className="mt-6">
                <TaskRelationships
                  tasks={tasks}
                  relationships={relationships}
                  projectId={selectedProjectId}
                  onRelationshipsUpdate={() => loadProjectData(selectedProjectId)}
                />
              </TabsContent>
            </Tabs>
          ) : (
            <Card className="bg-white/80 backdrop-blur-sm border-slate-200 h-64">
              <CardContent className="flex items-center justify-center h-full">
                <div className="text-center">
                  <CalendarIcon className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-600 mb-2">No Project Selected</h3>
                  <p className="text-slate-500">Please select a project to view scheduling information</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Resource Assignment Dialog */}
          <ResourceAssignment
            selectedTask={selectedTaskForAssignment}
            projectId={selectedProjectId}
            isOpen={showResourceAssignment}
            onClose={() => {
              setShowResourceAssignment(false);
              setSelectedTaskForAssignment(null);
            }}
            onAssignmentUpdate={handleAssignmentUpdate}
          />

          {/* Resource Panel */}
          <ResourcePane
            isOpen={showResourcePane}
            onClose={() => setShowResourcePane(false)}
            selectedProjectId={selectedProjectId}
            onResourceAssign={async (resource, task) => {
              try {
                await Task.update(task.id, { assigned_to: resource.name });
                loadProjectData(selectedProjectId);
              } catch (error) {
                console.error("Error assigning resource:", error);
              }
            }}
            isFullWindow={false}
            onToggleFullWindow={() => {}}
          />
        </motion.div>

        {/* Diagnostics Dialog */}
        <Dialog open={showDiagnosticsDialog} onOpenChange={setShowDiagnosticsDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center text-xl">
                <Stethoscope className="w-6 h-6 mr-3 text-blue-600" />
                Schedule Diagnostics Report
              </DialogTitle>
              <DialogDescription>
                This report identifies potential issues in the project schedule.
              </DialogDescription>
            </DialogHeader>
            {isFixing ? (
             <div className="flex flex-col items-center justify-center p-8 space-y-4">
                <Wrench className="w-12 h-12 animate-spin text-blue-600" />
                <p className="text-lg font-medium text-gray-700">Applying fixes to the schedule...</p>
                <p className="text-sm text-gray-500">This may take a moment. Please wait.</p>
            </div>
          ) : (
            <>
              {diagnosticsResult && (
                <div className="mt-4 space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                  <div className={`p-4 rounded-lg flex items-center gap-3 ${diagnosticsResult.summary.includes('All checks passed') ? 'bg-green-100/50 border-green-200' : 'bg-yellow-100/50 border-yellow-200'} border`}>
                    {diagnosticsResult.summary.includes('All checks passed') ? <ShieldCheck className="w-6 h-6 text-green-600" /> : <AlertTriangle className="w-6 h-6 text-yellow-600" />}
                    <p className="font-semibold text-sm">{diagnosticsResult.summary}</p>
                  </div>
                  {diagnosticsResult.checks.map((check, index) => check.count > 0 && (
                    <Collapsible key={index}>
                      <CollapsibleTrigger className="flex justify-between items-center w-full p-3 bg-gray-50 rounded-lg hover:bg-gray-100/80 transition-colors border border-gray-200">
                        <div className="flex items-center gap-2">
                          <Badge variant={check.count > 0 ? "destructive" : "default"}>{check.count}</Badge>
                          <span className="font-medium text-gray-800">{check.name}</span>
                        </div>
                        <ChevronsUpDown className="w-4 h-4" />
                      </CollapsibleTrigger>
                      <CollapsibleContent className="p-3 mt-1 bg-white border rounded-lg">
                        <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                          {check.details.slice(0, 10).map((detail, i) => <li key={i}>{detail}</li>)}
                          {check.details.length > 10 && <li>...and {check.details.length - 10} more.</li>}
                        </ul>
                      </CollapsibleContent>
                    </Collapsible>
                  ))}
                </div>
              )}
            </>
          )}
          <DialogFooter className="mt-4">
            {diagnosticsResult && !diagnosticsResult.summary.includes('All checks passed') && !isFixing && (
              <Button onClick={handleFixIssues} disabled={isFixing} className="bg-blue-600 hover:bg-blue-700">
                <Wrench className="w-4 h-4 mr-2" />
                Fix Issues Automatically
              </Button>
            )}
            <Button variant="outline" onClick={() => setShowDiagnosticsDialog(false)} disabled={isFixing}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

        {/* AI Analysis Dialog */}
        <Dialog open={showAiDialog} onOpenChange={setShowAiDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                Jz-Agent Schedule Analysis
              </DialogTitle>
              <DialogDescription>
                Intelligent analysis of your project schedule with actionable insights from Jz-Agent.
              </DialogDescription>
            </DialogHeader>

            <div className="py-4">
              {!aiResult && !aiAnalyzing && (
                <div className="text-center py-8">
                  <Wand2 className="w-12 h-12 text-purple-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Ready to analyze your schedule</h3>
                  <p className="text-slate-600 mb-4">
                        Jz-Agent will analyze {tasks.length} tasks and provide insights on risks, opportunities, and recommendations.
                  </p>
                  <Button
                    onClick={runAiAnalysis}
                    className="bg-purple-600 hover:bg-purple-700"
                    disabled={!selectedProjectId || isLoading}
                  >
                    Start Jz-Agent Analysis
                  </Button>
                </div>
              )}

              {aiAnalyzing && (
                <div className="text-center py-8">
                  <Sparkles className="w-12 h-12 text-purple-600 mx-auto mb-4 animate-pulse" />
                  <h3 className="text-lg font-semibold mb-2">Jz-Agent is analyzing your schedule...</h3>
                  <p className="text-slate-600">This may take a few moments.</p>
                </div>
              )}

              {aiResult && !aiResult.error && (
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Analysis Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p>{aiResult.summary}</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg text-orange-700">Identified Risks</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {aiResult.risks.map((risk, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <AlertTriangle className="w-4 h-4 text-orange-500 mt-0.5" />
                            <span className="text-sm">{risk}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg text-green-700">Recommendations</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {aiResult.recommendations.map((rec, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <span className="w-4 h-4 bg-green-500 rounded-full text-white text-xs flex items-center justify-center mt-0.5">
                              {index + 1}
                            </span>
                            <span className="text-sm">{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  {aiResult.detailed_analysis && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Detailed Analysis</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-sm whitespace-pre-wrap bg-slate-50 p-3 rounded">
                          {aiResult.detailed_analysis}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}

              {aiResult && aiResult.error && (
                <div className="text-center py-8">
                  <AlertTriangle className="w-12 h-12 text-red-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-red-700 mb-2">Analysis Failed</h3>
                  <p className="text-slate-600 mb-4">{aiResult.error}</p>
                  <Button
                    onClick={runAiAnalysis}
                    variant="outline"
                    disabled={!selectedProjectId || isLoading}
                  >
                    Try Again
                  </Button>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAiDialog(false)}>
                Close
              </Button>
              {aiResult && !aiResult.error && (
                <Button
                  onClick={runAiAnalysis}
                  className="bg-purple-600 hover:bg-purple-700"
                  disabled={!selectedProjectId || isLoading}
                >
                  Run New Analysis
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
