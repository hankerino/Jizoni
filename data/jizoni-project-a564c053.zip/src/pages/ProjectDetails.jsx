import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { Project } from '@/api/entities';
import { Task } from '@/api/entities';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Calendar, DollarSign, Users, CheckSquare, ListTodo, Edit, Bot, BarChart3, Network } from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

export default function ProjectDetails() {
  const [project, setProject] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const projectId = params.get('id');
    if (projectId) {
      loadData(projectId);
    }
  }, [location.search]);

  const loadData = async (projectId) => {
    setIsLoading(true);
    try {
      const [projectData, tasksData] = await Promise.all([
        Project.get(projectId),
        Task.filter({ project_id: projectId }, '-created_date'),
      ]);
      setProject(projectData);
      setTasks(tasksData);
    } catch (error) {
      console.error('Error loading project details:', error);
    }
    setIsLoading(false);
  };
  
  const getTaskStatusData = () => {
    const statusCounts = tasks.reduce((acc, task) => {
      acc[task.status] = (acc[task.status] || 0) + 1;
      return acc;
    }, {});
    
    const colors = {
      not_started: '#94a3b8',
      in_progress: '#3b82f6',
      completed: '#16a34a',
      on_hold: '#f59e0b',
    };

    return Object.entries(statusCounts).map(([name, value]) => ({
      name: name.replace('_', ' ').replace(/^\w/, c => c.toUpperCase()),
      value,
      fill: colors[name],
    }));
  };

  if (isLoading) {
    return <div className="p-6">Loading project details...</div>;
  }

  if (!project) {
    return <div className="p-6">Project not found.</div>;
  }
  
  const taskStatusData = getTaskStatusData();
  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const totalTasks = tasks.length;

  return (
    <div className="p-6 bg-slate-50 min-h-full">
      <div className="max-w-7xl mx-auto space-y-6">
        <Link to={createPageUrl('Projects')} className="flex items-center gap-2 text-sm text-slate-600 hover:text-slate-900">
          <ArrowLeft className="w-4 h-4" />
          Back to All Projects
        </Link>
        
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start gap-4">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">{project.name}</h1>
              <p className="text-slate-600 mt-1">{project.description}</p>
            </div>
            <div className="flex gap-2">
                <Button asChild variant="outline">
                    <Link to={createPageUrl(`Projects`)}><Edit className="w-4 h-4 mr-2" />Edit Project</Link>
                </Button>
                <Button asChild>
                    <Link to={createPageUrl(`Scheduling?projectId=${project.id}`)}><Calendar className="w-4 h-4 mr-2" />View Schedule</Link>
                </Button>
            </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Status</CardTitle>
                    <ListTodo className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <Badge>{project.status.replace('_', ' ')}</Badge>
                </CardContent>
            </Card>
             <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Budget</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">${(project.budget || 0).toLocaleString()}</div>
                </CardContent>
            </Card>
             <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">End Date</CardTitle>
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{new Date(project.end_date).toLocaleDateString()}</div>
                </CardContent>
            </Card>
             <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Team Size</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{project.team_size}</div>
                </CardContent>
            </Card>
        </div>
        
        {/* Progress and Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            <Card className="lg:col-span-3">
                <CardHeader>
                    <CardTitle>Project Progress</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex justify-between">
                        <span>Overall Completion</span>
                        <span>{project.completion_percentage}%</span>
                    </div>
                    <Progress value={project.completion_percentage} />
                     <div className="flex justify-between">
                        <span>Task Completion</span>
                        <span>{completedTasks} / {totalTasks} tasks</span>
                    </div>
                    <Progress value={totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0} />
                </CardContent>
            </Card>
            <Card className="lg:col-span-2">
                <CardHeader>
                    <CardTitle>Task Status</CardTitle>
                </CardHeader>
                <CardContent>
                    <ResponsiveContainer width="100%" height={150}>
                        <PieChart>
                            <Pie data={taskStatusData} cx="50%" cy="50%" outerRadius={60} dataKey="value">
                                {taskStatusData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.fill} />)}
                            </Pie>
                            <Tooltip />
                        </PieChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>
        </div>
        
        {/* Task List */}
        <Card>
            <CardHeader>
                <CardTitle>Tasks</CardTitle>
                <CardDescription>Key tasks associated with this project.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-2">
                    {tasks.slice(0, 5).map(task => (
                        <div key={task.id} className="flex items-center justify-between p-2 rounded-md hover:bg-slate-100">
                           <div>
                             <p className="font-medium">{task.name}</p>
                             <p className="text-sm text-slate-500">{task.description}</p>
                           </div>
                           <Badge variant={task.status === 'completed' ? 'default' : 'outline'}>{task.status.replace('_', ' ')}</Badge>
                        </div>
                    ))}
                    {tasks.length > 5 && (
                        <Link to={createPageUrl(`WBSEditor?projectId=${project.id}`)} className="text-blue-600 text-sm">
                            View all {tasks.length} tasks...
                        </Link>
                    )}
                </div>
            </CardContent>
        </Card>
        
      </div>
    </div>
  );
}