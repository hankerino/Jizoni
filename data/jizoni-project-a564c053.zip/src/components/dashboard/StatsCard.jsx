import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

export default function StatsCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  gradient, 
  delay = 0, 
  onClick 
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
    >
      <Card 
        className={`${gradient} text-white border-0 cursor-pointer hover:shadow-xl hover:scale-105 transition-all duration-300`}
        onClick={onClick}
      >
        <CardContent className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-white/80 text-sm font-medium">{title}</p>
              <h3 className="text-3xl font-bold mt-2">{value}</h3>
              <p className="text-white/80 text-xs mt-1">{subtitle}</p>
            </div>
            <Icon className="w-6 h-6 text-white/70" />
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}