import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar, DollarSign } from "lucide-react";

export default function ProjectCard({ project, delay = 0, onClick }) {
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-red-100 text-red-700';
      case 'high': return 'bg-orange-100 text-orange-700';
      case 'medium': return 'bg-yellow-100 text-yellow-700';
      default: return 'bg-slate-100 text-slate-600';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'border-green-300 bg-green-50 text-green-700';
      case 'completed': return 'border-blue-300 bg-blue-50 text-blue-700';
      case 'on_hold': return 'border-yellow-300 bg-yellow-50 text-yellow-700';
      default: return 'border-slate-300 bg-slate-50 text-slate-600';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, delay }}
    >
      <Card 
        className="h-full bg-white/80 backdrop-blur-sm border-slate-200 hover:shadow-xl transition-all duration-300 group cursor-pointer"
        onClick={onClick}
      >
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="space-y-2 flex-1 min-w-0">
              <CardTitle className="text-lg group-hover:text-blue-700 transition-colors truncate">
                {project.name}
              </CardTitle>
              <div className="flex items-center gap-2 flex-wrap">
                <Badge className={getPriorityColor(project.priority)}>
                  {project.priority}
                </Badge>
                <Badge variant="outline" className={getStatusColor(project.status)}>
                  {project.status.replace('_', ' ').toUpperCase()}
                </Badge>
              </div>
            </div>
          </div>
          <CardDescription className="line-clamp-2 mt-2">
            {project.description || 'No description provided'}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span className="font-semibold">{project.completion_percentage || 0}%</span>
            </div>
            <Progress value={project.completion_percentage || 0} className="h-2" />
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-slate-400" />
              <div>
                <span className="text-slate-500 block">End Date</span>
                <p className="font-medium">
                  {project.end_date 
                    ? new Date(project.end_date).toLocaleDateString()
                    : 'Not set'
                  }
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <DollarSign className="h-4 w-4 text-slate-400" />
              <div>
                <span className="text-slate-500 block">Budget</span>
                <p className="font-medium">
                  {project.budget ? `$${Number(project.budget).toLocaleString()}` : 'N/A'}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}