import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, CheckSquare, AlertTriangle } from "lucide-react";
import { motion } from "framer-motion";

export default function ActivityFeed({ tasks, projects }) {
  const getRecentActivity = () => {
    const activities = [];
    
    // Recent task completions
    const completedTasks = tasks
      .filter(task => task.status === 'completed')
      .sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date))
      .slice(0, 3);
    
    completedTasks.forEach(task => {
      const project = projects.find(p => p.id === task.project_id);
      activities.push({
        id: `task-${task.id}`,
        type: 'task_completed',
        title: `Task completed: ${task.name}`,
        project: project?.name || 'Unknown Project',
        time: task.updated_date,
        icon: CheckSquare,
        color: 'text-green-600'
      });
    });

    // Overdue tasks
    const overdueTasks = tasks
      .filter(task => task.end_date && new Date(task.end_date) < new Date() && task.status !== 'completed')
      .slice(0, 2);
    
    overdueTasks.forEach(task => {
      const project = projects.find(p => p.id === task.project_id);
      activities.push({
        id: `overdue-${task.id}`,
        type: 'task_overdue',
        title: `Overdue: ${task.name}`,
        project: project?.name || 'Unknown Project',
        time: task.end_date,
        icon: AlertTriangle,
        color: 'text-red-600'
      });
    });

    // Recent project updates
    const recentProjects = projects
      .sort((a, b) => new Date(b.updated_date) - new Date(a.updated_date))
      .slice(0, 2);
    
    recentProjects.forEach(project => {
      activities.push({
        id: `project-${project.id}`,
        type: 'project_updated',
        title: `Project updated: ${project.name}`,
        project: project.name,
        time: project.updated_date,
        icon: Clock,
        color: 'text-blue-600'
      });
    });

    return activities
      .sort((a, b) => new Date(b.time) - new Date(a.time))
      .slice(0, 8);
  };

  const activities = getRecentActivity();

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-blue-600" />
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        {activities.length > 0 ? (
          <div className="space-y-4">
            {activities.map((activity, index) => (
              <motion.div
                key={activity.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-start gap-3 p-3 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors"
              >
                <activity.icon className={`w-4 h-4 mt-0.5 ${activity.color}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate">
                    {activity.title}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-xs">
                      {activity.project}
                    </Badge>
                    <span className="text-xs text-slate-500">
                      {activity.time ? new Date(activity.time).toLocaleDateString() : 'Recently'}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Clock className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500 text-sm">No recent activity</p>
            <p className="text-slate-400 text-xs mt-1">Activity will appear here as you work on projects</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}