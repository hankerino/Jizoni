import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Palette, Bell, Shield } from 'lucide-react';

export default function UserPreferences({ isOpen, onClose }) {
  const [theme, setTheme] = useState('light');
  const [notifications, setNotifications] = useState({
    taskUpdates: true,
    projectMentions: true,
  });

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);
    document.documentElement.classList.toggle('dark', savedTheme === 'dark');
  }, []);

  const handleThemeChange = (isDark) => {
    const newTheme = isDark ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.classList.toggle('dark', isDark);
  };

  const handleNotificationChange = (key, value) => {
    setNotifications(prev => ({ ...prev, [key]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>User Preferences</DialogTitle>
          <DialogDescription>
            Customize your experience across the application.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-6">
          <div className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2"><Palette className="w-4 h-4"/> Appearance</h3>
            <div className="flex items-center justify-between p-3 bg-slate-100 dark:bg-slate-800 rounded-lg">
              <Label htmlFor="dark-mode">Dark Mode</Label>
              <Switch
                id="dark-mode"
                checked={theme === 'dark'}
                onCheckedChange={handleThemeChange}
              />
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2"><Bell className="w-4 h-4"/> Notifications</h3>
            <div className="flex items-center justify-between p-3 bg-slate-100 dark:bg-slate-800 rounded-lg">
              <Label htmlFor="task-updates">Task Updates</Label>
              <Switch
                id="task-updates"
                checked={notifications.taskUpdates}
                onCheckedChange={(v) => handleNotificationChange('taskUpdates', v)}
              />
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-100 dark:bg-slate-800 rounded-lg">
              <Label htmlFor="project-mentions">Project Mentions</Label>
              <Switch
                id="project-mentions"
                checked={notifications.projectMentions}
                onCheckedChange={(v) => handleNotificationChange('projectMentions', v)}
              />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={onClose}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}