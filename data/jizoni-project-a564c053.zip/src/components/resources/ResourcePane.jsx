
import React, { useState, useEffect } from "react";
import { Resource } from "@/api/entities";
import { Task } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { 
  Users, 
  Search, 
  Filter,
  Plus,
  Edit,
  Trash2,
  Clock,
  AlertTriangle,
  CheckCircle,
  User,
  Wrench,
  Package,
  DollarSign,
  X,
  Maximize2,
  Minimize2
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ResourcePane({ 
  isOpen, 
  onClose, 
  selectedProjectId, 
  onResourceAssign,
  isFullWindow = false,
  onToggleFullWindow 
}) {
  const [resources, setResources] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [selectedResource, setSelectedResource] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [isLoading, setIsLoading] = useState(true);
  const [showAssignDialog, setShowAssignDialog] = useState(false);
  const [assignmentData, setAssignmentData] = useState({});

  useEffect(() => {
    if (isOpen) {
      loadResourceData();
    }
  }, [isOpen, selectedProjectId]);

  const loadResourceData = async () => {
    setIsLoading(true);
    try {
      const [resourcesData, tasksData] = await Promise.all([
        Resource.list(),
        selectedProjectId ? Task.filter({ project_id: selectedProjectId }) : []
      ]);
      setResources(resourcesData || []);
      setTasks(tasksData || []);
    } catch (error) {
      console.error("Error loading resource data:", error);
    }
    setIsLoading(false);
  };

  const getResourceIcon = (type) => {
    switch (type) {
      case 'person': return User;
      case 'equipment': return Wrench;
      case 'material': return Package;
      case 'cost': return DollarSign;
      default: return User;
    }
  };

  const getResourceUtilization = (resource) => {
    const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
    const totalWorkload = assignedTasks.reduce((sum, task) => {
      return sum + (task.duration_days || 0);
    }, 0);
    return Math.min((totalWorkload / 20) * 100, 150); // Assuming 20 days as 100%
  };

  const getUtilizationStatus = (utilization) => {
    if (utilization <= 70) return { color: "text-green-600", bg: "bg-green-100", status: "Available" };
    if (utilization <= 100) return { color: "text-yellow-600", bg: "bg-yellow-100", status: "Optimal" };
    return { color: "text-red-600", bg: "bg-red-100", status: "Overallocated" };
  };

  const filteredResources = resources.filter(resource => {
    const matchesSearch = resource.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (resource.role || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (resource.email || '').toLowerCase().includes(searchTerm.toLowerCase());
    
    // Fixed filter logic for all resource types
    const matchesFilter = filterType === "all" || resource.type === filterType;
    
    const matchesProject = !selectedProjectId || !resource.project_id || resource.project_id === selectedProjectId;
    
    return matchesSearch && matchesFilter && matchesProject;
  });

  const handleResourceAssign = (resource, task) => {
    setAssignmentData({ resource, task });
    setShowAssignDialog(true);
  };

  const confirmAssignment = async () => {
    if (onResourceAssign && assignmentData.resource && assignmentData.task) {
      await onResourceAssign(assignmentData.resource, assignmentData.task);
      setShowAssignDialog(false);
      setAssignmentData({});
      loadResourceData();
    }
  };

  const getResourceTypeStats = () => {
    const stats = {
      all: resources.length,
      person: resources.filter(r => r.type === 'person').length,
      equipment: resources.filter(r => r.type === 'equipment').length,
      material: resources.filter(r => r.type === 'material').length,
      cost: resources.filter(r => r.type === 'cost').length
    };
    return stats;
  };

  const resourceStats = getResourceTypeStats();

  const ResourceCard = ({ resource }) => {
    const Icon = getResourceIcon(resource.type);
    const utilization = getResourceUtilization(resource);
    const status = getUtilizationStatus(utilization);
    const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);

    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`p-4 rounded-lg border cursor-pointer transition-all hover:shadow-md ${
          selectedResource?.id === resource.id ? 'border-blue-500 bg-blue-50' : 'border-slate-200 bg-white'
        }`}
        onClick={() => setSelectedResource(resource)}
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${status.bg}`}>
              <Icon className={`w-4 h-4 ${status.color}`} />
            </div>
            <div>
              <h4 className="font-semibold text-slate-900">{resource.name}</h4>
              {resource.role && (
                <p className="text-sm text-slate-600">{resource.role}</p>
              )}
            </div>
          </div>
          <Badge variant="outline" className={`${status.color} border-current`}>
            {status.status}
          </Badge>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-slate-600">Utilization</span>
            <span className="font-medium">{Math.round(utilization)}%</span>
          </div>
          <Progress value={Math.min(utilization, 100)} className="h-2" />
          
          <div className="flex justify-between text-sm">
            <span className="text-slate-600">Assigned Tasks</span>
            <span className="font-medium">{assignedTasks.length}</span>
          </div>
          
          {resource.standard_rate > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-slate-600">Rate</span>
              <span className="font-medium">${resource.standard_rate}/hr</span>
            </div>
          )}
        </div>
      </motion.div>
    );
  };

  const ResourceDetails = ({ resource }) => {
    const assignedTasks = tasks.filter(task => task.assigned_to === resource.name);
    const utilization = getResourceUtilization(resource);
    const status = getUtilizationStatus(utilization);

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3 pb-4 border-b">
          <Avatar className="w-12 h-12">
            <AvatarImage src={`https://i.pravatar.cc/100?u=${resource.email || resource.name}`} />
            <AvatarFallback>{resource.name.substring(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-semibold text-lg">{resource.name}</h3>
            <p className="text-slate-600">{resource.role || resource.type}</p>
            {resource.email && (
              <p className="text-sm text-slate-500">{resource.email}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <h4 className="font-medium text-slate-900">Utilization</h4>
            <div className={`p-3 rounded-lg ${status.bg}`}>
              <div className="flex justify-between items-center">
                <span className={`font-semibold ${status.color}`}>
                  {Math.round(utilization)}%
                </span>
                <Badge className={`${status.color} border-current`} variant="outline">
                  {status.status}
                </Badge>
              </div>
              <Progress value={Math.min(utilization, 100)} className="mt-2 h-2" />
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium text-slate-900">Workload</h4>
            <div className="p-3 rounded-lg bg-slate-50">
              <div className="text-2xl font-bold text-slate-900">{assignedTasks.length}</div>
              <div className="text-sm text-slate-600">Active Tasks</div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h4 className="font-medium text-slate-900">Assigned Tasks</h4>
          <ScrollArea className="h-64">
            <div className="space-y-2">
              {assignedTasks.map(task => (
                <div key={task.id} className="p-3 rounded-lg border border-slate-200 bg-white">
                  <div className="flex justify-between items-start">
                    <div>
                      <h5 className="font-medium text-slate-900">{task.name}</h5>
                      <p className="text-sm text-slate-600">{task.wbs_code}</p>
                    </div>
                    <Badge variant="outline">{task.status}</Badge>
                  </div>
                  <div className="flex justify-between text-sm text-slate-500 mt-2">
                    <span>Duration: {task.duration_days || 0} days</span>
                    <span>{task.completion_percentage || 0}% complete</span>
                  </div>
                </div>
              ))}
              {assignedTasks.length === 0 && (
                <div className="text-center py-8 text-slate-500">
                  <User className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                  <p>No tasks assigned</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </div>
      </div>
    );
  };

  const content = (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-blue-600" />
          <h2 className="text-lg font-semibold">Resource Management</h2>
          <Badge variant="outline">{filteredResources.length} of {resources.length} resources</Badge>
        </div>
        <div className="flex items-center gap-2">
          {onToggleFullWindow && (
            <Button
              variant="outline"
              size="sm"
              onClick={onToggleFullWindow}
              className="gap-2"
            >
              {isFullWindow ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              {isFullWindow ? 'Minimize' : 'Expand'}
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input
            placeholder="Search resources by name, role, or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        {/* Resource Type Filter Tabs */}
        <div className="flex gap-2 flex-wrap">
          <Button
            variant={filterType === "all" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterType("all")}
            className="gap-2"
          >
            <Filter className="w-3 h-3" />
            All ({resourceStats.all})
          </Button>
          
          <Button
            variant={filterType === "person" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterType("person")}
            className="gap-2"
          >
            <User className="w-3 h-3" />
            People ({resourceStats.person})
          </Button>
          
          <Button
            variant={filterType === "equipment" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterType("equipment")}
            className="gap-2"
          >
            <Wrench className="w-3 h-3" />
            Equipment ({resourceStats.equipment})
          </Button>
          
          <Button
            variant={filterType === "material" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterType("material")}
            className="gap-2"
          >
            <Package className="w-3 h-3" />
            Materials ({resourceStats.material})
          </Button>
          
          <Button
            variant={filterType === "cost" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterType("cost")}
            className="gap-2"
          >
            <DollarSign className="w-3 h-3" />
            Cost ({resourceStats.cost})
          </Button>
        </div>

        {/* Active Filter Indicator */}
        {filterType !== "all" && (
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="gap-1">
              Filtered by: {filterType}
              <button
                onClick={() => {
                  setFilterType("all");
                  setSearchTerm(""); // Clear search when clearing filter for better UX
                }}
                className="ml-1 hover:bg-slate-300 rounded-full p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            </Badge>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[600px]">
        {/* Resources List */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-medium text-slate-900">
              {filterType === "all" ? "All Resources" : 
               filterType === "person" ? "Team Members" :
               filterType === "equipment" ? "Equipment & Tools" :
               filterType === "material" ? "Materials & Supplies" :
               "Cost Resources"}
            </h3>
            {filteredResources.length !== resources.length && (
              <Badge variant="outline" className="text-xs">
                {filteredResources.length} of {resources.length}
              </Badge>
            )}
          </div>
          
          <ScrollArea className="h-full">
            <div className="space-y-3">
              {isLoading ? (
                Array(6).fill(0).map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-24 bg-slate-200 rounded-lg"></div>
                  </div>
                ))
              ) : (
                filteredResources.map(resource => (
                  <ResourceCard key={resource.id} resource={resource} />
                ))
              )}
              {!isLoading && filteredResources.length === 0 && (
                <div className="text-center py-12">
                  <div className="w-16 h-16 mx-auto mb-4 text-slate-300">
                    {filterType === "person" ? <User className="w-16 h-16" /> :
                     filterType === "equipment" ? <Wrench className="w-16 h-16" /> :
                     filterType === "material" ? <Package className="w-16 h-16" /> :
                     filterType === "cost" ? <DollarSign className="w-16 h-16" /> :
                     <Users className="w-16 h-16" />}
                  </div>
                  <h3 className="text-lg font-semibold text-slate-600 mb-2">
                    No {filterType === "all" ? "resources" : filterType === "person" ? "people" : `${filterType} resources`} found
                  </h3>
                  <p className="text-slate-500">
                    {searchTerm ? 
                      `Try adjusting your search term "${searchTerm}"` :
                      `No ${filterType === "all" ? "resources" : `${filterType} resources`} available`
                    }
                  </p>
                  {searchTerm && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-3"
                      onClick={() => setSearchTerm("")}
                    >
                      Clear Search
                    </Button>
                  )}
                </div>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Resource Details */}
        <div className="space-y-4">
          <h3 className="font-medium text-slate-900">Resource Details</h3>
          <Card className="h-full">
            <CardContent className="p-4 h-full">
              {selectedResource ? (
                <ResourceDetails resource={selectedResource} />
              ) : (
                <div className="flex items-center justify-center h-full text-slate-500">
                  <div className="text-center">
                    <Users className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                    <p>Select a resource to view details</p>
                    <p className="text-sm mt-2">
                      Click on any resource card to see assignments and utilization
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );

  if (isFullWindow) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden">
          <div className="p-6 h-full">
            {content}
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ x: 400, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 400, opacity: 0 }}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          className="fixed right-0 top-0 h-full w-96 bg-white border-l border-slate-200 shadow-xl z-50 overflow-hidden"
        >
          <div className="p-6 h-full flex flex-col">
            {content}
          </div>
        </motion.div>
      )}

      {/* Assignment Dialog */}
      <Dialog open={showAssignDialog} onOpenChange={setShowAssignDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Resource</DialogTitle>
            <DialogDescription>
              Assign {assignmentData.resource?.name} to {assignmentData.task?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-slate-600">
              This will update the task assignment and recalculate resource utilization.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAssignDialog(false)}>
              Cancel
            </Button>
            <Button onClick={confirmAssignment}>
              Confirm Assignment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AnimatePresence>
  );
}
