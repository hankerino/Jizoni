import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, Settings } from "lucide-react";

export default function ResourceAssignmentButton({ 
  onClick, 
  assignmentCount = 0, 
  totalCost = 0,
  disabled = false 
}) {
  return (
    <Button
      variant="outline"
      onClick={onClick}
      disabled={disabled}
      className="gap-2 relative"
    >
      <Users className="w-4 h-4" />
      Resource Assignment
      <Settings className="w-4 h-4" />
      
      {assignmentCount > 0 && (
        <div className="flex gap-1 ml-2">
          <Badge variant="secondary">
            {assignmentCount} assigned
          </Badge>
          {totalCost > 0 && (
            <Badge variant="outline" className="text-green-600">
              ${totalCost.toFixed(0)}
            </Badge>
          )}
        </div>
      )}
    </Button>
  );
}