import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, Eye, EyeOff } from "lucide-react";

export default function ResourcePaneToggle({ 
  isOpen, 
  onToggle, 
  resourceCount = 0,
  overallocatedCount = 0 
}) {
  return (
    <Button
      variant={isOpen ? "default" : "outline"}
      onClick={onToggle}
      className="gap-2 relative"
    >
      <Users className="w-4 h-4" />
      Resource Pane
      {isOpen ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
      
      {resourceCount > 0 && (
        <Badge variant="secondary" className="ml-2">
          {resourceCount}
        </Badge>
      )}
      
      {overallocatedCount > 0 && (
        <Badge variant="destructive" className="ml-1 animate-pulse">
          {overallocatedCount} over
        </Badge>
      )}
    </Button>
  );
}