import React, { useState, useEffect } from "react";
import { Resource } from "@/api/entities";
import { Task } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Slider } from "@/components/ui/slider";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Users, 
  Plus,
  Edit,
  Trash2,
  Clock,
  DollarSign,
  Calendar,
  BarChart3,
  TrendingUp,
  AlertTriangle,
  CheckCircle2
} from "lucide-react";
import { motion } from "framer-motion";

export default function ResourceAssignment({ 
  selectedTask, 
  projectId, 
  isOpen, 
  onClose, 
  onAssignmentUpdate 
}) {
  const [resources, setResources] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newAssignment, setNewAssignment] = useState({
    resource_id: "",
    assignment_units: 100,
    rate_override: 0,
    allocation_curve: "uniform"
  });

  useEffect(() => {
    if (isOpen && selectedTask) {
      loadData();
    }
  }, [isOpen, selectedTask, projectId]);

  const loadData = async () => {
    if (!projectId) return;
    
    setIsLoading(true);
    try {
      const resourcesData = await Resource.filter({ project_id: projectId });
      setResources(resourcesData || []);
      
      // Mock assignments for now - in real app would load from ResourceAssignment entity
      const mockAssignments = selectedTask?.assigned_to ? [{
        id: '1',
        resource_id: resourcesData.find(r => r.name === selectedTask.assigned_to)?.id || '',
        assignment_units: 100,
        rate_override: 0,
        allocation_curve: "uniform",
        work_hours: selectedTask.duration_days * 8 || 0,
        actual_work_hours: 0,
        assignment_cost: 0,
        actual_cost: 0
      }] : [];
      
      setAssignments(mockAssignments);
    } catch (error) {
      console.error("Error loading assignment data:", error);
      setResources([]);
      setAssignments([]);
    }
    setIsLoading(false);
  };

  const handleSaveAssignment = async () => {
    if (!newAssignment.resource_id) {
      alert("Please select a resource");
      return;
    }

    const resource = resources.find(r => r.id === newAssignment.resource_id);
    if (!resource) return;

    const assignment = {
      id: Date.now().toString(),
      resource_id: newAssignment.resource_id,
      assignment_units: newAssignment.assignment_units,
      rate_override: newAssignment.rate_override,
      allocation_curve: newAssignment.allocation_curve,
      work_hours: (selectedTask?.duration_days || 1) * 8 * (newAssignment.assignment_units / 100),
      actual_work_hours: 0,
      assignment_cost: ((selectedTask?.duration_days || 1) * 8 * (newAssignment.assignment_units / 100)) * (newAssignment.rate_override || resource.standard_rate || 0),
      actual_cost: 0,
      resource_name: resource.name
    };

    const updatedAssignments = editingAssignment 
      ? assignments.map(a => a.id === editingAssignment.id ? { ...assignment, id: editingAssignment.id } : a)
      : [...assignments, assignment];

    setAssignments(updatedAssignments);
    
    // Notify parent component
    if (onAssignmentUpdate) {
      onAssignmentUpdate(selectedTask.id, updatedAssignments);
    }

    resetForm();
  };

  const handleEditAssignment = (assignment) => {
    setEditingAssignment(assignment);
    setNewAssignment({
      resource_id: assignment.resource_id,
      assignment_units: assignment.assignment_units,
      rate_override: assignment.rate_override,
      allocation_curve: assignment.allocation_curve
    });
    setShowAddDialog(true);
  };

  const handleDeleteAssignment = (assignmentId) => {
    const updatedAssignments = assignments.filter(a => a.id !== assignmentId);
    setAssignments(updatedAssignments);
    
    if (onAssignmentUpdate) {
      onAssignmentUpdate(selectedTask.id, updatedAssignments);
    }
  };

  const resetForm = () => {
    setNewAssignment({
      resource_id: "",
      assignment_units: 100,
      rate_override: 0,
      allocation_curve: "uniform"
    });
    setEditingAssignment(null);
    setShowAddDialog(false);
  };

  const calculateTotalCost = () => {
    return assignments.reduce((sum, assignment) => sum + (assignment.assignment_cost || 0), 0);
  };

  const calculateTotalHours = () => {
    return assignments.reduce((sum, assignment) => sum + (assignment.work_hours || 0), 0);
  };

  const getResourceUtilization = (resourceId) => {
    const resourceAssignments = assignments.filter(a => a.resource_id === resourceId);
    return resourceAssignments.reduce((sum, a) => sum + a.assignment_units, 0);
  };

  if (!selectedTask) return null;

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-purple-600" />
              Resource Assignment - {selectedTask.name}
            </DialogTitle>
            <DialogDescription>
              Assign resources to this task and configure allocation details.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Task Summary */}
            <Card className="bg-slate-50">
              <CardContent className="p-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <Label className="text-slate-600">Duration</Label>
                    <p className="font-medium">{selectedTask.duration_days || 0} days</p>
                  </div>
                  <div>
                    <Label className="text-slate-600">Status</Label>
                    <Badge className="mt-1">{selectedTask.status}</Badge>
                  </div>
                  <div>
                    <Label className="text-slate-600">Priority</Label>
                    <Badge variant="outline" className="mt-1">{selectedTask.priority}</Badge>
                  </div>
                  <div>
                    <Label className="text-slate-600">WBS Code</Label>
                    <p className="font-mono text-xs">{selectedTask.wbs_code}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Tabs defaultValue="assignments" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="assignments">Current Assignments</TabsTrigger>
                <TabsTrigger value="resources">Available Resources</TabsTrigger>
                <TabsTrigger value="summary">Assignment Summary</TabsTrigger>
              </TabsList>

              <TabsContent value="assignments" className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold">Resource Assignments</h3>
                  <Button onClick={() => setShowAddDialog(true)} className="gap-2">
                    <Plus className="w-4 h-4" />
                    Add Assignment
                  </Button>
                </div>

                {assignments.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Resource</TableHead>
                        <TableHead>Units</TableHead>
                        <TableHead>Work Hours</TableHead>
                        <TableHead>Cost</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {assignments.map((assignment) => {
                        const resource = resources.find(r => r.id === assignment.resource_id);
                        return (
                          <TableRow key={assignment.id}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Users className="w-4 h-4 text-slate-400" />
                                <span>{resource?.name || assignment.resource_name || 'Unknown Resource'}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{assignment.assignment_units}%</Badge>
                            </TableCell>
                            <TableCell>{assignment.work_hours?.toFixed(1) || 0}h</TableCell>
                            <TableCell>${assignment.assignment_cost?.toFixed(2) || 0}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleEditAssignment(assignment)}
                                >
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="text-red-600"
                                  onClick={() => handleDeleteAssignment(assignment.id)}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-slate-500">
                    <Users className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                    <p>No resources assigned to this task</p>
                    <Button 
                      onClick={() => setShowAddDialog(true)} 
                      className="mt-2 gap-2"
                      variant="outline"
                    >
                      <Plus className="w-4 h-4" />
                      Add First Assignment
                    </Button>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="resources" className="space-y-4">
                <h3 className="text-lg font-semibold">Available Resources</h3>
                <ScrollArea className="h-64">
                  <div className="space-y-2">
                    {resources.map((resource) => {
                      const utilization = getResourceUtilization(resource.id);
                      const isOverallocated = utilization > 100;
                      
                      return (
                        <Card key={resource.id} className={`p-3 ${isOverallocated ? 'border-red-200 bg-red-50' : ''}`}>
                          <div className="flex justify-between items-center">
                            <div>
                              <p className="font-medium">{resource.name}</p>
                              <p className="text-sm text-slate-600">{resource.role || resource.type}</p>
                            </div>
                            <div className="text-right">
                              <Badge variant={isOverallocated ? "destructive" : utilization > 80 ? "secondary" : "default"}>
                                {utilization}% utilized
                              </Badge>
                              <p className="text-sm text-slate-600">${resource.standard_rate || 0}/hr</p>
                            </div>
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="summary" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2">
                        <Clock className="w-5 h-5 text-blue-500" />
                        <div>
                          <p className="text-sm text-slate-600">Total Work Hours</p>
                          <p className="text-xl font-bold">{calculateTotalHours().toFixed(1)}h</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-5 h-5 text-green-500" />
                        <div>
                          <p className="text-sm text-slate-600">Total Cost</p>
                          <p className="text-xl font-bold">${calculateTotalCost().toFixed(2)}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2">
                        <Users className="w-5 h-5 text-purple-500" />
                        <div>
                          <p className="text-sm text-slate-600">Resources Assigned</p>
                          <p className="text-xl font-bold">{assignments.length}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add/Edit Assignment Dialog */}
      <Dialog open={showAddDialog} onOpenChange={() => resetForm()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingAssignment ? "Edit Assignment" : "Add Resource Assignment"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Resource</Label>
              <Select 
                value={newAssignment.resource_id} 
                onValueChange={(value) => setNewAssignment(prev => ({...prev, resource_id: value}))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a resource" />
                </SelectTrigger>
                <SelectContent>
                  {resources.map(resource => (
                    <SelectItem key={resource.id} value={resource.id}>
                      {resource.name} - {resource.role || resource.type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Assignment Units (%)</Label>
              <div className="px-3">
                <Slider
                  value={[newAssignment.assignment_units]}
                  onValueChange={([value]) => setNewAssignment(prev => ({...prev, assignment_units: value}))}
                  max={200}
                  min={25}
                  step={25}
                />
              </div>
              <p className="text-sm text-slate-600">{newAssignment.assignment_units}% allocation</p>
            </div>

            <div className="space-y-2">
              <Label>Rate Override ($/hour)</Label>
              <Input
                type="number"
                value={newAssignment.rate_override}
                onChange={(e) => setNewAssignment(prev => ({...prev, rate_override: parseFloat(e.target.value) || 0}))}
                placeholder="Leave 0 for standard rate"
              />
            </div>

            <div className="space-y-2">
              <Label>Allocation Curve</Label>
              <Select 
                value={newAssignment.allocation_curve} 
                onValueChange={(value) => setNewAssignment(prev => ({...prev, allocation_curve: value}))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="uniform">Uniform</SelectItem>
                  <SelectItem value="front_loaded">Front Loaded</SelectItem>
                  <SelectItem value="back_loaded">Back Loaded</SelectItem>
                  <SelectItem value="bell_curve">Bell Curve</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => resetForm()}>
              Cancel
            </Button>
            <Button onClick={handleSaveAssignment}>
              {editingAssignment ? "Update Assignment" : "Add Assignment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}