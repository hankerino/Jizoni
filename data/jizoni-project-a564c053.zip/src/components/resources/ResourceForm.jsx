import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ResourceForm({ open, onOpenChange, resource, onSave, projects }) {
  const [currentResource, setCurrentResource] = React.useState({});

  React.useEffect(() => {
    setCurrentResource(resource || {
      name: "",
      email: "",
      role: "",
      type: "person",
      project_id: null,
      standard_rate: 0,
      max_units: 100
    });
  }, [resource]);

  const handleSave = () => {
    if (!currentResource.name.trim()) {
      alert("Please enter a resource name");
      return;
    }
    onSave(currentResource);
  };
  
  const handleChange = (field, value) => {
    setCurrentResource(prev => ({...prev, [field]: value}));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{resource?.id ? "Edit Resource" : "Add New Resource"}</DialogTitle>
          <DialogDescription>
            {resource?.id ? "Update the details for this resource." : "Add a new team member, equipment, or resource to your project."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={currentResource.name || ""}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="e.g., John Doe, Crane-01"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Type</Label>
              <Select value={currentResource.type} onValueChange={(value) => handleChange('type', value)}>
                <SelectTrigger id="type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="person">Person</SelectItem>
                  <SelectItem value="equipment">Equipment</SelectItem>
                  <SelectItem value="material">Material</SelectItem>
                  <SelectItem value="cost">Cost Resource</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {currentResource.type === 'person' && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={currentResource.email || ""}
                    onChange={(e) => handleChange('email', e.target.value)}
                    placeholder="john.doe@company.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role">Role/Position</Label>
                  <Input
                    id="role"
                    value={currentResource.role || ""}
                    onChange={(e) => handleChange('role', e.target.value)}
                    placeholder="Project Manager, Engineer, etc."
                  />
                </div>
              </div>
            </>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="max_units">Max Units (%)</Label>
              <Input
                id="max_units"
                type="number"
                min="0"
                max="500"
                value={currentResource.max_units || 100}
                onChange={(e) => handleChange('max_units', parseInt(e.target.value) || 100)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="standard_rate">Hourly Rate ($)</Label>
              <Input
                id="standard_rate"
                type="number"
                min="0"
                step="0.01"
                value={currentResource.standard_rate || 0}
                onChange={(e) => handleChange('standard_rate', parseFloat(e.target.value) || 0)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="project_id">Assign to Project (Optional)</Label>
            <Select 
              value={currentResource.project_id || ""} 
              onValueChange={(value) => handleChange('project_id', value || null)}
            >
              <SelectTrigger id="project_id">
                <SelectValue placeholder="Global resource (no specific project)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>Global Resource</SelectItem>
                {projects.map(project => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
            {resource?.id ? "Update Resource" : "Add Resource"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}