import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { BarChart3, Settings, Baseline as BaselineIcon } from "lucide-react";
import { motion } from "framer-motion";

export default function GanttChart({ tasks = [], criticalPath = [], baselines = [], comparedBaselineId, onCompareBaseline }) {
  const [viewMode, setViewMode] = useState("weeks");
  const [zoomLevel, setZoomLevel] = useState([100]);
  const [showSettings, setShowSettings] = useState(false);
  const [ganttSettings, setGanttSettings] = useState({
    showTaskNames: true,
    showWBSCodes: true,
    showBaseline: true,
    showCriticalPath: true,
    showProgress: true,
    showMilestones: true,
    colorByStatus: true,
    autoScroll: false,
    highlightWeekends: false,
    showGridLines: true
  });

  const comparedBaseline = baselines.find(b => b.id === comparedBaselineId);
  const baselineTasksMap = comparedBaseline && comparedBaseline.baseline_data && comparedBaseline.baseline_data.tasks
    ? new Map(comparedBaseline.baseline_data.tasks.map(t => [t.id, t]))
    : null;

  const handleSettingChange = (key, value) => {
    setGanttSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const getDateRange = () => {
    const defaultStartDate = new Date();
    const defaultEndDate = new Date(defaultStartDate);
    defaultEndDate.setDate(defaultEndDate.getDate() + 30);

    if (!tasks || tasks.length === 0) {
      return { start: defaultStartDate, end: defaultEndDate };
    }

    let allDates = tasks
      .filter(task => task.start_date && task.end_date)
      .flatMap(task => [new Date(task.start_date), new Date(task.end_date)]);

    if (comparedBaseline && comparedBaseline.baseline_data && comparedBaseline.baseline_data.tasks) {
      const baselineDates = comparedBaseline.baseline_data.tasks
        .filter(task => task.start_date && task.end_date)
        .flatMap(task => [new Date(task.start_date), new Date(task.end_date)]);
      allDates = [...allDates, ...baselineDates];
    }

    if (allDates.length === 0) {
      return { start: defaultStartDate, end: defaultEndDate };
    }

    return {
      start: new Date(Math.min(...allDates)),
      end: new Date(Math.max(...allDates))
    };
  };

  const { start: projectStart, end: projectEnd } = getDateRange();

  const generateTimeline = () => {
    const timeline = [];
    if (projectStart >= projectEnd) return [];
    const current = new Date(projectStart);
    const end = new Date(projectEnd);

    while (current <= end) {
      timeline.push(new Date(current));
      if (viewMode === "days") {
        current.setDate(current.getDate() + 1);
      } else if (viewMode === "weeks") {
        current.setDate(current.getDate() + 7);
      } else {
        current.setMonth(current.getMonth() + 1);
      }
    }
    return timeline;
  };

  const timeline = generateTimeline();
  const totalDuration = projectEnd - projectStart;

  const getTaskBarStyle = (startDate, endDate) => {
    if (!startDate || !endDate || totalDuration <= 0) return { left: '0%', width: '0%' };

    const taskStart = new Date(startDate);
    const taskEnd = new Date(endDate);

    const left = ((taskStart - projectStart) / totalDuration) * 100;
    const width = ((taskEnd - taskStart) / totalDuration) * 100;

    return { left: `${Math.max(left, 0)}%`, width: `${Math.max(width, 0.5)}%` };
  };

  const getTaskStyling = (task) => {
    const isCritical = criticalPath.includes(task.id);
    const baseClasses = "h-5 rounded-sm flex items-center px-2 text-xs font-medium transition-all text-white absolute";

    if (isCritical && ganttSettings.showCriticalPath) {
      return `${baseClasses} bg-red-500 border-2 border-red-700`;
    }

    if (!ganttSettings.colorByStatus) {
      return `${baseClasses} bg-slate-400`;
    }

    switch (task.status) {
      case 'completed':
        return `${baseClasses} bg-green-500`;
      case 'in_progress':
        return `${baseClasses} bg-blue-500`;
      case 'on_hold':
        return `${baseClasses} bg-yellow-500`;
      default:
        return `${baseClasses} bg-slate-400`;
    }
  };

  const formatTimelineDate = (date) => {
    if (viewMode === "days") {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    } else if (viewMode === "weeks") {
      const oneDay = 24 * 60 * 60 * 1000;
      const firstDay = new Date(projectStart.getFullYear(), projectStart.getMonth(), projectStart.getDate());
      const diffDays = Math.round(Math.abs((date - firstDay) / oneDay));
      const weekNumber = Math.ceil(diffDays / 7) + 1;
      return `W${weekNumber}`;
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    }
  };

  return (
    <>
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              Interactive Gantt Chart
              <Badge variant="outline">
                {tasks.length} tasks shown
              </Badge>
            </CardTitle>
            <div className="flex gap-2 items-center">
              <Select value={viewMode} onValueChange={setViewMode}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="days">Days</SelectItem>
                  <SelectItem value="weeks">Weeks</SelectItem>
                  <SelectItem value="months">Months</SelectItem>
                </SelectContent>
              </Select>

              <Select value={comparedBaselineId || ""} onValueChange={(value) => onCompareBaseline(value === "none" ? null : value)}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Compare baseline..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No baseline comparison</SelectItem>
                  {baselines.map(baseline => (
                    <SelectItem key={baseline.id} value={baseline.id}>
                      {baseline.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button
                variant="outline"
                size="icon"
                onClick={() => setShowSettings(true)}
              >
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-600">Zoom:</span>
              <div className="w-32">
                <Slider
                  value={zoomLevel}
                  onValueChange={setZoomLevel}
                  max={200}
                  min={50}
                  step={10}
                />
              </div>
              <span className="text-sm text-slate-600">{zoomLevel[0]}%</span>
            </div>

            {comparedBaseline && (
              <Badge variant="outline" className="bg-slate-200 text-slate-700 border-slate-300">
                <BaselineIcon className="w-3 h-3 mr-1" /> Comparing: {comparedBaseline.name}
              </Badge>
            )}
          </div>
        </CardHeader>

        <CardContent>
          <div className="overflow-x-auto">
            <div className="min-w-[1200px]" style={{ transform: `scale(${zoomLevel[0] / 100})`, transformOrigin: 'top left' }}>
              {/* Timeline Header */}
              <div className={`grid grid-cols-12 mb-4 sticky top-0 bg-white/90 z-10 ${ganttSettings.showGridLines ? 'border-b border-slate-200' : ''}`}>
                <div className="col-span-4 font-semibold text-slate-700 py-2">
                  Task Name
                </div>
                <div className="col-span-8 relative">
                  <div className="flex">
                    {timeline.map((date, index) => (
                      <div
                        key={index}
                        className={`flex-1 text-center py-2 text-xs font-medium text-slate-600 ${ganttSettings.showGridLines ? 'border-r border-slate-100' : ''}`}
                      >
                        {formatTimelineDate(date)}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Task Rows */}
              <div className="space-y-1">
                {tasks.map((task, index) => {
                  const baselineTask = baselineTasksMap?.get(task.id);
                  return (
                    <motion.div
                      key={task.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.02 }}
                      className="grid grid-cols-12 hover:bg-slate-50 rounded-lg transition-colors"
                    >
                      <div className="col-span-4 py-2 px-2 truncate">
                        {ganttSettings.showWBSCodes && task.wbs_code && (
                          <span className="font-mono text-xs text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                            {task.wbs_code}
                          </span>
                        )}
                        {ganttSettings.showTaskNames && (
                          <span className={`${ganttSettings.showWBSCodes && task.wbs_code ? 'ml-2' : ''} font-medium text-slate-900`}>
                            {task.name}
                          </span>
                        )}
                      </div>

                      <div className="col-span-8 py-2 px-2 relative h-10">
                        {ganttSettings.showBaseline && comparedBaseline && baselineTask && (
                          <div
                            className="h-3 bg-slate-300 rounded-sm absolute"
                            style={{
                              ...getTaskBarStyle(baselineTask.start_date, baselineTask.end_date),
                              top: '20px'
                            }}
                            title={`Baseline: ${baselineTask.name} (${baselineTask.start_date ? new Date(baselineTask.start_date).toLocaleDateString() : 'N/A'} - ${baselineTask.end_date ? new Date(baselineTask.end_date).toLocaleDateString() : 'N/A'})`}
                          />
                        )}
                        {task.start_date && task.end_date && (
                          <div
                            className={getTaskStyling(task)}
                            style={{
                              ...getTaskBarStyle(task.start_date, task.end_date),
                              top: '2px'
                            }}
                            title={`${task.name} (${new Date(task.start_date).toLocaleDateString()} - ${new Date(task.end_date).toLocaleDateString()})`}
                          >
                            <span className="truncate">{task.name}</span>
                            {ganttSettings.showProgress && task.completion_percentage !== undefined && (
                              <div
                                className="absolute inset-0 bg-white/20 rounded-sm"
                                style={{ width: `${task.completion_percentage}%` }}
                              />
                            )}
                          </div>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              {tasks.length === 0 && (
                <div className="text-center py-12">
                  <BarChart3 className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-600 mb-2">No tasks to display</h3>
                  <p className="text-slate-500">
                    Create tasks in your project or adjust your filters to see the Gantt chart.
                  </p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Gantt Chart Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Gantt Chart Settings
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-3">
              <Label className="text-sm font-medium">Display Options</Label>

              <div className="flex items-center justify-between">
                <Label htmlFor="show-task-names" className="text-sm">Show Task Names</Label>
                <Switch
                  id="show-task-names"
                  checked={ganttSettings.showTaskNames}
                  onCheckedChange={(checked) => handleSettingChange('showTaskNames', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="show-wbs-codes" className="text-sm">Show WBS Codes</Label>
                <Switch
                  id="show-wbs-codes"
                  checked={ganttSettings.showWBSCodes}
                  onCheckedChange={(checked) => handleSettingChange('showWBSCodes', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="show-baseline" className="text-sm">Show Baseline</Label>
                <Switch
                  id="show-baseline"
                  checked={ganttSettings.showBaseline}
                  onCheckedChange={(checked) => handleSettingChange('showBaseline', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="show-progress" className="text-sm">Show Progress</Label>
                <Switch
                  id="show-progress"
                  checked={ganttSettings.showProgress}
                  onCheckedChange={(checked) => handleSettingChange('showProgress', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="show-grid-lines" className="text-sm">Show Grid Lines</Label>
                <Switch
                  id="show-grid-lines"
                  checked={ganttSettings.showGridLines}
                  onCheckedChange={(checked) => handleSettingChange('showGridLines', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="color-by-status" className="text-sm">Color by Status</Label>
                <Switch
                  id="color-by-status"
                  checked={ganttSettings.colorByStatus}
                  onCheckedChange={(checked) => handleSettingChange('colorByStatus', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="show-critical-path-setting" className="text-sm">Highlight Critical Path</Label>
                <Switch
                  id="show-critical-path-setting"
                  checked={ganttSettings.showCriticalPath}
                  onCheckedChange={(checked) => handleSettingChange('showCriticalPath', checked)}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setShowSettings(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}