import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Target, 
  TrendingUp, 
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  Clock,
  Calendar,
  DollarSign
} from "lucide-react";
import { motion } from "framer-motion";
import { format, parseISO, isAfter, isBefore } from "date-fns";

export default function ProgressSpotlight({ 
  tasks = [], 
  dataDate, 
  onDataDateChange, 
  showProgressBars = true, 
  showEarnedValue = true 
}) {
  const [selectedView, setSelectedView] = useState("overview");

  // Calculate progress metrics
  const progressMetrics = useMemo(() => {
    if (!tasks || tasks.length === 0) {
      return {
        totalTasks: 0,
        completedTasks: 0,
        inProgressTasks: 0,
        overdueTasks: 0,
        upcomingTasks: 0,
        completionPercentage: 0,
        onTimePercentage: 0,
        totalPlannedValue: 0,
        totalEarnedValue: 0,
        totalActualCost: 0
      };
    }

    const currentDate = dataDate ? parseISO(dataDate) : new Date();
    
    const completedTasks = tasks.filter(t => t.status === 'completed');
    const inProgressTasks = tasks.filter(t => t.status === 'in_progress');
    const overdueTasks = tasks.filter(t => 
      t.end_date && 
      isAfter(currentDate, parseISO(t.end_date)) && 
      t.status !== 'completed'
    );
    const upcomingTasks = tasks.filter(t => 
      t.start_date && 
      isAfter(parseISO(t.start_date), currentDate) &&
      t.status === 'not_started'
    );

    const completionPercentage = Math.round((completedTasks.length / tasks.length) * 100);
    const onTimePercentage = Math.round(((tasks.length - overdueTasks.length) / tasks.length) * 100);

    const totalPlannedValue = tasks.reduce((sum, t) => sum + (t.planned_value || 0), 0);
    const totalEarnedValue = tasks.reduce((sum, t) => sum + (t.earned_value || 0), 0);
    const totalActualCost = tasks.reduce((sum, t) => sum + (t.actual_cost || 0), 0);

    return {
      totalTasks: tasks.length,
      completedTasks: completedTasks.length,
      inProgressTasks: inProgressTasks.length,
      overdueTasks: overdueTasks.length,
      upcomingTasks: upcomingTasks.length,
      completionPercentage,
      onTimePercentage,
      totalPlannedValue,
      totalEarnedValue,
      totalActualCost
    };
  }, [tasks, dataDate]);

  // Categorize tasks by status for detailed view
  const categorizedTasks = useMemo(() => {
    if (!tasks || tasks.length === 0) return {};

    const currentDate = dataDate ? parseISO(dataDate) : new Date();

    return {
      completed: tasks.filter(t => t.status === 'completed'),
      inProgress: tasks.filter(t => t.status === 'in_progress'),
      overdue: tasks.filter(t => 
        t.end_date && 
        isAfter(currentDate, parseISO(t.end_date)) && 
        t.status !== 'completed'
      ),
      upcoming: tasks.filter(t => 
        t.start_date && 
        isAfter(parseISO(t.start_date), currentDate) &&
        t.status === 'not_started'
      ),
      notStarted: tasks.filter(t => t.status === 'not_started')
    };
  }, [tasks, dataDate]);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const TaskStatusBadge = ({ status }) => {
    const statusStyles = {
      completed: 'bg-green-100 text-green-700',
      in_progress: 'bg-blue-100 text-blue-700',
      not_started: 'bg-slate-100 text-slate-700',
      on_hold: 'bg-yellow-100 text-yellow-700'
    };

    return (
      <Badge className={statusStyles[status] || statusStyles.not_started}>
        {status.replace('_', ' ')}
      </Badge>
    );
  };

  const TaskCard = ({ task, isOverdue = false }) => (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`p-4 border rounded-lg bg-white hover:bg-slate-50 transition-colors ${
        isOverdue ? 'border-red-200 bg-red-50' : 'border-slate-200'
      }`}
    >
      <div className="flex justify-between items-start mb-2">
        <h4 className="font-semibold text-slate-900">{task.name}</h4>
        <TaskStatusBadge status={task.status} />
      </div>
      
      <div className="space-y-2">
        {task.wbs_code && (
          <div className="text-sm text-slate-600">
            WBS: {task.wbs_code}
          </div>
        )}
        
        {showProgressBars && task.completion_percentage !== undefined && (
          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span>{task.completion_percentage}%</span>
            </div>
            <Progress value={task.completion_percentage} className="h-2" />
          </div>
        )}

        <div className="flex items-center gap-4 text-sm text-slate-500">
          {task.start_date && (
            <div className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {format(parseISO(task.start_date), 'MMM d')}
            </div>
          )}
          {task.end_date && (
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {format(parseISO(task.end_date), 'MMM d')}
            </div>
          )}
          {task.duration_days && (
            <div>
              {task.duration_days}d
            </div>
          )}
        </div>

        {showEarnedValue && (task.planned_value || task.earned_value || task.actual_cost) && (
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="text-center p-1 bg-blue-50 rounded">
              <div className="font-medium">PV</div>
              <div>{formatCurrency(task.planned_value || 0)}</div>
            </div>
            <div className="text-center p-1 bg-green-50 rounded">
              <div className="font-medium">EV</div>
              <div>{formatCurrency(task.earned_value || 0)}</div>
            </div>
            <div className="text-center p-1 bg-orange-50 rounded">
              <div className="font-medium">AC</div>
              <div>{formatCurrency(task.actual_cost || 0)}</div>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );

  return (
    <div className="space-y-6">
      {/* Data Date Control */}
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-green-600" />
            Progress Spotlight
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Label htmlFor="data-date" className="text-sm font-medium">Data Date:</Label>
              <Input
                id="data-date"
                type="date"
                value={dataDate}
                onChange={(e) => onDataDateChange(e.target.value)}
                className="w-48"
              />
            </div>
            <Badge variant="outline">
              As of {dataDate ? format(parseISO(dataDate), 'MMM d, yyyy') : 'Today'}
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-green-100 text-xs font-medium">Task Completion</p>
                <h3 className="text-2xl font-bold">{progressMetrics.completionPercentage}%</h3>
                <p className="text-green-100 text-sm">
                  {progressMetrics.completedTasks} of {progressMetrics.totalTasks} tasks
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-blue-100 text-xs font-medium">In Progress</p>
                <h3 className="text-2xl font-bold">{progressMetrics.inProgressTasks}</h3>
                <p className="text-blue-100 text-sm">Active tasks</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white">
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-red-100 text-xs font-medium">Overdue</p>
                <h3 className="text-2xl font-bold">{progressMetrics.overdueTasks}</h3>
                <p className="text-red-100 text-sm">Require attention</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-purple-100 text-xs font-medium">On Schedule</p>
                <h3 className="text-2xl font-bold">{progressMetrics.onTimePercentage}%</h3>
                <p className="text-purple-100 text-sm">Timeline performance</p>
              </div>
              <Target className="w-8 h-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Earned Value Overview */}
      {showEarnedValue && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-blue-600 text-sm font-medium">Planned Value (PV)</p>
                  <h3 className="text-xl font-bold text-blue-900">
                    {formatCurrency(progressMetrics.totalPlannedValue)}
                  </h3>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                  <Target className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-green-600 text-sm font-medium">Earned Value (EV)</p>
                  <h3 className="text-xl font-bold text-green-900">
                    {formatCurrency(progressMetrics.totalEarnedValue)}
                  </h3>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-orange-50 border-orange-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-orange-600 text-sm font-medium">Actual Cost (AC)</p>
                  <h3 className="text-xl font-bold text-orange-900">
                    {formatCurrency(progressMetrics.totalActualCost)}
                  </h3>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Detailed Task Lists */}
      <Tabs value={selectedView} onValueChange={setSelectedView} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="completed">Completed ({categorizedTasks.completed?.length || 0})</TabsTrigger>
          <TabsTrigger value="inProgress">In Progress ({categorizedTasks.inProgress?.length || 0})</TabsTrigger>
          <TabsTrigger value="overdue">Overdue ({categorizedTasks.overdue?.length || 0})</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming ({categorizedTasks.upcoming?.length || 0})</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
            <CardHeader>
              <CardTitle>Project Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-semibold text-slate-900">Task Distribution</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Completed</span>
                        <span className="font-medium">{progressMetrics.completedTasks}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>In Progress</span>
                        <span className="font-medium">{progressMetrics.inProgressTasks}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Overdue</span>
                        <span className="font-medium text-red-600">{progressMetrics.overdueTasks}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Upcoming</span>
                        <span className="font-medium">{progressMetrics.upcomingTasks}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="font-semibold text-slate-900">Progress Indicators</h4>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Overall Completion</span>
                          <span className="text-sm font-medium">{progressMetrics.completionPercentage}%</span>
                        </div>
                        <Progress value={progressMetrics.completionPercentage} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">On-Time Performance</span>
                          <span className="text-sm font-medium">{progressMetrics.onTimePercentage}%</span>
                        </div>
                        <Progress 
                          value={progressMetrics.onTimePercentage} 
                          className="h-2"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="completed" className="mt-6">
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                Completed Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              {categorizedTasks.completed && categorizedTasks.completed.length > 0 ? (
                <div className="grid gap-4">
                  {categorizedTasks.completed.map(task => (
                    <TaskCard key={task.id} task={task} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">
                  <CheckCircle className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <p>No completed tasks yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inProgress" className="mt-6">
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                In Progress Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              {categorizedTasks.inProgress && categorizedTasks.inProgress.length > 0 ? (
                <div className="grid gap-4">
                  {categorizedTasks.inProgress.map(task => (
                    <TaskCard key={task.id} task={task} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">
                  <TrendingUp className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <p>No tasks currently in progress</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="overdue" className="mt-6">
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                Overdue Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              {categorizedTasks.overdue && categorizedTasks.overdue.length > 0 ? (
                <div className="grid gap-4">
                  {categorizedTasks.overdue.map(task => (
                    <TaskCard key={task.id} task={task} isOverdue={true} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-green-500">
                  <CheckCircle className="w-16 h-16 text-green-300 mx-auto mb-4" />
                  <p>Great! No overdue tasks</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upcoming" className="mt-6">
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-purple-600" />
                Upcoming Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              {categorizedTasks.upcoming && categorizedTasks.upcoming.length > 0 ? (
                <div className="grid gap-4">
                  {categorizedTasks.upcoming.map(task => (
                    <TaskCard key={task.id} task={task} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">
                  <Clock className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <p>No upcoming tasks scheduled</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}