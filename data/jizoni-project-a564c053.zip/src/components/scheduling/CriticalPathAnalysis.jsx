import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Target, Clock, AlertTriangle, TrendingUp, Zap } from "lucide-react";
import { motion } from "framer-motion";

export default function CriticalPathAnalysis({ tasks, criticalPath, scheduleMetrics }) {
  const criticalTasks = tasks.filter(task => criticalPath.includes(task.id));
  const nonCriticalTasks = tasks.filter(task => !criticalPath.includes(task.id));

  const calculateFloat = (task) => {
    // Simplified float calculation - in reality this would use proper CPM algorithms
    if (criticalPath.includes(task.id)) return 0;
    return Math.floor(Math.random() * 5) + 1; // Simulated float for demo
  };

  const getFloatColor = (floatDays) => {
    if (floatDays === 0) return "text-red-600";
    if (floatDays <= 2) return "text-orange-600";
    return "text-green-600";
  };

  const getTaskRisk = (task) => {
    if (criticalPath.includes(task.id)) return "High";
    const floatDays = calculateFloat(task);
    if (floatDays <= 2) return "Medium";
    return "Low";
  };

  const getRiskColor = (risk) => {
    switch (risk) {
      case "High": return "bg-red-100 text-red-700 border-red-200";
      case "Medium": return "bg-orange-100 text-orange-700 border-orange-200";
      case "Low": return "bg-green-100 text-green-700 border-green-200";
      default: return "bg-slate-100 text-slate-700 border-slate-200";
    }
  };

  return (
    <div className="space-y-6">
      {/* Analysis Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white border-0">
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-red-100 text-xs font-medium">Critical Tasks</p>
                <h3 className="text-2xl font-bold">{criticalTasks.length}</h3>
              </div>
              <Target className="w-5 h-5 text-red-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0">
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-blue-100 text-xs font-medium">Critical Path Duration</p>
                <h3 className="text-2xl font-bold">{scheduleMetrics?.critical_path_duration || 0}d</h3>
              </div>
              <Clock className="w-5 h-5 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0">
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-green-100 text-xs font-medium">Total Float</p>
                <h3 className="text-2xl font-bold">{scheduleMetrics?.total_float_days || 0}d</h3>
              </div>
              <TrendingUp className="w-5 h-5 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0">
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-purple-100 text-xs font-medium">Schedule Risk</p>
                <h3 className="text-lg font-bold">{scheduleMetrics?.schedule_risk || "Medium"}</h3>
              </div>
              <AlertTriangle className="w-5 h-5 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Critical Path Tasks */}
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-red-600" />
            Critical Path Tasks
            <Badge className="bg-red-100 text-red-700 border-red-200">
              {criticalTasks.length} tasks
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {criticalTasks.length > 0 ? (
            <div className="space-y-3">
              {criticalTasks.map((task, index) => (
                <motion.div
                  key={task.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="border-l-4 border-red-500 bg-red-50 p-4 rounded-r-lg"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-mono text-xs text-red-600 bg-red-100 px-2 py-1 rounded">
                          {task.wbs_code}
                        </span>
                        <h4 className="font-semibold text-slate-900">{task.name}</h4>
                        <Badge className="bg-red-100 text-red-700 border-red-200">
                          Critical
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-600 mb-2">{task.description}</p>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="text-slate-600">
                          Duration: <span className="font-medium">{task.duration_days || 0} days</span>
                        </span>
                        <span className="text-slate-600">
                          Assigned: <span className="font-medium">{task.assigned_to || "Unassigned"}</span>
                        </span>
                        <span className={getFloatColor(0)}>
                          Float: <span className="font-medium">0 days</span>
                        </span>
                      </div>
                    </div>
                    <Badge className={getRiskColor("High")} variant="outline">
                      High Risk
                    </Badge>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Target className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-600">No critical path calculated yet</p>
              <p className="text-sm text-slate-500">Add task dependencies to calculate the critical path</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Near-Critical Tasks */}
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            Near-Critical Tasks
            <Badge className="bg-orange-100 text-orange-700 border-orange-200">
              Low float
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {nonCriticalTasks.slice(0, 5).map((task, index) => {
              const floatDays = calculateFloat(task);
              const risk = getTaskRisk(task);
              
              return (
                <motion.div
                  key={task.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="border border-slate-200 p-4 rounded-lg hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-mono text-xs text-slate-500 bg-slate-100 px-2 py-1 rounded">
                          {task.wbs_code}
                        </span>
                        <h4 className="font-medium text-slate-900">{task.name}</h4>
                      </div>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="text-slate-600">
                          Duration: <span className="font-medium">{task.duration_days || 0} days</span>
                        </span>
                        <span className={getFloatColor(floatDays)}>
                          Float: <span className="font-medium">{floatDays} days</span>
                        </span>
                      </div>
                    </div>
                    <Badge className={getRiskColor(risk)} variant="outline">
                      {risk} Risk
                    </Badge>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      {scheduleMetrics?.recommendations && (
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-blue-600" />
              AI Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {scheduleMetrics.recommendations.map((recommendation, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-3 p-3 bg-blue-50 border border-blue-200 rounded-lg"
                >
                  <Zap className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-blue-800">{recommendation}</p>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}