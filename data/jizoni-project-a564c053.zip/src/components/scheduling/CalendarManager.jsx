import React, { useState } from "react";
import { Calendar as CalendarEntity } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Calendar as CalendarIcon, 
  Plus, 
  Star, 
  Clock,
  Trash2,
  Edit
} from "lucide-react";
import { motion } from "framer-motion";

export default function CalendarManager({ calendars, onCalendarsUpdate }) {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingCalendar, setEditingCalendar] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [newCalendar, setNewCalendar] = useState({
    name: "",
    description: "",
    calendar_type: "standard",
    working_days: [1, 2, 3, 4, 5], // Monday to Friday
    working_hours: {
      start: "08:00",
      end: "17:00",
      lunch_start: "12:00",
      lunch_end: "13:00"
    },
    holidays: [],
    is_default: false
  });

  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

  const handleSaveCalendar = async () => {
    if (!newCalendar.name.trim()) {
      alert("Please enter a calendar name");
      return;
    }

    setIsLoading(true);
    try {
      if (editingCalendar) {
        await CalendarEntity.update(editingCalendar.id, newCalendar);
      } else {
        await CalendarEntity.create(newCalendar);
      }
      
      setShowCreateDialog(false);
      setEditingCalendar(null);
      resetForm();
      onCalendarsUpdate();
    } catch (error) {
      console.error("Error saving calendar:", error);
      alert("Failed to save calendar. Please try again.");
    }
    setIsLoading(false);
  };

  const handleEditCalendar = (calendar) => {
    setEditingCalendar(calendar);
    setNewCalendar({
      name: calendar.name,
      description: calendar.description || "",
      calendar_type: calendar.calendar_type,
      working_days: calendar.working_days || [1, 2, 3, 4, 5],
      working_hours: calendar.working_hours || {
        start: "08:00",
        end: "17:00",
        lunch_start: "12:00",
        lunch_end: "13:00"
      },
      holidays: calendar.holidays || [],
      is_default: calendar.is_default || false
    });
    setShowCreateDialog(true);
  };

  const handleDeleteCalendar = async (calendar) => {
    if (calendar.is_default) {
      alert("Cannot delete the default calendar.");
      return;
    }

    if (window.confirm(`Are you sure you want to delete calendar "${calendar.name}"?`)) {
      try {
        await CalendarEntity.delete(calendar.id);
        onCalendarsUpdate();
      } catch (error) {
        console.error("Error deleting calendar:", error);
        alert("Failed to delete calendar. Please try again.");
      }
    }
  };

  const handleSetDefault = async (calendarId) => {
    try {
      // First, unset all calendars as default
      await Promise.all(
        calendars.map(cal => 
          CalendarEntity.update(cal.id, { ...cal, is_default: cal.id === calendarId })
        )
      );
      onCalendarsUpdate();
    } catch (error) {
      console.error("Error setting default calendar:", error);
      alert("Failed to set default calendar. Please try again.");
    }
  };

  const resetForm = () => {
    setNewCalendar({
      name: "",
      description: "",
      calendar_type: "standard",
      working_days: [1, 2, 3, 4, 5],
      working_hours: {
        start: "08:00",
        end: "17:00",
        lunch_start: "12:00",
        lunch_end: "13:00"
      },
      holidays: [],
      is_default: false
    });
  };

  const handleWorkingDayToggle = (dayIndex) => {
    setNewCalendar(prev => ({
      ...prev,
      working_days: prev.working_days.includes(dayIndex)
        ? prev.working_days.filter(d => d !== dayIndex)
        : [...prev.working_days, dayIndex].sort()
    }));
  };

  return (
    <div className="space-y-6">
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-purple-600" />
              Project Calendars
              <Badge className="bg-purple-100 text-purple-700">
                {calendars.length} calendars
              </Badge>
            </CardTitle>
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button 
                  className="bg-purple-600 hover:bg-purple-700 gap-2"
                  onClick={() => {
                    setEditingCalendar(null);
                    resetForm();
                  }}
                >
                  <Plus className="w-4 h-4" />
                  Create Calendar
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>
                    {editingCalendar ? "Edit Calendar" : "Create New Calendar"}
                  </DialogTitle>
                  <DialogDescription>
                    {editingCalendar 
                      ? "Update the calendar settings."
                      : "Create a new work calendar with custom working days and hours."
                    }
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-6 py-4 max-h-96 overflow-y-auto">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="calendar-name">Calendar Name *</Label>
                      <Input
                        id="calendar-name"
                        value={newCalendar.name}
                        onChange={(e) => setNewCalendar(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="e.g., Standard Work Week"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="calendar-type">Calendar Type</Label>
                      <Select 
                        value={newCalendar.calendar_type} 
                        onValueChange={(value) => setNewCalendar(prev => ({ ...prev, calendar_type: value }))}
                      >
                        <SelectTrigger id="calendar-type">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="standard">Standard</SelectItem>
                          <SelectItem value="resource">Resource Specific</SelectItem>
                          <SelectItem value="project">Project Specific</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="calendar-description">Description</Label>
                    <Textarea
                      id="calendar-description"
                      value={newCalendar.description}
                      onChange={(e) => setNewCalendar(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Optional description..."
                      rows={2}
                    />
                  </div>

                  <div className="space-y-3">
                    <Label>Working Days</Label>
                    <div className="grid grid-cols-7 gap-2">
                      {dayNames.map((day, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <Checkbox
                            id={`day-${index}`}
                            checked={newCalendar.working_days.includes(index)}
                            onCheckedChange={() => handleWorkingDayToggle(index)}
                          />
                          <Label htmlFor={`day-${index}`} className="text-xs">
                            {day.slice(0, 3)}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label>Working Hours</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="start-time">Start Time</Label>
                        <Input
                          id="start-time"
                          type="time"
                          value={newCalendar.working_hours.start}
                          onChange={(e) => setNewCalendar(prev => ({
                            ...prev,
                            working_hours: { ...prev.working_hours, start: e.target.value }
                          }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="end-time">End Time</Label>
                        <Input
                          id="end-time"
                          type="time"
                          value={newCalendar.working_hours.end}
                          onChange={(e) => setNewCalendar(prev => ({
                            ...prev,
                            working_hours: { ...prev.working_hours, end: e.target.value }
                          }))}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="lunch-start">Lunch Start</Label>
                        <Input
                          id="lunch-start"
                          type="time"
                          value={newCalendar.working_hours.lunch_start}
                          onChange={(e) => setNewCalendar(prev => ({
                            ...prev,
                            working_hours: { ...prev.working_hours, lunch_start: e.target.value }
                          }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lunch-end">Lunch End</Label>
                        <Input
                          id="lunch-end"
                          type="time"
                          value={newCalendar.working_hours.lunch_end}
                          onChange={(e) => setNewCalendar(prev => ({
                            ...prev,
                            working_hours: { ...prev.working_hours, lunch_end: e.target.value }
                          }))}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="is-default"
                      checked={newCalendar.is_default}
                      onCheckedChange={(checked) => setNewCalendar(prev => ({ ...prev, is_default: checked }))}
                    />
                    <Label htmlFor="is-default">Set as default calendar</Label>
                  </div>
                </div>
                <DialogFooter>
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setShowCreateDialog(false);
                      setEditingCalendar(null);
                    }}
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleSaveCalendar} 
                    disabled={isLoading}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    {isLoading ? "Saving..." : editingCalendar ? "Update Calendar" : "Create Calendar"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {calendars.length > 0 ? (
            <div className="space-y-4">
              {calendars.map((calendar, index) => (
                <motion.div
                  key={calendar.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`p-4 rounded-lg border ${
                    calendar.is_default 
                      ? 'border-purple-200 bg-purple-50' 
                      : 'border-slate-200 bg-white'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold text-slate-900">{calendar.name}</h4>
                        {calendar.is_default && (
                          <Badge className="bg-purple-100 text-purple-700 gap-1">
                            <Star className="w-3 h-3" />
                            Default
                          </Badge>
                        )}
                        <Badge variant="outline">
                          {calendar.calendar_type}
                        </Badge>
                      </div>
                      
                      {calendar.description && (
                        <p className="text-sm text-slate-600 mb-3">{calendar.description}</p>
                      )}
                      
                      <div className="flex items-center gap-6 text-sm text-slate-500">
                        <div className="flex items-center gap-1">
                          <CalendarIcon className="w-4 h-4" />
                          Working Days: {(calendar.working_days || [1,2,3,4,5]).length} days/week
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          Hours: {calendar.working_hours?.start || '08:00'} - {calendar.working_hours?.end || '17:00'}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      {!calendar.is_default && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleSetDefault(calendar.id)}
                        >
                          <Star className="w-4 h-4" />
                          Set Default
                        </Button>
                      )}
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEditCalendar(calendar)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      
                      {!calendar.is_default && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteCalendar(calendar)}
                          className="text-red-600 hover:bg-red-100"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <CalendarIcon className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-600 mb-2">No Calendars Created</h3>
              <p className="text-slate-500 mb-4">
                Create your first work calendar to define working days and hours.
              </p>
              <Button 
                onClick={() => setShowCreateDialog(true)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create First Calendar
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}