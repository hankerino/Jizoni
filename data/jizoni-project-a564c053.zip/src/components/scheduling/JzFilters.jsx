import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { 
  Filter, 
  Plus, 
  Trash2, 
  Search,
  Settings,
  CheckCircle,
  X
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function JzFilters({ onApplyFilters, onClearFilters }) {
  const [matchType, setMatchType] = useState("all");
  const [rules, setRules] = useState([]);
  const [showAddRule, setShowAddRule] = useState(false);

  const [newRule, setNewRule] = useState({
    parameter: "",
    condition: "",
    value: ""
  });

  const availableParameters = [
    { value: "status", label: "Status" },
    { value: "priority", label: "Priority" },
    { value: "assigned_to", label: "Assigned To" },
    { value: "name", label: "Task Name" },
    { value: "wbs_code", label: "WBS Code" },
    { value: "duration_days", label: "Duration (Days)" },
    { value: "completion_percentage", label: "Completion %" },
    { value: "is_critical", label: "Is Critical" }
  ];

  const availableConditions = [
    { value: "is", label: "Is" },
    { value: "is_not", label: "Is Not" },
    { value: "contains", label: "Contains" },
    { value: "does_not_contain", label: "Does Not Contain" },
    { value: "is_less_than", label: "Is Less Than" },
    { value: "is_greater_than", label: "Is Greater Than" }
  ];

  const statusValues = ["not_started", "in_progress", "completed", "on_hold"];
  const priorityValues = ["low", "medium", "high", "critical"];
  const criticalValues = ["true", "false"];

  const getValueOptions = (parameter) => {
    switch (parameter) {
      case "status": return statusValues;
      case "priority": return priorityValues;
      case "is_critical": return criticalValues;
      default: return [];
    }
  };

  const addRule = () => {
    if (newRule.parameter && newRule.condition && newRule.value !== "") {
      setRules([...rules, { ...newRule, id: Date.now() }]);
      setNewRule({ parameter: "", condition: "", value: "" });
      setShowAddRule(false);
    }
  };

  const removeRule = (ruleId) => {
    setRules(rules.filter(rule => rule.id !== ruleId));
  };

  const applyFilters = () => {
    const filterConfig = {
      matchType,
      rules: rules.map(({ id, ...rule }) => rule) // Remove the temporary ID
    };
    onApplyFilters(filterConfig);
  };

  const clearAllFilters = () => {
    setRules([]);
    setMatchType("all");
    onClearFilters();
  };

  const getRuleDisplayText = (rule) => {
    const param = availableParameters.find(p => p.value === rule.parameter)?.label || rule.parameter;
    const condition = availableConditions.find(c => c.value === rule.condition)?.label || rule.condition;
    return `${param} ${condition} "${rule.value}"`;
  };

  return (
    <div className="space-y-6">
      <Card className="bg-white/90 backdrop-blur-sm border-slate-200 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-blue-600" />
            Advanced Task Filters
            {rules.length > 0 && (
              <Badge className="bg-blue-100 text-blue-700">
                {rules.length} active
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Match Type Selection */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Match</Label>
            <Select value={matchType} onValueChange={setMatchType}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All of the following</SelectItem>
                <SelectItem value="any">Any of the following</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500">
              {matchType === "all" ? "Tasks must match ALL rules" : "Tasks must match ANY rule"}
            </p>
          </div>

          {/* Rules Display */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Rules:</Label>
            <AnimatePresence>
              {rules.map((rule, index) => (
                <motion.div
                  key={rule.id}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border"
                >
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="font-mono text-xs">
                      {index + 1}
                    </Badge>
                    <span className="text-sm font-medium text-slate-700">
                      {getRuleDisplayText(rule)}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-8 h-8 text-red-500 hover:bg-red-100"
                    onClick={() => removeRule(rule.id)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </motion.div>
              ))}
            </AnimatePresence>

            {rules.length === 0 && (
              <div className="text-center py-8 text-slate-500">
                <Filter className="w-12 h-12 mx-auto mb-2 opacity-30" />
                <p>No filter rules defined</p>
                <p className="text-xs">Click "Add Rule" to create your first filter</p>
              </div>
            )}
          </div>

          {/* Add Rule Form */}
          <AnimatePresence>
            {showAddRule && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-4 p-4 bg-blue-50 rounded-lg border border-blue-200"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Parameter</Label>
                    <Select 
                      value={newRule.parameter} 
                      onValueChange={(value) => setNewRule({...newRule, parameter: value, value: ""})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select parameter..." />
                      </SelectTrigger>
                      <SelectContent>
                        {availableParameters.map(param => (
                          <SelectItem key={param.value} value={param.value}>
                            {param.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Condition</Label>
                    <Select 
                      value={newRule.condition} 
                      onValueChange={(value) => setNewRule({...newRule, condition: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select condition..." />
                      </SelectTrigger>
                      <SelectContent>
                        {availableConditions.map(condition => (
                          <SelectItem key={condition.value} value={condition.value}>
                            {condition.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Value</Label>
                    {getValueOptions(newRule.parameter).length > 0 ? (
                      <Select 
                        value={newRule.value} 
                        onValueChange={(value) => setNewRule({...newRule, value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select value..." />
                        </SelectTrigger>
                        <SelectContent>
                          {getValueOptions(newRule.parameter).map(value => (
                            <SelectItem key={value} value={value}>
                              {value === "true" ? "Yes" : value === "false" ? "No" : value.replace('_', ' ')}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <Input
                        value={newRule.value}
                        onChange={(e) => setNewRule({...newRule, value: e.target.value})}
                        placeholder="Enter value..."
                      />
                    )}
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowAddRule(false);
                      setNewRule({ parameter: "", condition: "", value: "" });
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={addRule}
                    disabled={!newRule.parameter || !newRule.condition || newRule.value === ""}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Add Rule
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => setShowAddRule(true)}
              disabled={showAddRule}
              className="gap-2"
            >
              <Plus className="w-4 h-4" />
              Add Rule
            </Button>
            
            <Button
              variant="outline"
              onClick={clearAllFilters}
              disabled={rules.length === 0}
              className="gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Clear All
            </Button>
            
            <Button
              onClick={applyFilters}
              disabled={rules.length === 0}
              className="bg-green-600 hover:bg-green-700 gap-2"
            >
              <Filter className="w-4 h-4" />
              Apply Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Active Filters Summary */}
      {rules.length > 0 && (
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="font-medium text-green-800">
                  {rules.length} filter{rules.length > 1 ? 's' : ''} active
                </span>
                <Badge className="bg-green-100 text-green-700">
                  Match {matchType}
                </Badge>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={clearAllFilters}
                className="text-green-700 hover:bg-green-100"
              >
                Clear All
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}