import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Baseline as BaselineIcon, 
  Plus, 
  Star, 
  Calendar,
  Trash2,
  GitCompare,
  CheckCircle
} from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

export default function BaselineManager({ 
  baselines, 
  tasks, 
  onCreateBaseline, 
  onSetCurrent, 
  onDelete, 
  onCompare,
  comparedBaselineId 
}) {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newBaseline, setNewBaseline] = useState({ name: "", description: "" });
  const [isCreating, setIsCreating] = useState(false);

  const handleCreateBaseline = async () => {
    if (!newBaseline.name.trim()) {
      alert("Please enter a baseline name");
      return;
    }

    setIsCreating(true);
    try {
      await onCreateBaseline(newBaseline.name, newBaseline.description);
      setShowCreateDialog(false);
      setNewBaseline({ name: "", description: "" });
    } catch (error) {
      console.error("Error creating baseline:", error);
      alert("Failed to create baseline. Please try again.");
    }
    setIsCreating(false);
  };

  const handleSetCurrent = async (baselineId) => {
    try {
      await onSetCurrent(baselineId);
    } catch (error) {
      console.error("Error setting current baseline:", error);
      alert("Failed to set current baseline. Please try again.");
    }
  };

  const handleDelete = async (baseline) => {
    if (baseline.is_current) {
      alert("Cannot delete the current baseline. Please set another baseline as current first.");
      return;
    }
    
    if (window.confirm(`Are you sure you want to delete baseline "${baseline.name}"?`)) {
      try {
        await onDelete(baseline.id);
      } catch (error) {
        console.error("Error deleting baseline:", error);
        alert("Failed to delete baseline. Please try again.");
      }
    }
  };

  const handleCompare = (baselineId) => {
    if (comparedBaselineId === baselineId) {
      onCompare(null); // Remove comparison
    } else {
      onCompare(baselineId); // Set comparison
    }
  };

  const currentBaseline = baselines.find(b => b.is_current);

  return (
    <div className="space-y-6">
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <BaselineIcon className="w-5 h-5 text-blue-600" />
              Project Baselines
              <Badge className="bg-blue-100 text-blue-700">
                {baselines.length} baselines
              </Badge>
            </CardTitle>
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 gap-2">
                  <Plus className="w-4 h-4" />
                  Create Baseline
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Baseline</DialogTitle>
                  <DialogDescription>
                    Save the current project schedule as a baseline for comparison and tracking.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="baseline-name">Baseline Name *</Label>
                    <Input
                      id="baseline-name"
                      value={newBaseline.name}
                      onChange={(e) => setNewBaseline(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="e.g., Original Schedule, Approved Baseline"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="baseline-description">Description</Label>
                    <Textarea
                      id="baseline-description"
                      value={newBaseline.description}
                      onChange={(e) => setNewBaseline(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Optional description for this baseline..."
                      rows={3}
                    />
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-sm text-blue-800">
                      This baseline will capture the current state of {tasks.length} tasks with their 
                      schedules, durations, and dependencies.
                    </p>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleCreateBaseline} 
                    disabled={isCreating}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {isCreating ? "Creating..." : "Create Baseline"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {baselines.length > 0 ? (
            <div className="space-y-4">
              {baselines.map((baseline, index) => (
                <motion.div
                  key={baseline.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`p-4 rounded-lg border ${
                    baseline.is_current 
                      ? 'border-blue-200 bg-blue-50' 
                      : comparedBaselineId === baseline.id
                      ? 'border-green-200 bg-green-50'
                      : 'border-slate-200 bg-white'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold text-slate-900">{baseline.name}</h4>
                        {baseline.is_current && (
                          <Badge className="bg-blue-100 text-blue-700 gap-1">
                            <Star className="w-3 h-3" />
                            Current
                          </Badge>
                        )}
                        {comparedBaselineId === baseline.id && (
                          <Badge className="bg-green-100 text-green-700 gap-1">
                            <GitCompare className="w-3 h-3" />
                            Comparing
                          </Badge>
                        )}
                        <Badge variant="outline">
                          Baseline {baseline.baseline_number}
                        </Badge>
                      </div>
                      
                      {baseline.description && (
                        <p className="text-sm text-slate-600 mb-3">{baseline.description}</p>
                      )}
                      
                      <div className="flex items-center gap-4 text-sm text-slate-500">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          Created: {format(new Date(baseline.baseline_date), 'MMM d, yyyy')}
                        </div>
                        <div>
                          Tasks: {baseline.baseline_data?.tasks?.length || 0}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleCompare(baseline.id)}
                        className={comparedBaselineId === baseline.id ? 'bg-green-100 text-green-700' : ''}
                      >
                        <GitCompare className="w-4 h-4" />
                        {comparedBaselineId === baseline.id ? 'Stop Compare' : 'Compare'}
                      </Button>
                      
                      {!baseline.is_current && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleSetCurrent(baseline.id)}
                        >
                          <CheckCircle className="w-4 h-4" />
                          Set Current
                        </Button>
                      )}
                      
                      {!baseline.is_current && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(baseline)}
                          className="text-red-600 hover:bg-red-100"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <BaselineIcon className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-600 mb-2">No Baselines Created</h3>
              <p className="text-slate-500 mb-4">
                Create your first baseline to track project progress and compare schedules.
              </p>
              <Button 
                onClick={() => setShowCreateDialog(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create First Baseline
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}