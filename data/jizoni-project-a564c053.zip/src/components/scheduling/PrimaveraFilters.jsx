
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Plus, Trash2, Filter, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const filterOptions = [
  { value: 'status', label: 'Status', input: 'select', options: ['not_started', 'in_progress', 'completed', 'on_hold'] },
  { value: 'priority', label: 'Priority', input: 'select', options: ['low', 'medium', 'high', 'critical'] },
  { value: 'is_critical', label: 'Is Critical', input: 'boolean' },
  { value: 'total_float', label: 'Total Float', input: 'number', conditions: ['is', 'is_not', 'is_less_than', 'is_greater_than'] },
  { value: 'start_date', label: 'Start Date', input: 'date' },
  { value: 'end_date', label: 'End Date', input: 'date' },
  { value: 'wbs_level', label: 'WBS Level', input: 'number', conditions: ['is', 'is_not', 'is_less_than', 'is_greater_than'] },
  { value: 'name', label: 'Task Name', input: 'text', conditions: ['contains', 'does_not_contain'] },
];

const defaultConditions = ['is', 'is_not'];

const Rule = ({ rule, index, onUpdate, onRemove }) => {
  const selectedOption = filterOptions.find(opt => opt.value === rule.parameter);

  const handleParameterChange = (value) => {
    onUpdate(index, { parameter: value, condition: (filterOptions.find(opt => opt.value === value)?.conditions || defaultConditions)[0], value: '' });
  };

  const renderValueInput = () => {
    if (!selectedOption) return null; // Handle case where selectedOption might be undefined initially
    switch (selectedOption.input) {
      case 'select':
        return (
          <Select value={rule.value} onValueChange={value => onUpdate(index, { ...rule, value })}>
            <SelectTrigger><SelectValue placeholder="Select a value..." /></SelectTrigger>
            <SelectContent>
              {selectedOption.options.map(opt => <SelectItem key={opt} value={opt}>{opt.replace('_', ' ')}</SelectItem>)}
            </SelectContent>
          </Select>
        );
      case 'boolean':
        return (
          <Select value={rule.value} onValueChange={value => onUpdate(index, { ...rule, value })}>
            <SelectTrigger><SelectValue placeholder="Select a value..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="true">Yes</SelectItem>
              <SelectItem value="false">No</SelectItem>
            </SelectContent>
          </Select>
        );
      case 'date':
        return <Input type="date" value={rule.value} onChange={e => onUpdate(index, { ...rule, value: e.target.value })} />;
      case 'number':
        return <Input type="number" value={rule.value} onChange={e => onUpdate(index, { ...rule, value: e.target.value })} />;
      default: // text
        return <Input type="text" value={rule.value} onChange={e => onUpdate(index, { ...rule, value: e.target.value })} />;
    }
  };

  return (
    <motion.div layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2 p-3 bg-slate-50 rounded-lg border">
      <Select value={rule.parameter} onValueChange={handleParameterChange}>
        <SelectTrigger className="w-48"><SelectValue placeholder="Select parameter..." /></SelectTrigger>
        <SelectContent>{filterOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}</SelectContent>
      </Select>
      
      <Select value={rule.condition} onValueChange={condition => onUpdate(index, { ...rule, condition })}>
        <SelectTrigger className="w-40"><SelectValue placeholder="Select condition..." /></SelectTrigger>
        <SelectContent>
          {(selectedOption?.conditions || defaultConditions).map(cond => <SelectItem key={cond} value={cond}>{cond.replace('_', ' ')}</SelectItem>)}
        </SelectContent>
      </Select>
      
      <div className="flex-1">{renderValueInput()}</div>
      
      <Button variant="ghost" size="icon" onClick={() => onRemove(index)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
    </motion.div>
  );
};

export default function DynamicFilterManager({ onApplyFilters, onClearFilters }) {
  const [rules, setRules] = useState([]);
  const [matchType, setMatchType] = useState('all'); // 'all' for AND, 'any' for OR

  const addRule = () => {
    setRules([...rules, { parameter: 'status', condition: 'is', value: 'in_progress', id: Date.now() }]);
  };

  const updateRule = (index, updatedRule) => {
    const newRules = [...rules];
    newRules[index] = updatedRule;
    setRules(newRules);
  };

  const removeRule = (index) => {
    setRules(rules.filter((_, i) => i !== index));
  };

  const handleApply = () => {
    // Filter out incomplete rules before applying
    const validRules = rules.filter(r => r.value !== '' && r.parameter && r.condition);
    onApplyFilters({ matchType, rules: validRules });
  };
  
  const handleClear = () => {
    setRules([]);
    onClearFilters();
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-blue-600" />
          Dynamic Filter Manager
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-between items-center p-3 bg-slate-100 rounded-lg">
          <div className="flex items-center gap-4">
            <Label>Match</Label>
            <RadioGroup value={matchType} onValueChange={setMatchType} className="flex gap-4">
              <div className="flex items-center space-x-2"><RadioGroupItem value="all" id="match-all" /><Label htmlFor="match-all">All filters (AND)</Label></div>
              <div className="flex items-center space-x-2"><RadioGroupItem value="any" id="match-any" /><Label htmlFor="match-any">Any filter (OR)</Label></div>
            </RadioGroup>
          </div>
          <Button onClick={addRule} className="gap-2"><Plus className="w-4 h-4" /> Add Rule</Button>
        </div>

        <div className="space-y-2">
          <AnimatePresence>
            {rules.map((rule, index) => <Rule key={rule.id || index} rule={rule} index={index} onUpdate={updateRule} onRemove={removeRule} />)}
          </AnimatePresence>
          {rules.length === 0 && (
            <div className="text-center py-8 text-slate-500">
              <p>No filters applied.</p>
              <p className="text-sm">Click "Add Rule" to get started.</p>
            </div>
          )}
        </div>

        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button variant="outline" onClick={handleClear} className="gap-2" disabled={rules.length === 0}><X className="w-4 h-4" /> Clear All Filters</Button>
          <Button onClick={handleApply} className="bg-blue-600 hover:bg-blue-700">Apply Filters</Button>
        </div>
      </CardContent>
    </Card>
  );
}
