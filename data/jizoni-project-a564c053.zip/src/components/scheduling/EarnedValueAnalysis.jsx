
import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Calendar,
  Target,
  AlertTriangle,
  CheckCircle,
  BarChart3,
  Edit,
  Info
} from "lucide-react";
import { motion } from "framer-motion";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export default function EarnedValueAnalysis({ project, tasks }) {
  const [timeScale, setTimeScale] = useState("weekly");
  const [evmData, setEvmData] = useState(null);
  const [sCurveData, setSCurveData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedMetric, setSelectedMetric] = useState(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editValues, setEditValues] = useState({});

  const calculateEVM = useCallback(() => {
    const taskList = tasks || [];
    if (taskList.length === 0) { 
        setEvmData(null);
        return;
    }

    const projectData = project || {};
    
    const totalPV = taskList.reduce((sum, task) => sum + (task.planned_value || 0), 0);
    const totalEV = taskList.reduce((sum, task) => sum + (task.earned_value || 0), 0);
    const totalAC = taskList.reduce((sum, task) => sum + (task.actual_cost || 0), 0);
    const totalBAC = projectData.budget || totalPV || 0;

    const cv = totalEV - totalAC; // Cost Variance
    const sv = totalEV - totalPV; // Schedule Variance
    const cpi = totalAC > 0 ? totalEV / totalAC : (totalEV > 0 ? Infinity : 1); // Cost Performance Index
    const spi = totalPV > 0 ? totalEV / totalPV : (totalEV > 0 ? Infinity : 1); // Schedule Performance Index
    
    // Estimates
    // EAC (Estimate at Completion) formula: BAC / CPI (assuming current CPI is typical for future work)
    const eac = (cpi > 0 && cpi !== Infinity) ? totalBAC / cpi : totalAC; 
    const etc = eac - totalAC; // Estimate to Complete
    const vac = totalBAC - eac; // Variance at Completion
    const tcpi_denominator = totalBAC - totalAC;
    // TCPI (To Complete Performance Index) formula: (BAC - EV) / (BAC - AC)
    const tcpi = tcpi_denominator > 0 ? (totalBAC - totalEV) / tcpi_denominator : 1; 

    setEvmData({
      pv: totalPV,
      ev: totalEV,
      ac: totalAC,
      bac: totalBAC,
      cv,
      sv,
      cpi,
      spi,
      eac,
      etc,
      vac,
      tcpi
    });
  }, [project, tasks]);

  const generateSCurveData = useCallback(() => {
    if (!tasks || tasks.length === 0 || !project || !project.start_date || !project.end_date) {
        setSCurveData([]);
        return;
    }

    const projectStartDate = new Date(project.start_date);
    const projectEndDate = new Date(project.end_date);
    const totalDays = Math.ceil((projectEndDate - projectStartDate) / (1000 * 60 * 60 * 24)) || 1;
    
    const interval = timeScale === "daily" ? 1 : timeScale === "weekly" ? 7 : 30;
    const dataPoints = [];

    for (let i = 0; i <= totalDays; i += interval) {
        const currentDate = new Date(projectStartDate.getTime() + i * 24 * 60 * 60 * 1000);
        let cumulativePV = 0;
        let cumulativeEV = 0;
        let cumulativeAC = 0;

        tasks.forEach(task => {
            const taskStartDate = task.start_date ? new Date(task.start_date) : null;
            const taskEndDate = task.end_date ? new Date(task.end_date) : null;

            if (taskStartDate && taskEndDate && task.planned_value !== undefined) {
                // Calculate Planned Value (PV) up to currentDate
                if (currentDate >= taskStartDate) {
                    const taskDurationDays = Math.max(1, (taskEndDate.getTime() - taskStartDate.getTime()) / (1000 * 60 * 60 * 24));
                    const daysIntoTask = Math.max(0, (currentDate.getTime() - taskStartDate.getTime()) / (1000 * 60 * 60 * 24));
                    const plannedProgress = Math.min(1, daysIntoTask / taskDurationDays);
                    cumulativePV += (task.planned_value || 0) * plannedProgress;
                }
            }
            
            // Calculate Earned Value (EV) and Actual Cost (AC) if task is completed or in progress
            if (taskStartDate && task.status && (task.status === 'completed' || currentDate >= taskStartDate)) {
                // For EV, we consider the reported earned value if available, else a simplified model
                // The provided outline implied using actual task.earned_value and task.actual_cost directly,
                // which would typically reflect current status rather than historical cumulative if not logged per day.
                // For a true S-curve over time, we'd need historical snapshots of EV/AC.
                // The current implementation takes the full EV/AC if the task has started or is completed by currentDate.
                // This is a simplification, as detailed daily EV/AC data per task is usually not available in basic `task` objects.
                // To simulate a more realistic S-curve, we'll assume `earned_value` and `actual_cost` are cumulative up to the present if the task has passed its start.
                // However, the prompt for `generateSCurveData` explicitly said "EV and AC are based on reported progress, not time" and then "cumulativeEV += task.earned_value || 0; cumulativeAC += task.actual_cost || 0;"
                // This means if a task has reported earned_value/actual_cost, we add it. A more realistic S-curve would need historical data.
                // For this simulation, if a task is "completed" or "in progress" and currentDate is past its start, we add its full reported EV/AC.
                // This might make the EV/AC curves jump, but aligns with the simplified outline.
                
                // A more nuanced approach would be:
                // If task.completion_date exists and is <= currentDate, add full EV/AC.
                // If task.status is 'in progress' and currentDate > taskStartDate, add current reported EV/AC.
                // Since there's no completion_date in task and only a status, we assume if `task.earned_value` and `task.actual_cost` are populated,
                // they reflect the current state and are "earned" / "incurred" by the current simulation date if the task is past its start.

                if (task.status === 'completed' || task.status === 'in-progress' || task.status === 'active') { // Assuming 'active' or 'in-progress' also means some EV/AC might have been incurred
                    cumulativeEV += task.earned_value || 0;
                    cumulativeAC += task.actual_cost || 0;
                }
            }
        });
        
        dataPoints.push({
            date: currentDate.toLocaleDateString(),
            dateObj: currentDate, // Keep for potential sorting
            PV: Math.round(cumulativePV),
            EV: Math.round(cumulativeEV),
            AC: Math.round(cumulativeAC),
        });
    }
    
    setSCurveData(dataPoints);
  }, [project, tasks, timeScale]);

  useEffect(() => {
    if (project || (tasks && tasks.length > 0)) {
      calculateEVM();
      generateSCurveData();
    } else {
      setEvmData(null);
      setSCurveData([]);
    }
    setIsLoading(false);
  }, [project, tasks, timeScale, calculateEVM, generateSCurveData]);

  const handleMetricClick = (metricType, value) => {
    setSelectedMetric({ type: metricType, value, data: getMetricDetails(metricType) });
    setShowDetailDialog(true);
  };

  const handleEditClick = (metricType) => {
    let initialValue;
    switch (metricType) {
      case 'Planned Value': initialValue = evmData.pv; break;
      case 'Earned Value': initialValue = evmData.ev; break;
      case 'Actual Cost': initialValue = evmData.ac; break;
      case 'Budget at Completion': initialValue = evmData.bac; break;
      default: initialValue = 0;
    }

    setEditValues({
      type: metricType,
      value: initialValue
    });
    setShowEditDialog(true);
  };

  const getMetricDetails = (metricType) => {
    const details = {
      'Planned Value': {
        description: 'The authorized budget assigned to scheduled work (BCWS - Budgeted Cost of Work Scheduled). It represents the planned expenditure for the work that should have been completed by a certain point in time.',
        calculation: 'Sum of all planned values for work scheduled to be completed up to the current date.',
        breakdown: tasks?.filter(task => task.planned_value > 0).map(task => ({
          name: task.name,
          value: task.planned_value || 0
        })) || []
      },
      'Earned Value': {
        description: 'The measure of work performed expressed in terms of the budget authorized (BCWP - Budgeted Cost of Work Performed). It quantifies the value of the work actually completed relative to the budget.',
        calculation: 'Sum of planned values for work actually completed up to the current date.',
        breakdown: tasks?.filter(task => task.earned_value > 0).map(task => ({
          name: task.name,
          value: task.earned_value || 0
        })) || []
      },
      'Actual Cost': {
        description: 'The realized cost incurred for the work performed (ACWP - Actual Cost of Work Performed). It is the total cost incurred in accomplishing the work that has been completed.',
        calculation: 'Sum of actual costs incurred for completed work up to the current date.',
        breakdown: tasks?.filter(task => task.actual_cost > 0).map(task => ({
          name: task.name,
          value: task.actual_cost || 0
        })) || []
      },
      'Budget at Completion': {
        description: 'The sum of all budgets allocated to the project (BAC - Budget at Completion). It represents the total planned budget for the entire project work.',
        calculation: 'Total project budget defined at the start, often the sum of all planned values for all tasks in the project.',
        breakdown: [] // BAC is a total project budget, not typically broken down by individual tasks for display here
      }
    };
    return details[metricType] || {};
  };

  const saveEditedValue = () => {
    // In a real application, you would send this update to a backend service.
    // For demonstration, we'll just show an alert.
    alert(`Attempted to update ${editValues.type} to ${formatCurrency(editValues.value)}.\n\nIn a real implementation, this would trigger an API call to update the project's data. Note that directly editing PV/EV/AC at project level without updating underlying tasks is an oversimplification.`);
    
    // Optionally, you might want to re-calculate EVM metrics if this was a true update
    // setEvmData(prevEvmData => ({ ...prevEvmData, [editValues.type.toLowerCase().replace(/ /g, '_').replace('at_completion', 'ac')]: editValues.value }));
    // calculateEVM(); // If the update implies a change to source data
    
    setShowEditDialog(false);
  };

  const getPerformanceStatus = (index, threshold = 1) => {
    if (index === Infinity) return { status: "excellent", color: "text-green-600", icon: CheckCircle }; // Special handling for Infinity
    if (index >= threshold * 1.1) return { status: "excellent", color: "text-green-600", icon: CheckCircle };
    if (index >= threshold) return { status: "good", color: "text-blue-600", icon: TrendingUp };
    if (index >= threshold * 0.9) return { status: "warning", color: "text-yellow-600", icon: AlertTriangle };
    return { status: "critical", color: "text-red-600", icon: TrendingDown };
  };

  const formatCurrency = (value) => {
    // Handle Infinity gracefully for display
    if (value === Infinity) {
        return "N/A (Infinite)";
    }
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
          <CardContent className="p-8 text-center">
            <BarChart3 className="w-16 h-16 text-slate-300 mx-auto mb-4 animate-spin" />
            <h3 className="text-lg font-semibold text-slate-600 mb-2">Loading EVM Data</h3>
            <p className="text-slate-500">Calculating earned value metrics...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!evmData) {
    return (
      <div className="space-y-6">
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
          <CardContent className="p-8 text-center">
            <BarChart3 className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-600 mb-2">No EVM Data Available</h3>
            <p className="text-slate-500">Add tasks with budget information to generate earned value analysis.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const cpiStatus = getPerformanceStatus(evmData.cpi);
  const spiStatus = getPerformanceStatus(evmData.spi);

  return (
    <div className="space-y-6">
      {/* EVM Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0 }}
        >
          <Card 
            className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0 cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => handleMetricClick('Planned Value', evmData.pv)}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-blue-100 text-xs font-medium">Planned Value (PV)</p>
                  <h3 className="text-2xl font-bold">{formatCurrency(evmData.pv)}</h3>
                </div>
                <div className="flex gap-1 items-center">
                  <Calendar className="w-5 h-5 text-blue-200" />
                  <Info className="w-4 h-4 text-blue-200" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card 
            className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0 cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => handleMetricClick('Earned Value', evmData.ev)}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-green-100 text-xs font-medium">Earned Value (EV)</p>
                  <h3 className="text-2xl font-bold">{formatCurrency(evmData.ev)}</h3>
                </div>
                <div className="flex gap-1 items-center">
                  <Target className="w-5 h-5 text-green-200" />
                  <Info className="w-4 h-4 text-green-200" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card 
            className="bg-gradient-to-r from-orange-500 to-orange-600 text-white border-0 cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => handleMetricClick('Actual Cost', evmData.ac)}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-orange-100 text-xs font-medium">Actual Cost (AC)</p>
                  <h3 className="text-2xl font-bold">{formatCurrency(evmData.ac)}</h3>
                </div>
                <div className="flex gap-1 items-center">
                  <DollarSign className="w-5 h-5 text-orange-200" />
                  <Info className="w-4 h-4 text-orange-200" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card 
            className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0 cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => handleMetricClick('Budget at Completion', evmData.bac)}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-purple-100 text-xs font-medium">Budget at Completion</p>
                  <h3 className="text-2xl font-bold">{formatCurrency(evmData.bac)}</h3>
                </div>
                <div className="flex gap-1 items-center">
                  <BarChart3 className="w-5 h-5 text-purple-200" />
                  <Info className="w-4 h-4 text-purple-200" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Performance Indices */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Performance Indices
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <cpiStatus.icon className={`w-5 h-5 ${cpiStatus.color}`} />
                  <div>
                    <h4 className="font-semibold text-slate-900">Cost Performance Index (CPI)</h4>
                    <p className="text-sm text-slate-600">
                      {evmData.cpi >= 1 ? 'Under budget' : 'Over budget'}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-2xl font-bold ${cpiStatus.color}`}>
                    {evmData.cpi === Infinity ? '∞' : evmData.cpi.toFixed(2)}
                  </div>
                  <Badge className={cpiStatus.status === 'good' || cpiStatus.status === 'excellent' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}>
                    {cpiStatus.status}
                  </Badge>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <spiStatus.icon className={`w-5 h-5 ${spiStatus.color}`} />
                  <div>
                    <h4 className="font-semibold text-slate-900">Schedule Performance Index (SPI)</h4>
                    <p className="text-sm text-slate-600">
                      {evmData.spi >= 1 ? 'Ahead of schedule' : 'Behind schedule'}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-2xl font-bold ${spiStatus.color}`}>
                    {evmData.spi === Infinity ? '∞' : evmData.spi.toFixed(2)}
                  </div>
                  <Badge className={spiStatus.status === 'good' || spiStatus.status === 'excellent' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}>
                    {spiStatus.status}
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-600" />
              Variance Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-slate-50 rounded-lg">
                <div className={`text-xl font-bold ${evmData.cv >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(evmData.cv)}
                </div>
                <div className="text-sm text-slate-600">Cost Variance (CV)</div>
              </div>
              <div className="text-center p-3 bg-slate-50 rounded-lg">
                <div className={`text-xl font-bold ${evmData.sv >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(evmData.sv)}
                </div>
                <div className="text-sm text-slate-600">Schedule Variance (SV)</div>
              </div>
              <div className="text-center p-3 bg-slate-50 rounded-lg">
                <div className="text-xl font-bold text-slate-900">
                  {formatCurrency(evmData.eac)}
                </div>
                <div className="text-sm text-slate-600">Estimate at Completion</div>
              </div>
              <div className="text-center p-3 bg-slate-50 rounded-lg">
                <div className={`text-xl font-bold ${evmData.vac >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(evmData.vac)}
                </div>
                <div className="text-sm text-slate-600">Variance at Completion</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* S-Curve Chart */}
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-purple-600" />
              S-Curve Analysis
            </CardTitle>
            <Select value={timeScale} onValueChange={setTimeScale}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sCurveData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="date" 
                  fontSize={12}
                  tick={{ fill: '#64748b' }}
                />
                <YAxis 
                  tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
                  fontSize={12}
                  tick={{ fill: '#64748b' }}
                />
                <Tooltip 
                  formatter={(value, name) => [formatCurrency(value), name]}
                  labelStyle={{ color: '#1e293b' }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="PV" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  name="Planned Value"
                  dot={{ r: 3 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="EV" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  name="Earned Value"
                  dot={{ r: 3 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="AC" 
                  stroke="#f59e0b" 
                  strokeWidth={2}
                  name="Actual Cost"
                  dot={{ r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Metric Detail Dialog */}
      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Info className="w-5 h-5 text-blue-600" />
              {selectedMetric?.type} Details
            </DialogTitle>
            <DialogDescription>
              Detailed breakdown and analysis of this Earned Value Management metric.
            </DialogDescription>
          </DialogHeader>
          {selectedMetric && (
            <div className="space-y-4 py-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-3xl font-bold text-blue-700">
                  {formatCurrency(selectedMetric.value)}
                </div>
                <div className="text-sm text-blue-600">{selectedMetric.type}</div>
              </div>
              
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-slate-900">Description</h4>
                  <p className="text-sm text-slate-600">{selectedMetric.data.description}</p>
                </div>
                
                <div>
                  <h4 className="font-semibold text-slate-900">Calculation Method</h4>
                  <p className="text-sm text-slate-600">{selectedMetric.data.calculation}</p>
                </div>
                
                {selectedMetric.data.breakdown.length > 0 && (
                  <div>
                    <h4 className="font-semibold text-slate-900 mb-2">Task Breakdown (Sample)</h4>
                    <div className="max-h-40 overflow-y-auto border border-slate-200 rounded-md p-2">
                      {selectedMetric.data.breakdown.slice(0, 10).map((item, index) => (
                        <div key={index} className="flex justify-between py-1 text-sm border-b border-slate-100 last:border-b-0">
                          <span className="text-slate-700">{item.name}</span>
                          <span className="font-medium">{formatCurrency(item.value)}</span>
                        </div>
                      ))}
                      {selectedMetric.data.breakdown.length > 10 && (
                        <p className="text-xs text-slate-500 pt-2">And {selectedMetric.data.breakdown.length - 10} more tasks...</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDetailDialog(false)}>Close</Button>
            <Button 
              onClick={() => {
                setShowDetailDialog(false);
                handleEditClick(selectedMetric?.type);
              }}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Edit className="w-4 h-4 mr-2" />
              Edit Value
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Value Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit {editValues.type}</DialogTitle>
            <DialogDescription>
              Update the value for this metric. This is for demonstration purposes.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-value">New Value</Label>
              <Input
                id="edit-value"
                type="number"
                value={editValues.value || ''}
                onChange={(e) => setEditValues(prev => ({ ...prev, value: parseFloat(e.target.value) || 0 }))}
                placeholder="Enter new value"
              />
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <p className="text-sm text-yellow-800">
                <strong>Note:</strong> In a real application, editing these summary metrics directly might require updating underlying project tasks or financial records. This demonstration only updates the displayed value.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>Cancel</Button>
            <Button onClick={saveEditedValue} className="bg-green-600 hover:bg-green-700">
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
