
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, TrendingUp, AlertTriangle, Zap, Settings } from "lucide-react";
import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function ResourceLeveling({ resources, tasks, calendars }) {
  const [levelingMethod, setLevelingMethod] = useState("automatic");
  const [levelingPriority, setLevelingPriority] = useState("priority");
  const [isLeveling, setIsLeveling] = useState(false);
  const [levelingResults, setLevelingResults] = useState(null);

  // Calculate resource utilization from actual project data
  const calculateResourceUtilization = () => {
    if (!resources || resources.length === 0) {
      return [];
    }
    const utilization = new Map();
    
    resources.forEach(resource => {
      // Find tasks assigned to this resource by name or ID.
      const assignedTasks = tasks.filter(task => task.assigned_to === resource.name || task.assigned_to === resource.id);
      
      const totalWorkload = assignedTasks.reduce((sum, task) => {
        // Consider only active or upcoming tasks for workload calculation
        if (task.status === 'in_progress' || task.status === 'not_started') {
          return sum + (task.duration_days || 0);
        }
        return sum;
      }, 0); // Initial sum should be 0
      
      // A simple utilization metric: assume 20 work days in a typical month as 100% capacity.
      // This can be refined with calendar data for actual working days.
      const utilizationPercentage = (totalWorkload / 20) * 100;
      
      utilization.set(resource.id, {
        resource,
        workload: totalWorkload,
        utilization: utilizationPercentage,
        tasks: assignedTasks,
        overallocated: utilizationPercentage > (resource.max_units || 100) // Compare against resource's max units (or 100% if not specified)
      });
    });
    
    return Array.from(utilization.values());
  };

  const resourceUtilization = calculateResourceUtilization();
  const overallocatedResources = resourceUtilization.filter(r => r.overallocated);

  const getUtilizationColor = (utilization) => {
    if (utilization <= 70) return "bg-green-500";
    if (utilization <= 100) return "bg-yellow-500";
    return "bg-red-500";
  };

  const getUtilizationStatus = (utilization) => {
    if (utilization <= 70) return { text: "Under-utilized", color: "text-green-700" };
    if (utilization <= 100) return { text: "Optimal", color: "text-yellow-700" };
    return { text: "Overallocated", color: "text-red-700" };
  };

  const performResourceLeveling = async () => {
    setIsLeveling(true);
    
    // Simulate leveling process
    // In a real application, this would involve calling a backend API
    // or a complex local algorithm to adjust task dates/assignments.
    setTimeout(() => {
      const results = {
        overallocatedCount: overallocatedResources.length,
        recommendations: [
          { task: "Foundation Design", action: "Delay by 2 days", impact: "No critical path impact" },
          { task: "Structural Analysis", action: "Reassign to Mike Chen", impact: "Reduces John's workload by 15%" },
          { task: "Site Survey", action: "Split into 2 phases", impact: "Better resource distribution" }
        ],
        summary: `Resource leveling complete. ${overallocatedResources.length} conflicts resolved. Project end date unchanged.`
      };
      setLevelingResults(results);
      setIsLeveling(false);
    }, 2000);
  };

  // Generate histogram data from actual task assignments
  const generateHistogramData = () => {
    const data = {};
    const validStartDates = tasks.filter(t => t.start_date).map(t => new Date(t.start_date));
    const startDate = validStartDates.length > 0 ? new Date(Math.min(...validStartDates)) : new Date();

    tasks.forEach(task => {
        if (task.start_date && task.duration_days > 0 && task.assigned_to) {
            const taskStart = new Date(task.start_date);
            for (let i = 0; i < task.duration_days; i++) {
                const date = new Date(taskStart);
                date.setDate(date.getDate() + i);
                
                // Calculate week number relative to the project start date
                const oneWeek = 1000 * 60 * 60 * 24 * 7;
                const weekNumber = Math.floor((date.getTime() - startDate.getTime()) / oneWeek) + 1;
                const week = `Week ${weekNumber}`;

                if (!data[week]) {
                    // Initialize with total available capacity (e.g., resources.length * 100 units/percentage)
                    data[week] = { week, allocated: 0, available: resources.length * 100 }; 
                }
                // Simplified allocation: each assigned task contributes a fractional amount of 100 'units'
                // for each day it's active. This simulates a distributed load.
                data[week].allocated += (1 / task.duration_days) * 100;
            }
        }
    });

    // Convert to array, sort by week number, and limit to 12 weeks for display
    return Object.values(data)
      .sort((a, b) => parseInt(a.week.replace('Week ', '')) - parseInt(b.week.replace('Week ', '')))
      .slice(0, 12);
  };

  const histogramData = generateHistogramData();

  return (
    <div className="space-y-6">
      {/* Leveling Controls */}
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-600" />
            Resource Leveling Configuration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Leveling Method</label>
              <Select value={levelingMethod} onValueChange={setLevelingMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="automatic">Automatic Leveling</SelectItem>
                  <SelectItem value="manual">Manual Leveling</SelectItem>
                  <SelectItem value="priority">Priority-Based</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Leveling Priority</label>
              <Select value={levelingPriority} onValueChange={setLevelingPriority}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="priority">Task Priority</SelectItem>
                  <SelectItem value="duration">Duration</SelectItem>
                  <SelectItem value="critical_path">Critical Path</SelectItem>
                  <SelectItem value="start_date">Start Date</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button 
              onClick={performResourceLeveling}
              disabled={isLeveling}
              className="bg-blue-600 hover:bg-blue-700 gap-2"
            >
              <Zap className="w-4 h-4" />
              {isLeveling ? "Leveling..." : "Level Resources"}
            </Button>
          </div>
          
          {overallocatedResources.length > 0 && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-center gap-2 text-red-800">
                <AlertTriangle className="w-4 h-4" />
                <span className="font-medium">
                  {overallocatedResources.length} resource(s) overallocated
                </span>
              </div>
              <p className="text-sm text-red-700 mt-1">
                Resource leveling is recommended to resolve conflicts and optimize schedules.
              </p>
            </div>
          )}

          {levelingResults && (
            <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
              <h4 className="font-semibold text-green-800 mb-2">Leveling Results</h4>
              <p className="text-sm text-green-700 mb-3">{levelingResults.summary}</p>
              <div className="space-y-2">
                <h5 className="font-medium text-green-800">Recommendations:</h5>
                {levelingResults.recommendations.map((rec, i) => (
                  <div key={i} className="text-sm text-green-700 pl-4">
                    <strong>{rec.task}:</strong> {rec.action} - {rec.impact}
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Resource Utilization */}
      <Tabs defaultValue="utilization" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="utilization">Resource Utilization</TabsTrigger>
          <TabsTrigger value="histogram">Resource Histogram</TabsTrigger>
        </TabsList>

        <TabsContent value="utilization">
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-green-600" />
                Resource Utilization Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              {resourceUtilization.length > 0 ? (
                <div className="space-y-4">
                  {resourceUtilization.map((item, index) => {
                    const status = getUtilizationStatus(item.utilization);
                    
                    return (
                      <motion.div
                        key={item.resource.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="border border-slate-200 rounded-lg p-4"
                      >
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <h4 className="font-semibold text-slate-900">{item.resource.name}</h4>
                            <p className="text-sm text-slate-600">{item.resource.type}</p>
                          </div>
                          <div className="text-right">
                            <div className={`text-sm font-medium ${status.color}`}>
                              {status.text}
                            </div>
                            <div className="text-lg font-bold text-slate-900">
                              {Math.round(item.utilization)}%
                            </div>
                          </div>
                        </div>

                        <div className="space-y-2 mb-4">
                          <div className="flex justify-between text-sm">
                            <span className="text-slate-600">Utilization</span>
                            <span className="font-medium">{Math.round(item.utilization)}%</span>
                          </div>
                          <Progress 
                            value={Math.min(item.utilization, 100)} 
                            className="h-3"
                          />
                          {item.utilization > 100 && (
                            <div className="text-xs text-red-600 font-medium">
                              Overallocated by {Math.round(item.utilization - 100)}%
                            </div>
                          )}
                        </div>

                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div className="text-center p-2 bg-slate-50 rounded">
                            <div className="font-semibold text-slate-900">{item.tasks.length}</div>
                            <div className="text-slate-600">Assigned Tasks</div>
                          </div>
                          <div className="text-center p-2 bg-slate-50 rounded">
                            <div className="font-semibold text-slate-900">{item.workload}d</div>
                            <div className="text-slate-600">Total Workload</div>
                          </div>
                          <div className="text-center p-2 bg-slate-50 rounded">
                            <div className="font-semibold text-slate-900">
                              {item.resource.max_units || 100}%
                            </div>
                            <div className="text-slate-600">Max Units</div>
                          </div>
                        </div>

                        {item.overallocated && (
                          <div className="mt-3 flex gap-2">
                            <Button variant="outline" size="sm" className="gap-1">
                              <Zap className="w-3 h-3" />
                              Level
                            </Button>
                            <Button variant="outline" size="sm">
                              Reassign Tasks
                            </Button>
                          </div>
                        )}
                      </motion.div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-600 mb-2">No resources to analyze</h3>
                  <p className="text-slate-500">Add resources to your project to see utilization analysis</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="histogram">
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-purple-600" />
                Resource Histogram
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={histogramData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="allocated" fill="#3b82f6" name="Allocated" />
                    <Bar dataKey="available" fill="#e2e8f0" name="Available" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 text-sm text-slate-600">
                <p>This histogram shows resource allocation over time. Blue bars represent allocated resources, gray bars show total available capacity.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
