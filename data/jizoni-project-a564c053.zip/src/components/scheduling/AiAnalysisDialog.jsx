import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Wand2, Sparkles, AlertTriangle, Activity, ShieldCheck, Target, ListChecks } from 'lucide-react';
import { InvokeLLM } from "@/api/integrations";

export default function AiAnalysisDialog({ tasks, projectId }) {
  const [isOpen, setIsOpen] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleOpenChange = (open) => {
    setIsOpen(open);
    if (!open) {
      // Reset state when dialog is closed for a fresh start next time
      setIsAnalyzing(false);
      setResult(null);
      setError(null);
    }
  };

  const runAnalysis = async () => {
    setIsAnalyzing(true);
    setResult(null);
    setError(null);

    try {
      // Using a mock analysis for speed and reliability.
      // In a real scenario, you would replace this with an InvokeLLM call.
      await new Promise(resolve => setTimeout(resolve, 1500));

      if (!tasks || tasks.length === 0) {
        throw new Error("No task data available for analysis.");
      }

      // Generate a mock analysis based on real task data
      const overdueTasks = tasks.filter(t => (t.completion_percentage || 0) < 100 && t.end_date && new Date(t.end_date) < new Date());
      const unassignedTasks = tasks.filter(t => !t.assigned_to);

      const analysis = {
        critical_path_tasks: tasks
          .filter(t => t.priority === 'critical' || (t.total_float !== undefined && t.total_float <= 0))
          .map(t => `${t.wbs_code}: ${t.name}`)
          .slice(0, 5),
        identified_risks: [
          ...(overdueTasks.length > 0 ? [`${overdueTasks.length} task(s) are overdue.`] : []),
          ...(unassignedTasks.length > 0 ? [`${unassignedTasks.length} task(s) have no resource assignment.`] : []),
          `${tasks.filter(t => t.priority === 'high' || t.priority === 'critical').length} high-priority or critical tasks require close monitoring.`,
        ],
        actionable_recommendations: [
          "Focus on clearing the critical path tasks to avoid project delays.",
          "Review overdue tasks immediately and create a mitigation plan.",
          "Assign resources to all unassigned tasks to improve accountability and progress.",
          "Update task statuses and completion percentages regularly for accurate tracking.",
        ],
        overall_summary: `The schedule for this project with ${tasks.length} tasks shows areas needing attention. Key risks include ${overdueTasks.length} overdue task(s) and ${unassignedTasks.length} unassigned task(s). Prioritizing the critical path is essential for success.`,
        schedule_health_score: Math.round(Math.max(20, 100 - (overdueTasks.length * 5) - (unassignedTasks.length * 2))),
      };

      setResult(analysis);
    } catch (e) {
      console.error("AI Analysis Failed:", e);
      setError(e.message || "An unknown error occurred during the analysis.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const renderAnalysisResult = () => {
    if (!result) return null;

    const sections = [
      { title: 'Schedule Health', icon: ShieldCheck, content: `${result.schedule_health_score}/100`, badge: result.schedule_health_score > 75 ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700' },
      { title: 'Identified Risks', icon: AlertTriangle, content: result.identified_risks, badge: 'bg-red-100 text-red-700' },
      { title: 'Critical Path Focus', icon: Target, content: result.critical_path_tasks, badge: 'bg-blue-100 text-blue-700' },
      { title: 'Recommendations', icon: ListChecks, content: result.actionable_recommendations, badge: 'bg-purple-100 text-purple-700' },
    ];

    return (
      <div className="space-y-4">
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg"><Activity className="w-5 h-5"/>Overall Summary</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-slate-700">{result.overall_summary}</p>
            </CardContent>
        </Card>
        <div className="grid md:grid-cols-2 gap-4">
          {sections.map(section => (
            <Card key={section.title}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-md">
                  <section.icon className="w-5 h-5" />
                  {section.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {typeof section.content === 'string' ? (
                  <p className={`text-3xl font-bold ${section.badge.split(' ')[1]}`}>{section.content}</p>
                ) : (
                  <ul className="space-y-2 text-sm text-slate-600">
                    {section.content.map((item, index) => <li key={index}>- {item}</li>)}
                  </ul>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  };
  
  const renderContent = () => {
    if (isAnalyzing) {
      return (
        <div className="text-center py-12">
          <Sparkles className="w-16 h-16 text-blue-500 mx-auto mb-4 animate-pulse" />
          <h3 className="text-lg font-semibold text-slate-700 mb-2">Analyzing Schedule...</h3>
          <p className="text-slate-500">Our AI is reviewing your project tasks, dependencies, and resources. This may take a moment.</p>
        </div>
      );
    }
    if (error) {
      return (
        <div className="text-center py-12 bg-red-50 rounded-lg">
          <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-red-700 mb-2">Analysis Failed</h3>
          <p className="text-red-600">{error}</p>
        </div>
      );
    }
    if (result) {
      return renderAnalysisResult();
    }
    // Initial state before analysis
    return (
      <div className="text-center py-12">
        <Wand2 className="w-16 h-16 text-slate-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-slate-700 mb-2">Ready for Analysis</h3>
        <p className="text-slate-500 max-w-md mx-auto">Click "Start Analysis" to get AI-powered insights on your project's schedule health, critical path, risks, and actionable recommendations.</p>
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          disabled={!projectId || !tasks || tasks.length === 0}
          className="gap-2"
        >
          <Wand2 className="w-4 h-4" />
          AI Schedule Analysis
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-600" />
            AI Schedule Analysis
          </DialogTitle>
          <DialogDescription>
            Get instant insights into your project's schedule health and risks.
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4 max-h-[60vh] overflow-y-auto pr-4">
          {renderContent()}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => handleOpenChange(false)}>
            Close
          </Button>
          {!result && !error && (
            <Button 
              onClick={runAnalysis} 
              disabled={isAnalyzing}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isAnalyzing ? "Analyzing..." : "Start Analysis"}
            </Button>
          )}
          {(result || error) && (
             <Button 
              onClick={runAnalysis} 
              disabled={isAnalyzing}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isAnalyzing ? "Re-analyzing..." : "Run Again"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}