import React, { useState } from "react";
import { TaskRelationship } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Network, 
  Plus, 
  ArrowRight,
  Trash2,
  Edit,
  Link
} from "lucide-react";
import { motion } from "framer-motion";

export default function TaskRelationships({ 
  tasks, 
  relationships, 
  projectId, 
  onRelationshipsUpdate 
}) {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingRelationship, setEditingRelationship] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [newRelationship, setNewRelationship] = useState({
    predecessor_task_id: "",
    successor_task_id: "",
    relationship_type: "FS",
    lag_days: 0,
    relationship_description: ""
  });

  const relationshipTypes = {
    "FS": "Finish-to-Start",
    "SS": "Start-to-Start", 
    "FF": "Finish-to-Finish",
    "SF": "Start-to-Finish"
  };

  const getTaskById = (taskId) => tasks.find(t => t.id === taskId);

  const handleSaveRelationship = async () => {
    if (!newRelationship.predecessor_task_id || !newRelationship.successor_task_id) {
      alert("Please select both predecessor and successor tasks");
      return;
    }

    if (newRelationship.predecessor_task_id === newRelationship.successor_task_id) {
      alert("A task cannot have a relationship with itself");
      return;
    }

    // Check for duplicate relationships
    const existingRelationship = relationships.find(rel => 
      rel.predecessor_task_id === newRelationship.predecessor_task_id &&
      rel.successor_task_id === newRelationship.successor_task_id &&
      rel.relationship_type === newRelationship.relationship_type
    );

    if (existingRelationship && !editingRelationship) {
      alert("This dependency relationship already exists");
      return;
    }

    setIsLoading(true);
    try {
      const relationshipData = {
        ...newRelationship,
        project_id: projectId
      };

      if (editingRelationship) {
        await TaskRelationship.update(editingRelationship.id, relationshipData);
      } else {
        await TaskRelationship.create(relationshipData);
      }
      
      setShowCreateDialog(false);
      setEditingRelationship(null);
      resetForm();
      
      // Call the parent callback to refresh relationships
      if (typeof onRelationshipsUpdate === 'function') {
        await onRelationshipsUpdate();
      }
      
      // Show success message
      const predecessorTask = getTaskById(newRelationship.predecessor_task_id);
      const successorTask = getTaskById(newRelationship.successor_task_id);
      alert(`Dependency created: ${predecessorTask?.name} → ${successorTask?.name}`);
      
    } catch (error) {
      console.error("Error saving relationship:", error);
      alert("Failed to save relationship. Please try again.");
    }
    setIsLoading(false);
  };

  const handleEditRelationship = (relationship) => {
    setEditingRelationship(relationship);
    setNewRelationship({
      predecessor_task_id: relationship.predecessor_task_id,
      successor_task_id: relationship.successor_task_id,
      relationship_type: relationship.relationship_type,
      lag_days: relationship.lag_days || 0,
      relationship_description: relationship.relationship_description || ""
    });
    setShowCreateDialog(true);
  };

  const handleDeleteRelationship = async (relationship) => {
    const predecessorTask = getTaskById(relationship.predecessor_task_id);
    const successorTask = getTaskById(relationship.successor_task_id);
    
    if (window.confirm(`Are you sure you want to delete the dependency: ${predecessorTask?.name} → ${successorTask?.name}?`)) {
      try {
        await TaskRelationship.delete(relationship.id);
        if (typeof onRelationshipsUpdate === 'function') {
          await onRelationshipsUpdate();
        }
        alert("Dependency deleted successfully");
      } catch (error) {
        console.error("Error deleting relationship:", error);
        alert("Failed to delete relationship. Please try again.");
      }
    }
  };

  const resetForm = () => {
    setNewRelationship({
      predecessor_task_id: "",
      successor_task_id: "",
      relationship_type: "FS",
      lag_days: 0,
      relationship_description: ""
    });
  };

  const getRelationshipIcon = (type) => {
    switch (type) {
      case "FS": return "→";
      case "SS": return "⇊";
      case "FF": return "⇁";
      case "SF": return "↰";
      default: return "→";
    }
  };

  const getRelationshipDescription = (type) => {
    switch (type) {
      case "FS": return "The predecessor must finish before the successor can start.";
      case "SS": return "Both tasks can start at the same time.";
      case "FF": return "Both tasks must finish at the same time.";
      case "SF": return "The successor must finish before the predecessor can start.";
      default: return "";
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Network className="w-5 h-5 text-green-600" />
              Task Dependencies
              <Badge className="bg-green-100 text-green-700">
                {relationships.length} relationships
              </Badge>
            </CardTitle>
            <Dialog open={showCreateDialog} onOpenChange={(open) => {
              setShowCreateDialog(open);
              if (!open) {
                setEditingRelationship(null);
                resetForm();
              }
            }}>
              <DialogTrigger asChild>
                <Button 
                  className="bg-green-600 hover:bg-green-700 gap-2"
                  onClick={() => {
                    if (tasks.length < 2) {
                      alert("You need at least 2 tasks to create a dependency relationship.");
                      return;
                    }
                    setEditingRelationship(null);
                    resetForm();
                    setShowCreateDialog(true);
                  }}
                >
                  <Plus className="w-4 h-4" />
                  Add Dependency
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>
                    {editingRelationship ? "Edit Task Dependency" : "Create Task Dependency"}
                  </DialogTitle>
                  <DialogDescription>
                    {editingRelationship 
                      ? "Update the task dependency relationship."
                      : "Define how tasks depend on each other in the project schedule."
                    }
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="predecessor">Predecessor Task *</Label>
                    <Select 
                      value={newRelationship.predecessor_task_id} 
                      onValueChange={(value) => setNewRelationship(prev => ({ ...prev, predecessor_task_id: value }))}
                    >
                      <SelectTrigger id="predecessor">
                        <SelectValue placeholder="Select predecessor task" />
                      </SelectTrigger>
                      <SelectContent>
                        {tasks.map(task => (
                          <SelectItem 
                            key={task.id} 
                            value={task.id}
                            disabled={task.id === newRelationship.successor_task_id}
                          >
                            {task.wbs_code ? `${task.wbs_code} - ${task.name}` : task.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="successor">Successor Task *</Label>
                    <Select 
                      value={newRelationship.successor_task_id} 
                      onValueChange={(value) => setNewRelationship(prev => ({ ...prev, successor_task_id: value }))}
                    >
                      <SelectTrigger id="successor">
                        <SelectValue placeholder="Select successor task" />
                      </SelectTrigger>
                      <SelectContent>
                        {tasks.map(task => (
                          <SelectItem 
                            key={task.id} 
                            value={task.id}
                            disabled={task.id === newRelationship.predecessor_task_id}
                          >
                            {task.wbs_code ? `${task.wbs_code} - ${task.name}` : task.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="relationship-type">Relationship Type</Label>
                      <Select 
                        value={newRelationship.relationship_type} 
                        onValueChange={(value) => setNewRelationship(prev => ({ ...prev, relationship_type: value }))}
                      >
                        <SelectTrigger id="relationship-type">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(relationshipTypes).map(([key, value]) => (
                            <SelectItem key={key} value={key}>
                              {key} - {value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="lag-days">Lag/Lead Days</Label>
                      <Input
                        id="lag-days"
                        type="number"
                        value={newRelationship.lag_days}
                        onChange={(e) => setNewRelationship(prev => ({ ...prev, lag_days: parseInt(e.target.value) || 0 }))}
                        placeholder="0"
                      />
                      <p className="text-xs text-slate-500">Positive = Lag, Negative = Lead</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description (Optional)</Label>
                    <Input
                      id="description"
                      value={newRelationship.relationship_description}
                      onChange={(e) => setNewRelationship(prev => ({ ...prev, relationship_description: e.target.value }))}
                      placeholder="e.g., Concrete must cure before steel installation"
                    />
                  </div>

                  <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-sm text-blue-800">
                      <strong>{relationshipTypes[newRelationship.relationship_type]}:</strong>
                      {" " + getRelationshipDescription(newRelationship.relationship_type)}
                    </p>
                  </div>
                </div>
                <DialogFooter>
                  <Button 
                    variant="outline" 
                    onClick={() => setShowCreateDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleSaveRelationship} 
                    disabled={isLoading || !newRelationship.predecessor_task_id || !newRelationship.successor_task_id}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {isLoading ? "Saving..." : editingRelationship ? "Update Dependency" : "Create Dependency"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {relationships.length > 0 ? (
            <div className="space-y-4">
              {relationships.map((relationship, index) => {
                const predecessorTask = getTaskById(relationship.predecessor_task_id);
                const successorTask = getTaskById(relationship.successor_task_id);
                
                return (
                  <motion.div
                    key={relationship.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="p-4 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-slate-900">
                              {predecessorTask?.name || "Unknown Task"}
                            </span>
                            <div className="flex items-center gap-1 px-2 py-1 bg-slate-100 rounded text-sm">
                              <span>{getRelationshipIcon(relationship.relationship_type)}</span>
                              <Badge variant="outline">{relationship.relationship_type}</Badge>
                            </div>
                            <span className="font-medium text-slate-900">
                              {successorTask?.name || "Unknown Task"}
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-4 text-sm text-slate-500">
                          <span>
                            Type: {relationshipTypes[relationship.relationship_type]}
                          </span>
                          {relationship.lag_days !== 0 && (
                            <span>
                              {relationship.lag_days > 0 ? 'Lag' : 'Lead'}: {Math.abs(relationship.lag_days)} days
                            </span>
                          )}
                        </div>
                        
                        {relationship.relationship_description && (
                          <p className="text-sm text-slate-600 mt-2">
                            {relationship.relationship_description}
                          </p>
                        )}
                      </div>
                      
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditRelationship(relationship)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteRelationship(relationship)}
                          className="text-red-600 hover:bg-red-100"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <Network className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-600 mb-2">No Dependencies Defined</h3>
              <p className="text-slate-500 mb-4">
                {tasks.length < 2 
                  ? "Add more tasks to create dependencies between them."
                  : "Create task dependencies to define the project workflow and critical path."
                }
              </p>
              {tasks.length >= 2 && (
                <Button 
                  onClick={() => {
                    resetForm();
                    setShowCreateDialog(true);
                  }}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Dependency
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}